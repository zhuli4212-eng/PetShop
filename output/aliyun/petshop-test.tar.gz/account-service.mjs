// released-accounts:V3
import { createHash as createHash4, createHmac as createHmac2, randomBytes as randomBytes4, randomUUID as randomUUID5 } from "node:crypto";
import { randomBytes as randomBytes2, randomUUID as randomUUID4 } from "node:crypto";
import { createHash as createHash2, randomBytes, randomUUID as randomUUID2 } from "node:crypto";
import { createHash, randomInt, randomUUID } from "node:crypto";
import { createHash as createHash3, createHmac } from "node:crypto";
import { Buffer } from "node:buffer";
import { randomUUID as randomUUID3 } from "node:crypto";
import { randomBytes as randomBytes3, scryptSync, timingSafeEqual } from "node:crypto";
import { Buffer as Buffer2 } from "node:buffer";
function rareRedrawPercent(level) {
  return 10 * (1 + 0.05 * level);
}
function scoreRiseChance(baseGrade, otherGrade, level) {
  let chance = [0.18, 0.18, 0.18, 0.18, 0.1, 0.06, 0][baseGrade];
  if (otherGrade < baseGrade - 1) chance = Math.min(chance, 0.03);
  return Math.min(0.9, chance * (1 + 0.03 * level));
}
function bredValuePercent(level) {
  return 20 + level * 0.5;
}
function percent(value) {
  return Number(value.toFixed(2)) + "%";
}
function researchBonus(branch, level) {
  if (branch === 2) return percent(bredValuePercent(level));
  return (level ? "+" : "") + percent((branch === 0 ? 5 : 3) * level);
}
function researchBenefit(branch, level, speciesName2, mutationEnabled = true) {
  const maxed = level >= 10, next = maxed ? level : level + 1;
  const currentBonus = researchBonus(branch, level);
  const nextBonus = maxed ? null : researchBonus(branch, next);
  let valueLabel, description, delta, example, overview, currentValue, nextValue, switchNote = "";
  if (branch === 0) {
    valueLabel = "重抽出稀有";
    const from = rareRedrawPercent(level), to = rareRedrawPercent(next);
    currentValue = percent(from);
    nextValue = maxed ? null : percent(to);
    overview = "重抽出稀有 " + currentValue + (maxed ? "" : " → " + nextValue);
    description = "升级后再配对，幼" + speciesName2 + "的前五项特征若重新抽标签，就更容易抽到稀有。";
    delta = maxed ? "" : "升这一级，重抽出稀有的机会增加 0.5 个百分点。";
    example = "重抽一个标签时，稀有机会" + (maxed ? "是 " + currentValue : "从 " + currentValue + " 升到 " + nextValue) + "。";
  } else if (branch === 1) {
    valueLabel = "双亲 B 时升 A";
    const from = 100 * scoreRiseChance(3, 3, level), to = 100 * scoreRiseChance(3, 3, next);
    currentValue = percent(from);
    nextValue = maxed ? null : percent(to);
    overview = "双亲 B 时升 A " + currentValue + (maxed ? "" : " → " + nextValue);
    description = "开启选育加成后再配对，幼" + speciesName2 + "的前五项评分各有机会升一档，最高 S+。机会取决于父母的评分。";
    delta = maxed ? "" : "升这一级，多出原本升档机会的 3%。";
    example = "例如父母毛发都是 B，幼体毛发升 A 的机会" + (maxed ? "是 " + currentValue : "从 " + currentValue + " 升到 " + nextValue + "，多 " + Number((to - from).toFixed(2)) + " 个百分点") + "。";
    if (!mutationEnabled) switchNote = "本房选育加成已关闭，配对前可在繁育台打开。";
  } else {
    valueLabel = "估价 200 时";
    const from = 2 * bredValuePercent(level), to = 2 * bredValuePercent(next);
    currentValue = from + " 金币";
    nextValue = maxed ? null : to + " 金币";
    overview = "估价 200，繁育后保留 " + from + (maxed ? "" : " → " + to) + " 金币";
    description = "卖出繁育过的" + speciesName2 + "时，它能多保留一些原本的身价。荣誉和买家的加价另算。";
    delta = maxed ? "" : "升这一级，基础估价多保留 0.5 个百分点。";
    example = "例如基础估价 200 金币，繁育后" + (maxed ? "保留 " + currentValue : "从 " + currentValue + " 增至 " + nextValue) + "。";
  }
  return {
    bonusLabel: branch === 2 ? "保留比例" : "比基础机会多",
    valueLabel,
    metric: valueLabel,
    description,
    currentBonus,
    nextBonus,
    currentValue,
    nextValue,
    overview,
    delta,
    example,
    switchNote
  };
}
var minute = 6e4;
var day = 24 * 60 * minute;
var speciesList = ["rabbit", "cat", "dog"];
var gradeNames = ["E", "D", "C", "B", "A", "S", "S+"];
var baseValues = { rabbit: 100, cat: 1200, dog: 1300 };
var breedFactors = [100, 110, 120, 135];
var stageFactors = { 幼年: 80, 成长: 92, 成年: 100, 老年: 65, 已故: 0 };
var channelNames = { market: "自由市场", order: "订单交付", recycle: "研究所回收", guest: "来客委托" };
var researchNames = ["稀有标签研究", "五维选育研究", "繁育后价值研究"];
var researchBases = { rabbit: 100, cat: 250, dog: 400 };
var ornaments = {
  fence: { name: "矮篱", base: 80 },
  lamp: { name: "台灯", base: 60 },
  plant: { name: "盆栽", base: 100 },
  rug: { name: "地毯", base: 120 }
};
var bjDay = (now) => new Date(now + 8 * 60 * minute).toISOString().slice(0, 10);
var timeLabel = (now) => new Date(now + 8 * 60 * minute).toISOString().slice(5, 16).replace("T", " ");
var choose = (list) => list[randomInt(list.length)];
function weighted(weights) {
  let roll = randomInt(weights.reduce((sum, n) => sum + n, 0));
  for (let i = 0; i < weights.length; i++) {
    roll -= weights[i];
    if (roll < 0) return i;
  }
}
var speciesName = (key) => SPECIES[key].name;
var roomKeys = (s, asOf) => speciesList.filter((key) => s.rooms[key] && s.rooms[key].openedAt <= asOf);
var requireValue = (condition, message) => {
  if (!condition) throw new Error(message);
};
var halfUp = (numerator, denominator) => Math.floor((2 * numerator + denominator) / (2 * denominator));
function purchasePrice(s, base) {
  return 10 * Math.ceil(base * (2e5 - (s.ratingBps || 0)) / 2e6);
}
function quality(p) {
  const indexSum = p.traits.reduce((total, trait) => total + gradeNames.indexOf(trait.grade), 0);
  const normalised = p.traits.slice(0, 5);
  return 600 + 5 * (indexSum - 18) + 18 * normalised.filter((t) => t.rarity === "少见").length + 48 * normalised.filter((t) => t.rarity === "稀有").length;
}
function breedBase(p) {
  const index = SPECIES[p.species].breeds.indexOf(p.breedKey);
  return baseValues[p.species] * (p.mixed ? 100 : breedFactors[index]) / 100;
}
function youngPurchaseBase(p) {
  const youngValue = halfUp(breedBase(p) * 80 * quality(p), 6e4);
  return 10 * Math.ceil(28 * youngValue / 100);
}
function valuation(s, p, now) {
  const base = breedBase(p);
  const q = quality(p);
  const stage = stageOf(p, now);
  const value = halfUp(base * q * stageFactors[stage], 6e4);
  const adult = halfUp(base * q, 600);
  const minimum = Math.max(1, Math.floor(6 * base / 100));
  const bredRate = bredValuePercent(s.research[p.species]?.[2] ?? 0);
  const retained = p.bred ? Math.max(minimum, halfUp(value * bredRate, 100)) : value;
  const honor = Math.floor(base * Math.round((p.honor || 0) * 100) / 100);
  const deadPrice = honor ? Math.max(minimum, Math.floor((adult + 5 * honor) / 10)) : minimum;
  const multiplier = 1e4 + (s.ratingBps || 0);
  return { base, qualityUnits: q, stage, stagePercent: stageFactors[stage], value, adult, minimum, bredRate, retained, honor, deadPrice, multiplier };
}
function salePrice(s, p, now, channel, rate = 100) {
  const { stage, deadPrice, multiplier, retained, honor } = valuation(s, p, now);
  if (channel === "recycle") {
    requireValue(stage === "已故", "研究所只回收已故动物。");
    return halfUp(deadPrice * multiplier, 1e4);
  }
  return halfUp(multiplier * (retained * rate + 100 * honor), 1e6);
}
function makeOrder(s, date, first = false) {
  const species = choose(roomKeys(s, date));
  const diff = first ? 0 : weighted([70, 25, 5]);
  const order = { id: randomUUID(), species, diff, rate: [135, 155, 180][diff] };
  if (diff && randomInt(2)) {
    order.breed = SPECIES[species].breeds[diff === 2 ? 3 : weighted([4, 3, 2])];
  } else if (diff) {
    order.tag = choose(choose(TRAITS)[diff - 1]);
  }
  return order;
}
function orderCondition(order) {
  const pet = speciesName(order.species);
  if (order.breed) return "登记品种为" + BREEDS[order.breed].name;
  if (order.tag) return pet + " · 带「" + order.tag + "」标签";
  return pet + " · 任意品种";
}
function matchesOrder(p, order) {
  return p.species === order.species && (!order.breed || !p.mixed && p.breedKey === order.breed) && (!order.tag || p.traits.slice(0, 5).some((t) => t.label === order.tag));
}
function offerIncome(s, offer, order, now) {
  return salePrice(s, { ...offer, bornAt: now }, now, "order", order.rate);
}
function offerOrderRows(s, offer, now) {
  const rows = [];
  for (const [index, { order }] of (s.orders ?? []).entries()) {
    if (!order || !matchesOrder(offer, order)) continue;
    rows.push({ title: "可交第 " + (index + 1) + " 单", text: orderCondition(order) + " · 购入后立即交付，预计收入 " + offerIncome(s, offer, order, now) + " 金币。" });
  }
  return rows.length ? rows : [{ title: "当前普通订单", text: "这只幼体目前没有匹配的普通订单。" }];
}
function orderStockRows(s, order, now) {
  const speciesPets = s.pets.filter((p) => p.species === order.species);
  const matching = speciesPets.filter((p) => matchesOrder(p, order));
  const rows = [{ title: "所需物种 · " + speciesName(order.species), text: "本店持有 " + speciesPets.length + " 只。" }];
  if (order.breed || order.tag) rows.push({
    title: order.breed ? "所需登记品种 · " + BREEDS[order.breed].name : "所需标签 · " + order.tag,
    text: "该物种中符合此项的有 " + matching.length + " 只。"
  });
  const counts = /* @__PURE__ */ new Map();
  for (const p of matching) {
    const reason = saleBlock(s, p, now, "order") || "可交付";
    counts.set(reason, (counts.get(reason) || 0) + 1);
  }
  rows.push({
    title: "本店可交付 " + (counts.get("可交付") || 0) + " 只",
    text: [...counts].filter(([reason]) => reason !== "可交付").map(([reason, n]) => reason + " " + n + " 只").join(" · ") || (matching.length ? "符合条件的在店动物均可交付。" : "当前没有符合全部条件的在册动物。")
  });
  const offers = (s.rooms[order.species]?.shelf?.offers || []).filter((p) => p && matchesOrder(p, order));
  if (offers.length) {
    for (const offer of offers) rows.push({ ...linkRow(
      "可采购 · " + offer.name + "（" + offer.sex + "）",
      "尚未持有 · 购价 " + purchasePrice(s, youngPurchaseBase(offer)) + " 金币 · 立即交付预计收入 " + offerIncome(s, offer, order, now) + " 金币，成交前重新核价。",
      "offer",
      { species: order.species, id: offer.id },
      petArt(offer)
    ), stage: "幼年" });
  } else rows.push({ title: "本批货架", text: "目前没有符合这张订单的在售幼体。下一批随机供货。" });
  return rows;
}
function readyOrderId(s, now) {
  return s.orders.find(({ order }) => order && canFillOrder(s, order, now))?.order.id ?? null;
}
var canFillOrder = (s, order, now) => s.pets.some((p) => !saleBlock(s, p, now, "order") && matchesOrder(p, order));
function daily(s, now) {
  const date = bjDay(now);
  if (s.businessDay?.date !== date) s.businessDay = { date, freeUsed: 0, bought: 0, arrived: 0 };
}
function initBusiness(s, now) {
  s.research ||= Object.fromEntries(speciesList.map((key) => [key, [0, 0, 0]]));
  s.orders ||= Array.from({ length: 3 }, (_, i) => ({ order: makeOrder(s, now, i === 0), readyAt: null }));
  s.cancelCredits ??= 0;
  s.decor ||= Object.fromEntries(Object.keys(ornaments).map((key) => [key, { owned: false, placed: false }]));
  s.visitors ||= { active: null, elapsed: 0, misses: 0, sessions: {}, intervals: [], since: now };
  s.sales ||= [];
  daily(s, now);
}
function endVisit(v, time2) {
  v.active = null;
  v.elapsed = 0;
  v.misses = 0;
  v.intervals = [];
  v.since = time2;
}
function tickBusiness(s, now) {
  daily(s, now);
  for (const slot of s.orders) {
    if (!slot.order && now >= slot.readyAt) {
      slot.order = makeOrder(s, slot.readyAt);
      slot.order.refilledAt = slot.readyAt;
      slot.readyAt = null;
    }
  }
  const v = s.visitors;
  if (v.active && now >= v.active.endsAt) endVisit(v, v.active.endsAt);
  for (const [key, last] of Object.entries(v.sessions)) {
    if (now - last > minute) delete v.sessions[key];
  }
}
function visitorRequirements(p, stage) {
  const base = { species: p.species, breed: p.mixed ? "mixed" : p.breedKey, stage };
  const list = [];
  p.traits.slice(0, 5).forEach((t, dimension) => {
    if (gradeNames.indexOf(t.grade) >= 4) list.push({ ...base, dimension, tag: t.label, rarity: t.rarity });
  });
  if (gradeNames.indexOf(p.traits[1].grade) >= 4) {
    list.push({ ...base, coat: BREEDS[p.breedKey].coats[p.coatIndex - 1] });
  }
  return list;
}
function pickVisit(s, now) {
  const immediate = [], future = [];
  for (const p of s.pets) {
    if (saleBlock(s, p, now, "guest")) continue;
    let at = now;
    while (at <= now + 25 * minute) {
      const stage = stageOf(p, at), end = stageEnd(p, at);
      if (stage === "已故" || !end || end <= at) break;
      const isNow = at === now;
      if (end - at >= (isNow ? 2 : 5) * minute) {
        (isNow ? immediate : future).push(...visitorRequirements(p, stage));
      }
      at = end;
    }
  }
  const pool = immediate.length && future.length ? randomInt(100) < 70 ? immediate : future : immediate.length ? immediate : future;
  if (!pool.length) return null;
  const species = choose([...new Set(pool.map((r) => r.species))]);
  const bySpecies = pool.filter((r) => r.species === species);
  const tag = choose([...new Set(bySpecies.map((r) => Boolean(r.tag)))]);
  const unique = new Map(bySpecies.filter((r) => Boolean(r.tag) === tag).map((r) => [JSON.stringify(r), r]));
  return choose([...unique.values()]);
}
function matchesVisit(p, request, now) {
  if (p.species !== request.species || (p.mixed ? "mixed" : p.breedKey) !== request.breed || stageOf(p, now) !== request.stage) return false;
  if (request.tag) {
    const trait = p.traits[request.dimension];
    return trait.label === request.tag && trait.rarity === request.rarity && gradeNames.indexOf(trait.grade) >= 4;
  }
  return request.coat === BREEDS[p.breedKey].coats[p.coatIndex - 1] && gradeNames.indexOf(p.traits[1].grade) >= 4;
}
function visitCondition(v) {
  const r = v.requirement;
  return [
    r.breed === "mixed" ? "杂交" + speciesName(r.species) : BREEDS[r.breed].name,
    r.stage,
    r.tag ? r.rarity + "标签「" + r.tag + "」且该维至少A" : r.coat + "花色且品相至少A"
  ].join(" · ");
}
function addInterval(v, start, end) {
  const intervals = v.intervals.filter((pair) => pair[1] >= end - 3e4);
  const previous = intervals.reduce((sum, [a, b]) => sum + b - a, 0);
  intervals.push([start, end]);
  intervals.sort((a, b) => a[0] - b[0]);
  const merged = [];
  for (const pair of intervals) {
    const tail = merged.at(-1);
    if (tail && tail[1] >= pair[0]) tail[1] = Math.max(tail[1], pair[1]);
    else merged.push([...pair]);
  }
  v.intervals = merged;
  v.elapsed += merged.reduce((sum, [a, b]) => sum + b - a, 0) - previous;
}
function businessHeartbeat(s, { clientId, foreground }, now) {
  requireValue(typeof clientId === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(clientId), "连接标识无效。");
  const v = s.visitors, key = "client:" + clientId, last = v.sessions[key];
  if (!foreground) {
    delete v.sessions[key];
    return;
  }
  v.sessions[key] = now;
  if (v.active || s.businessDay.arrived >= 6 || last === void 0 || now - last > 3e4 || now <= last) return;
  addInterval(v, Math.max(last, v.since), now);
  if (v.elapsed < 10 * minute) return;
  v.elapsed -= 10 * minute;
  const requirement = pickVisit(s, now);
  if (!requirement) return;
  if (v.misses < 2 && randomInt(100) >= 35) {
    v.misses++;
    return;
  }
  v.active = { id: randomUUID(), requirement, endsAt: now + 30 * minute };
  v.elapsed = 0;
  v.misses = 0;
  s.businessDay.arrived++;
}
function saleTarget(s, args, now) {
  const channel = args.channel;
  requireValue(Object.hasOwn(channelNames, channel), "请选择出售渠道。");
  if (channel === "order") {
    const slot = s.orders.find((entry) => entry.order?.id === args.targetId);
    requireValue(slot, "这张委托已经结束，请返回订单夹。");
    return {
      channel,
      rate: slot.order.rate,
      condition: orderCondition(slot.order),
      slot,
      eligible: (p) => matchesOrder(p, slot.order)
    };
  }
  if (channel === "guest") {
    const guest = s.visitors.active;
    requireValue(guest && guest.id === args.targetId && now < guest.endsAt, "这位客人已经离店。");
    return { channel, rate: 215, condition: visitCondition(guest), eligible: (p) => matchesVisit(p, guest.requirement, now) };
  }
  if ((channel === "market" || channel === "recycle") && args.species !== void 0) {
    requireValue(Object.hasOwn(SPECIES, args.species), "请选择要出售动物的房间。");
    const name = speciesName(args.species) + "房";
    const condition = channel === "market" ? "收购" + name + "的空闲活体" : name + " · 仅回收已故动物";
    return {
      channel,
      species: args.species,
      rate: 100,
      condition,
      eligible: (p) => p.species === args.species
    };
  }
  return {
    channel,
    rate: 100,
    condition: channel === "market" ? "收购空闲的在店活体" : "仅回收已故动物",
    eligible: () => true
  };
}
function saleBlocks(s, p, now, channel) {
  const reasons = [], deceased = stageOf(p, now) === "已故";
  if (channel === "recycle" && !deceased) reasons.push("活体");
  if (isBusy(s, p)) reasons.push("繁育中");
  if (channel !== "recycle" && deceased) reasons.push("已故");
  if (p.retained) reasons.push("种源保护");
  return reasons;
}
function saleBlock(s, p, now, channel) {
  return saleBlocks(s, p, now, channel)[0];
}
function petCaption(p, now, status = p.bred ? "已繁育" : "未繁育") {
  return [
    breedName(p),
    BREEDS[p.breedKey].coats[p.coatIndex - 1],
    p.sex,
    stageOf(p, now),
    status,
    ...p.retained ? ["种源"] : []
  ].join(" · ");
}
function quoteSelection(s, args, now, agreedAmounts) {
  const ids = args.ids;
  requireValue(Array.isArray(ids) && ids.length && new Set(ids).size === ids.length, "请勾选动物，每只只能选一次。");
  let target;
  const filter = args.channel === "market" ? rosterFilter(args.filter) : "全部";
  const stage = args.channel === "market" ? rosterStage(args.stage, args.filter) : "全部";
  const lines = [], issues = [];
  try {
    target = saleTarget(s, args, now);
  } catch (error) {
    if (args.channel !== "order" && args.channel !== "guest") throw error;
    issues.push(error.message);
  }
  const byId = new Map(s.pets.map((p) => [p.id, p]));
  const departed = /* @__PURE__ */ new Map(), missing = new Set(ids.filter((id) => !byId.has(id)));
  if (missing.size) for (const sale of s.sales || []) {
    for (const line of sale.lines) if (missing.has(line.id)) departed.set(line.id, line.name);
  }
  for (const [index, id] of ids.entries()) {
    const p = byId.get(id);
    const name = (p?.name || departed.get(id) || "所选动物") + " #" + String(id).slice(0, 6).toUpperCase();
    if (!p) {
      issues.push(name + "已离店");
      continue;
    }
    const blocked = saleBlock(s, p, now, args.channel);
    if (blocked || target && !target.eligible(p)) {
      const reason = { 活体: "仍在世，研究所只回收已故动物", 种源保护: "已标记为种源" }[blocked] || blocked;
      issues.push(name + (reason ? "（" + reason + "）" : "") + "不再符合交付条件");
      continue;
    }
    if (!rosterFilters[filter](s, p, now)) {
      issues.push(name + "已不符合「" + filter + "」筛选");
      continue;
    }
    if (stage !== "全部" && stageOf(p, now) !== stage) {
      issues.push(name + "已不符合「" + stage + "」筛选，目前为" + stageOf(p, now));
      continue;
    }
    if (!target) continue;
    const amount = salePrice(s, p, now, args.channel, target.rate);
    if (Array.isArray(agreedAmounts) && agreedAmounts[index] !== amount) {
      issues.push(name + "现价 " + amount + " 金币");
    }
    lines.push({ id, name: p.name, amount });
  }
  if (issues.length) throw new Error(issues.map((text) => text.replace(/。$/, "")).join("。") + "。请重新核价。");
  const selected = new Set(ids), risks = [];
  for (const species of speciesList) for (const sex of ["母", "公"]) {
    const remaining = s.pets.filter((p) => p.species === species && p.sex === sex && !p.bred && !isBusy(s, p) && stageOf(p, now) !== "已故");
    if (remaining.length && remaining.every((p) => selected.has(p.id))) risks.push(speciesName(species) + "房最后的未繁育" + sex + speciesName(species));
  }
  const terms = [target.channel, args.targetId || null, lines, risks];
  if (target.species) terms.push(target.species);
  if (filter !== "全部") terms.push(filter);
  if (stage !== "全部") terms.push({ stage });
  const hash2 = createHash("sha256").update(JSON.stringify(terms)).digest("hex");
  return { target, lines, risks, hash: hash2, filter, stage, total: lines.reduce((sum, row) => sum + row.amount, 0) };
}
function validateSaleQuote(s, args, now) {
  const quote = quoteSelection(s, args, now, args.amounts);
  requireValue(quote.hash === args.hash, "报价或未繁育动物余量已变化，请重新核价后再确认。");
  let kept = [];
  if (args.litterRetention) {
    if (args.channel !== "market") throw new Error("请从本窝的自由市场报价确认。");
    kept = retainedLitterPets(s, args.litterRetention, args.ids, now);
  }
  return { quote, kept };
}
function saleCommit(s, args, now) {
  const { quote, kept } = validateSaleQuote(s, args, now);
  const ids = new Set(args.ids);
  for (const p of kept) p.retained = true;
  s.pets = s.pets.filter((p) => !ids.has(p.id));
  s.coins += quote.total;
  s.sales.push({ at: now, channel: args.channel, targetId: args.targetId || null, lines: quote.lines, total: quote.total });
  if (quote.target.slot) {
    quote.target.slot.order = null;
    quote.target.slot.readyAt = now + 30 * minute;
  }
  if (args.channel === "guest") endVisit(s.visitors, now);
  return "已交付 " + ids.size + " 只，收入 " + quote.total + " 金币。";
}
function researchCost(s, species, target) {
  return purchasePrice(s, researchBases[species] * target * target);
}
function requirements(branch, level) {
  if (level <= 3) return [];
  return (level <= 6 ? [(branch + 1) % 3] : [0, 1, 2].filter((b) => b !== branch)).map((index) => ({ index, needed: level - 3 }));
}
function researchState(s, species, branch) {
  requireValue(speciesList.includes(species) && Number.isInteger(branch) && branch >= 0 && branch < 3, "研究项目不存在。");
  const levels = s.research[species], level = levels[branch];
  if (!s.rooms[species]) return "房间未开放";
  if (level === 10) return "已满级";
  if (requirements(branch, level + 1).some((r) => levels[r.index] < r.needed)) return "前置不足";
  if (s.coins < researchCost(s, species, level + 1)) return "金币不足";
  return "可研究";
}
var nextPage = (label, page, args = {}) => ({ label, page, args });
var linkRow = (title, text, page, args = {}, art) => ({ title, text, art, link: { page, args } });
function marketRoster(s, page, args, target, now) {
  const filter = rosterFilter(args.filter);
  const stage = rosterStage(args.stage, args.filter);
  const scope = { channel: "market", ...target.species && { species: target.species } };
  const rows = [], counts = { "种源保护": 0, "繁育中": 0, "已故": 0 };
  let eligibleCount = 0;
  for (const p of s.pets) {
    if (!target.eligible(p) || !rosterFilters[filter](s, p, now) || stage !== "全部" && stageOf(p, now) !== stage) continue;
    const reasons2 = saleBlocks(s, p, now, "market");
    const number2 = p.id.slice(0, 5).toUpperCase(), summary = petCaption(p, now, stockStatus(s, p));
    const visual = { name: p.name, number: number2, summary };
    const row = { ...linkRow(p.name, summary + " · #" + number2, "pet", { id: p.id }, petArt(p)), stage: stageOf(p, now), visual };
    if (reasons2.length) {
      for (const reason of reasons2) counts[reason]++;
      visual.blockedReason = reasons2.join(" · ");
      row.text += " · 不可出售：" + visual.blockedReason;
    } else {
      visual.price = salePrice(s, p, now, "market", target.rate);
      row.title += "  ·  " + visual.price + " 金币";
      row.select = p.id;
      eligibleCount++;
    }
    rows.push(row);
  }
  const reasons = Object.entries(counts).filter(([, count]) => count).map(([reason, count]) => reason + " " + count + " 只");
  return {
    title: channelNames.market,
    subtitle: [target.condition, ...reasons].join(" · "),
    visual: { eligibleCount, protectedCount: counts.种源保护 },
    empty: "当前筛选下没有动物。",
    rows,
    filters: [
      Object.keys(rosterFilters).map((label) => ({ ...nextPage(label, page, { ...scope, filter: label, stage }), active: label === filter })),
      ["全部", ...stageNames].map((label) => ({ ...nextPage(label, page, { ...scope, filter, stage: label }), active: label === stage }))
    ],
    actions: eligibleCount ? [{ ...nextPage("核对所选报价", "saleQuote", { ...scope, ...filter !== "全部" && { filter }, ...stage !== "全部" && { stage } }), useSelection: true }] : []
  };
}
function orderActions(s, id) {
  const source = s.businessDay.freeUsed < 3 ? "free" : "paid";
  const actions = [nextPage("选择交付动物", "sale", { channel: "order", targetId: id })];
  if (source === "free" || s.cancelCredits > 0) {
    actions.push({
      label: source === "free" ? "使用免费次数取消" : "使用已购次数取消",
      type: "order.cancel",
      args: { id, source },
      confirm: "消耗一次" + (source === "free" ? "免费" : "已购") + "取消次数，本槽 30 分钟后更新。确认取消？",
      go: "orders"
    });
  } else actions.push(nextPage("查看额外取消次数", "credits"));
  return actions;
}
function businessPage(s, page, args, now) {
  if (page === "lab") {
    return { title: "研究所", art: "shop-modules/lab", visual: { shelf: carePage(s, "shelf", { species: "rabbit" }, now) }, rows: [
      linkRow("幼体货架", "每个已开放动物房各有两格，每 30 分钟换批。", "shelf"),
      linkRow("研究手册", "选一个动物房，看看研究能让幼体或售价改善多少。", "research"),
      linkRow("服务单", "购买特征复评或选育指导服务。", "services"),
      linkRow("回收窗口", "仅回收已故动物，可多选并逐只核价。", "recycle")
    ] };
  }
  if (page === "market" || page === "recycle" || page === "sale") {
    const channel = page === "sale" ? args.channel : page;
    const target = saleTarget(s, { ...args, channel }, now);
    if (channel === "market") return marketRoster(s, page, args, target, now);
    const targetArgs = { channel, ...args.targetId && { targetId: args.targetId }, ...target.species && { species: target.species } };
    const eligible2 = [], omitted = { 种源保护: 0, 繁育中: 0, 已故: 0, 活体: 0, 不符需求: 0 };
    for (const p of s.pets) {
      if (target.species && p.species !== target.species) continue;
      const blocked = !target.eligible(p) ? "不符需求" : saleBlock(s, p, now, channel);
      if (blocked) omitted[blocked]++;
      else eligible2.push(p);
    }
    const reasons = Object.entries(omitted).filter(([, count]) => count).map(([reason, count]) => reason + " " + count + " 只");
    return {
      title: channelNames[channel],
      subtitle: [target.condition, ...reasons].join(" · "),
      visual: { protectedCount: omitted.种源保护 },
      empty: (channel === "recycle" ? "当前没有可回收的已故动物。" : "当前没有符合收购条件的动物。") + (omitted.种源保护 ? "种源不可出售，可在个体档案中取消留种。" : ""),
      rows: eligible2.map((p) => {
        const price = salePrice(s, p, now, channel, target.rate);
        return {
          title: p.name + "  ·  " + price + " 金币",
          visual: { name: p.name, price, summary: petCaption(p, now) },
          text: petCaption(p, now) + " · #" + p.id.slice(0, 6).toUpperCase(),
          art: petArt(p),
          stage: stageOf(p, now),
          select: p.id
        };
      }),
      actions: eligible2.length ? [{ label: "核对所选报价", page: "saleQuote", args: targetArgs, useSelection: true }] : []
    };
  }
  if (page === "saleQuote") {
    const { target, lines, total, risks, hash: hash2, filter, stage } = quoteSelection(s, args, now);
    const scope = target.species ? { species: target.species } : {};
    const rows = lines.map((line) => ({ title: line.name, text: line.amount + " 金币 · 编号 " + line.id.slice(0, 6).toUpperCase() }));
    if (risks.length) rows.push({ title: "繁育提醒", text: "本批包含" + risks.join("、") + "。" });
    return {
      title: "核对出售",
      subtitle: channelNames[args.channel] + " · " + lines.length + " 只，合计 " + total + " 金币",
      rows,
      actions: [{
        label: "确认交付 · " + total + " 金币",
        type: "sale.commit",
        args: {
          channel: args.channel,
          ...scope,
          ...filter !== "全部" && { filter },
          ...stage !== "全部" && { stage },
          ids: args.ids,
          targetId: args.targetId || null,
          amounts: lines.map((line) => line.amount),
          hash: hash2
        }
      }, { label: "修改选择", type: "ui.editSelection" }]
    };
  }
  if (page === "orders") {
    return {
      title: "普通订单",
      subtitle: "普通订单长期有效，交付时核验动物。",
      visual: { remaining: 3 - s.businessDay.freeUsed },
      rows: s.orders.map((slot, i) => {
        if (!slot.order) return { title: "第 " + (i + 1) + " 单 · 等待新客", text: timeLabel(slot.readyAt) + " 更新（北京时间）" };
        const order = slot.order, condition = orderCondition(order), difficulty = ["简单", "普通", "困难"][order.diff];
        const available = canFillOrder(s, order, now);
        const choices = orderActions(s, order.id);
        return {
          ...linkRow("第 " + (i + 1) + " 单 · " + difficulty, condition + " · 基础估值 ×" + order.rate / 100, "orderDesk", { id: order.id }),
          visual: { name: order.breed ? "品种收养委托" : order.tag ? "特征收养委托" : "街坊的委托", condition, difficulty, rate: order.rate / 100, available, choices }
        };
      }),
      actions: [nextPage("额外取消次数", "credits")]
    };
  }
  if (page === "orderDesk") {
    const slot = s.orders.find((item) => item.order?.id === args.id);
    if (!slot) return { title: "委托已结束", rows: [], actions: [nextPage("查看订单夹", "orders")] };
    return { title: "普通委托", subtitle: orderCondition(slot.order), rows: [
      ...orderStockRows(s, slot.order, now),
      { title: "订单倍率", text: "基础估值 ×" + slot.order.rate / 100 + "，荣誉另计。" },
      { title: "可用取消次数", text: "今日免费 " + (3 - s.businessDay.freeUsed) + " 次 · 已购 " + s.cancelCredits + " 次" }
    ], actions: orderActions(s, args.id) };
  }
  if (page === "credits") {
    const price = purchasePrice(s, 300);
    return { title: "额外取消次数", rows: [
      { title: "今日免费剩余", text: 3 - s.businessDay.freeUsed + " / 3 次" },
      { title: "已购余额", text: s.cancelCredits + " / 99 次 · 跨日保留" },
      { title: "今日已购买", text: s.businessDay.bought + " / 3 次" },
      { title: "每次基准 300 金币", text: "实付 " + price + " 金币" }
    ], actions: s.businessDay.bought < 3 && s.cancelCredits < 99 && s.coins >= price ? [{
      label: "购买 1 次",
      type: "order.buyCredit",
      args: { price },
      confirm: "支付 " + price + " 金币，增加 1 次额外取消次数？"
    }] : [] };
  }
  if (page === "guest") {
    const v = s.visitors, g = v.active;
    if (!g) return { title: "特殊来客", art: "shop-modules/guest", rows: [
      { title: "正在候客", text: "符合顾客偏好的动物可吸引特殊来客；在店经营时等候到访。" },
      { title: "今日到店", text: s.businessDay.arrived + " / 6 位" }
    ] };
    const hasMatch = s.pets.some((p) => !saleBlock(s, p, now, "guest") && matchesVisit(p, g.requirement, now));
    return { title: "书店来客", subtitle: visitCondition(g), rows: [
      { title: "来客报价", text: "基础估值 ×2.15，荣誉另计。" },
      { title: "离店时间", text: timeLabel(g.endsAt) + "（北京时间）" },
      ...!hasMatch ? [{ title: "暂时无法交付", text: "店内空闲动物尚未满足这份委托，可在客人离店前再次查看。" }] : []
    ], actions: [
      { ...nextPage("挑选动物", "sale", { channel: "guest", targetId: g.id }), disabled: !hasMatch },
      { label: "婉拒来客", type: "guest.dismiss", args: { id: g.id }, confirm: "婉拒后这位客人将离店。" }
    ] };
  }
  if (page === "research" || page === "researchNode" || page === "researchTable") return researchPage(s, page, args);
  if (page === "decor") return decorPage(s);
  return null;
}
function researchPage(s, page, args) {
  const species = args.species ?? "rabbit";
  requireValue(speciesList.includes(species), "物种不存在。");
  const levels = s.research[species];
  const benefitAt = (branch2, level2) => researchBenefit(branch2, level2, speciesName(species), s.rooms[species]?.mutationEnabled !== false);
  if (page === "research") {
    return {
      title: "研究技能树",
      visual: { levels, open: !!s.rooms[species], handbook: speciesName(species) + "房研究手册" },
      subtitle: s.rooms[species] ? "当前总等级 " + levels.reduce((sum, x) => sum + x, 0) + " / 30" : "开放该物种房间后可以研究。",
      tabs: speciesList.map((key) => ({ ...nextPage(speciesName(key) + "房", "research", { species: key }), active: key === species })),
      rows: levels.map((level2, branch2) => {
        const benefit2 = benefitAt(branch2, level2), status2 = researchState(s, species, branch2);
        return { ...linkRow(
          researchNames[branch2] + " · " + level2 + " 级",
          benefit2.overview + " · " + status2,
          "researchNode",
          { species, branch: branch2 }
        ), visual: { benefit: benefit2, status: status2 } };
      })
    };
  }
  const branch = args.branch, status = researchState(s, species, branch);
  const level = levels[branch], target = level + 1;
  const benefit = benefitAt(branch, level), description = benefit.description;
  if (page === "researchTable") {
    return { title: researchNames[branch], subtitle: description, visual: { benefit, status }, rows: Array.from({ length: 11 }, (_, i) => {
      const entry = benefitAt(branch, i);
      return { title: i + " 级" + (level === i ? " · 当前" : ""), text: entry.currentBonus, visual: { benefit: entry } };
    }) };
  }
  const rows = [{ title: "当前 · " + level + " 级", text: benefit.currentBonus }];
  const origin = Number.isInteger(args.originBranch) && args.originBranch >= 0 && args.originBranch < levels.length ? args.originBranch : branch;
  const context = origin === branch ? { species, branch } : { species, branch, originBranch: origin };
  const actions = [nextPage("查看 0–10 级效果", "researchTable", context)];
  if (origin !== branch) actions.push(nextPage("查看原研究", "researchNode", { species, branch: origin }));
  if (level < 10) {
    const price = researchCost(s, species, target);
    rows.push(
      { title: "下级 · " + target + " 级", text: benefit.nextBonus },
      { title: "基准 / 实付", text: researchBases[species] * target * target + " / " + price + " 金币" },
      { title: "本分支前置", text: "需要 " + level + " 级 · 已满足" }
    );
    for (const req of requirements(branch, target)) {
      rows.push(linkRow(researchNames[req.index] + " · 前置", levels[req.index] + " / " + req.needed + " 级 · " + (levels[req.index] >= req.needed ? "已满足" : "未满足"), "researchNode", { species, branch: req.index, originBranch: origin }));
    }
    if (status === "可研究") {
      const subject = [
        "重新抽一个标签时，抽到稀有的机会",
        "例如父母毛发都是 B，幼体毛发升到 A 的机会",
        "例如原本估价 200 金币，繁育后能保留的身价"
      ][branch];
      const confirm = [
        speciesName(species) + "房" + researchNames[branch] + "升至 " + target + " 级",
        "花费 " + price + " 金币",
        subject,
        benefit.currentValue + " → " + benefit.nextValue,
        benefit.switchNote
      ].filter(Boolean).join("\n");
      actions.push({ label: "升级至 " + target + " 级", type: "research.upgrade", args: { species, branch, level, price }, confirm });
    }
  }
  return { title: researchNames[branch], subtitle: description + " " + status, visual: { description, status, benefit }, rows, actions };
}
function decorPage(s) {
  return { title: "店内装饰", subtitle: "购入后可随时在固定位置摆出或收起。", rows: Object.entries(ornaments).map(([key, item]) => {
    const record = s.decor[key], price = purchasePrice(s, item.base), art = "decor/" + key;
    if (!record.owned) return {
      title: item.name,
      art,
      text: "基准 " + item.base + " · 实付 " + price + " 金币",
      action: { type: "decor.buy", args: { key, price }, confirm: "购买" + item.name + "？基准 " + item.base + " 金币，实付 " + price + " 金币。" }
    };
    return {
      title: item.name + (record.placed ? " · 已摆出" : " · 已收起"),
      art,
      text: record.placed ? "点此收起" : "点此摆出",
      action: { type: "decor.place", args: { key, placed: !record.placed } }
    };
  }) };
}
function pay(s, price, agreed) {
  requireValue(agreed === price, "实付价格有变化，请重新确认。");
  requireValue(s.coins >= price, "金币不足。");
  s.coins -= price;
}
function businessAction(s, type, args, now) {
  switch (type) {
    case "sale.commit":
      return saleCommit(s, args, now);
    case "order.buyCredit": {
      requireValue(s.businessDay.bought < 3, "今天已经买过 3 次。");
      requireValue(s.cancelCredits < 99, "已购次数达到 99 次。");
      pay(s, purchasePrice(s, 300), args.price);
      s.cancelCredits++;
      s.businessDay.bought++;
      return "已购入 1 次额外取消次数。";
    }
    case "order.cancel": {
      const slot = s.orders.find((entry) => entry.order?.id === args.id);
      requireValue(slot, "委托已结束，请查看当前订单。");
      if (args.source === "free") {
        requireValue(s.businessDay.freeUsed < 3, "今日免费次数已用完，请重新选择。");
        s.businessDay.freeUsed++;
      } else {
        requireValue(
          args.source === "paid" && s.businessDay.freeUsed >= 3 && s.cancelCredits > 0,
          "当前取消额度变化，请重新确认。"
        );
        s.cancelCredits--;
      }
      slot.order = null;
      slot.readyAt = now + 30 * minute;
      return "已取消委托，此槽将在 30 分钟后更新。";
    }
    case "guest.dismiss": {
      requireValue(s.visitors.active && s.visitors.active.id === args.id, "这位来客已经离店。");
      endVisit(s.visitors, now);
      return "已送别来客。";
    }
    case "research.upgrade": {
      const { species, branch, level, price } = args;
      const status = researchState(s, species, branch);
      requireValue(status === "可研究", status);
      requireValue(level === s.research[species][branch], "研究等级已变化，请重新确认。");
      pay(s, researchCost(s, species, level + 1), price);
      s.research[species][branch]++;
      return speciesName(species) + "房" + researchNames[branch] + "已升至 " + (level + 1) + " 级。";
    }
    case "decor.buy": {
      const { key, price } = args;
      requireValue(Object.hasOwn(ornaments, key), "装饰不存在。");
      requireValue(!s.decor[key].owned, "该装饰已购买。");
      pay(s, purchasePrice(s, ornaments[key].base), price);
      s.decor[key].owned = true;
      return "已购买" + ornaments[key].name + "，可点选摆出。";
    }
    case "decor.place": {
      const { key, placed } = args;
      requireValue(Object.hasOwn(ornaments, key) && s.decor[key].owned && typeof placed === "boolean", "请先购买该装饰。");
      s.decor[key].placed = placed;
      return ornaments[key].name + (placed ? "已摆出。" : "已收起。");
    }
    default:
      return void 0;
  }
}
var GRADES = ["E", "D", "C", "B", "A", "S", "S+"];
var defectLabels = ["明显缺陷", "轻微缺陷", "轻微缺陷", "无明显缺陷", "无明显缺陷", "完美无缺", "完美无缺"];
var traitWeights = [15, 20, 15, 25, 25];
var perfectByGrade = [1, 2, 3, 5, 10, 18, 30];
var gapTable = [
  { gap: 0, e: 0, d: 0.5, c: 1.5, a: 14, match: 1 },
  { gap: 2, e: 1, d: 4, c: 10, a: 10, match: 0.6 },
  { gap: 6, e: 24, d: 27, c: 29, a: 2, match: 0.2 }
];
function defectTrait(grade) {
  return { type: "缺陷", label: defectLabels[GRADES.indexOf(grade)], rarity: "普通", grade };
}
function defectProbabilities(motherTraits, fatherTraits) {
  let gapSum = 0, perfectSum = 0;
  for (const [i, weight] of traitWeights.entries()) {
    const mother = GRADES.indexOf(motherTraits[i].grade);
    const father = GRADES.indexOf(fatherTraits[i].grade);
    gapSum += weight * Math.abs(mother - father);
    perfectSum += weight * perfectByGrade[Math.min(mother, father)];
  }
  const gap = gapSum / 100;
  const segment = gap <= gapTable[1].gap ? 0 : 1;
  const low = gapTable[segment], high = gapTable[segment + 1];
  const fraction = (gap - low.gap) / (high.gap - low.gap);
  const interpolate = (key) => low[key] + (high[key] - low[key]) * fraction;
  const e = interpolate("e"), d = interpolate("d"), c = interpolate("c"), a = interpolate("a");
  const mildPercent = d + c, defectPercent = e + mildPercent;
  const perfectPercent = perfectSum / 100 * interpolate("match");
  const b = 100 - defectPercent - a - perfectPercent;
  const gradePercents = [e, d, c, b, a, perfectPercent * 0.8, perfectPercent / 5];
  return { defectPercent, perfectPercent, obviousPercent: e, mildPercent, gradePercents };
}
var petNames = Object.freeze(`
小朵 糯米 芝麻 点点 松子 桃酥 栗子 杏仁 阿团 花生 奶糖 小满 饼干 米粒 绒球 豆花
汤圆 米糕 麻薯 花卷 糖糕 豆包 芋圆 蛋卷 年糕 烧麦 藕粉 桂糕 雪饼 云吞 馒头 豆沙
麦芽 米酥 糖球 豆皮 玉米 红薯 南瓜 青豆 冬瓜 芋头 莲蓉 糖藕 布丁 果冻 软糖 雪糕
果酱 奶盖 可可 拿铁 奶泡 奶酪 奶黄 抹茶 乌龙 果茶 蜜糖 冰粉 甜筒 酸奶 松饼 蛋挞
小柚 青梅 橘子 橙子 柿子 杨桃 山楂 荔枝 龙眼 莲雾 葡萄 蜜瓜 杏子 李子 樱桃 枇杷
青枣 金桔 桑葚 蓝莓 草莓 白桃 杨梅 苹果 柠檬 甘蔗 无花果 石榴 西柚 椰子 梨儿 桃仁
茉莉 白兰 桂花 海棠 木槿 紫苏 丁香 鸢尾 铃兰 雏菊 月桂 栀子 含笑 迎春 玉兰 芍药
青葵 木棉 白芷 茶花 兰草 秋葵 薄荷 云杉 水杉 榆钱 松果 橡果 柳絮 芦苇 莲子 苜蓿
春芽 夏叶 秋实 冬青 小葱 青笋 毛栗 竹笋 芦花 荷叶 桐花 芽尖 青禾 青竹 艾草 三叶
朝露 晚霞 夕照 星星 云朵 彩虹 月牙 晴天 小雨 雨滴 晨雾 霜花 雪团 露珠 海风 山岚
晨星 弯月 银河 星屑 清晖 朝阳 秋分 夏至 春分 白露 立夏 冬至 芒种 谷雨 雨水 初晴
山雀 海盐 溪石 圆石 沙洲 青川 溪流 小舟 竹筏 贝壳 珍珠 珊瑚 银沙 泉眼 涟漪 潮汐
风铃 纸鸢 铃铛 铜铃 纽扣 毛线 绒帽 丝带 风筝 纸船 风车 绣球 花灯 小鼓 团扇 阿绵
木木 阿柴 甜勺 果果 小篓 棠棠 纸鹤 书书 墨滴 竹笛 琴儿 皮皮 桃仔 棉仔 彩彩 铃鼓
团团 圆圆 蓬蓬 暖暖 悠悠 朵朵 萌萌 跳跳 笑笑 呼呼 啾啾 嘟嘟 咕咕 扑扑 弯弯 蹦蹦
绵绵 甜甜 酥酥 噗噗 轻轻 转转 滚滚 绒绒 眯眯 囡囡 闪闪 泡泡 斑斑 星仔 芝仔 果仔
乌梅 阿栗 阿禾 阿梨 阿竹 阿诺 阿布 阿桃 阿杏 阿圆 阿橘 阿蓉 阿巧 阿福 阿乐 阿夏
小溪 小岛 小丘 小径 小桥 小苗 小枝 小瓣 小蕊 小穗 小藤 小葵 小榛 小枫 小栎 小蕨
梨窝 酒窝 眉豆 雪顶 乌豆 金豆 米白 桂圆 青团 麦香 灯芯 琥珀 云母 青瓷 墨玉 青苔 余晖
圆耳 歪耳 短尾 花尾 绒爪 雪爪 棉絮 棉桃 灰团 黑豆 白袜 花袖 半糖 满月 轻舟 飞絮
`.trim().split(/\s+/));
function occupiedPetNames(s, excludedOffers = []) {
  const used = new Set(s.pets.map((p) => p.name));
  for (const room of Object.values(s.rooms)) {
    for (const p of room.shelf?.offers ?? []) {
      if (p && !excludedOffers.includes(p)) used.add(p.name);
    }
    for (const p of room.job?.offspring ?? []) used.add(p.name);
  }
  return used;
}
function takePetName(used, roll, preferred) {
  let name = preferred;
  if (!name || used.has(name)) {
    const start = Math.floor(roll * petNames.length);
    for (let offset2 = 0; offset2 < petNames.length; offset2++) {
      name = petNames[(start + offset2) % petNames.length];
      if (!used.has(name)) break;
    }
    if (used.has(name)) {
      const base = petNames[start];
      let number2 = 2;
      do {
        name = base + "·" + number2++;
      } while (used.has(name));
    }
  }
  used.add(name);
  return name;
}
var go = (label, page, args = {}) => ({ label, page, args });
var link = (title, text, page, args = {}, extra = {}) => ({ title, text, link: { page, args }, ...extra });
var act = (label, type, args, confirm, page, goArgs = {}) => ({ label, type, args, confirm, go: page, goArgs });
var number = (p) => p.id.slice(0, 5).toUpperCase();
var options = (s, page, current2) => Object.entries(SPECIES).map(([species, c]) => ({ ...go(c.name + "房", page, { species }), active: species === current2, locked: !s.rooms[species] }));
var specimen = (s, p, now) => ({
  id: p.id,
  number: number(p),
  name: p.name,
  sex: p.sex,
  breed: breedName(p),
  coat: coatName(p),
  stage: stageOf(p, now),
  status: stageOf(p, now) === "已故" ? p.retained ? "种源保护" : "待回收" : stockStatus(s, p),
  art: petArt(p),
  retained: p.retained === true
});
var petRow = (s, p, now, page = "pet", args = { id: p.id }) => {
  const animal = specimen(s, p, now);
  return link(
    animal.name + " · " + animal.sex,
    [animal.breed, animal.coat, animal.stage, animal.status].join(" · "),
    page,
    args,
    { art: animal.art, stage: animal.stage, animal }
  );
};
var describeRemaining = (ms) => ms < 6e4 ? Math.max(1, Math.ceil(ms / 1e3)) + " 秒" : ms < 36e5 ? Math.ceil(ms / 6e4) + " 分钟" : ms < 864e5 ? Math.ceil(ms / 36e5) + " 小时" : Math.ceil(ms / 864e5) + " 天";
var empty = (title, text, page = "rooms") => ({ title, rows: [{ title: text }], actions: [go("查看名册", page)] });
var speciesKey = (a) => a.species && Object.hasOwn(SPECIES, a.species) ? a.species : "rabbit";
function closedRoom(s, species, page, now) {
  const c = SPECIES[species], cost2 = purchasePrice(s, c.roomCost), breed = BREEDS[c.breeds[0]].name;
  const estimate = beijingTime(lifeDates({ species, bornAt: now }).adultAt).slice(0, 16);
  const balance = s.coins - cost2;
  return {
    title: c.name + "房 · 待开放",
    art: "rooms/unfinished-room",
    subtitle: "新房套餐",
    presentation: { kind: "locked", species: c.name, youngArt: "pets/" + c.breeds[0] + "-coat01_female", maturity: c.young + c.growth, estimate, breed, price: cost2, coins: s.coins },
    rows: [
      { title: breed + "幼体一对", text: "公母各一只，六维 B，入住房间后开始成长。" },
      { title: "房间及两只种源", text: "基准 " + c.roomCost + " 金币 · 实付 " + cost2 + " 金币 · 余额 " + s.coins }
    ],
    tabs: options(s, page, species),
    actions: page === "rooms" ? [{ ...act("解锁" + c.name + "房", "care.unlock", { species, price: cost2 }, "支付 " + cost2 + " 金币开放" + c.name + "房，接收一公一母两只" + breed + "幼体？付款后余 " + Math.max(0, balance) + " 金币，若现在入住，预计北京时间 " + estimate + " 成年。", "roomReceipt", { species }), disabled: balance < 0 }] : [go("查看" + c.name + "房", "rooms", { species })]
  };
}
function openingReceipt(s, species) {
  const receipt = s.rooms[species]?.openingReceipt;
  if (!receipt) return empty("新房入住记录", "这份经营档没有保存该次入住的明细。", "rooms");
  return {
    title: SPECIES[species].name + "房入住回执",
    subtitle: "新房已开放 · 北京时间",
    rows: [
      ...receipt.pair.map((p) => ({
        title: p.sex + " · " + p.name + " #" + number(p),
        text: BREEDS[p.breedKey].name + " · " + coatName(p) + " · 入住时为幼体"
      })),
      { title: "出生及入住", text: beijingTime(receipt.bornAt) },
      { title: "成年时刻", text: beijingTime(receipt.adultAt) },
      { title: "本次实付", text: receipt.paid + " 金币 · 成交后余额 " + receipt.balance + " 金币" }
    ],
    actions: [{ label: "查看本房名册", type: "ui.back" }]
  };
}
function roster(s, a, now) {
  const species = speciesKey(a), cfg = SPECIES[species], room = s.rooms[species];
  if (!room) return closedRoom(s, species, "rooms", now);
  const all = s.pets.filter((p) => p.species === species);
  const filter = rosterFilter(a.filter);
  const stage = rosterStage(a.stage, a.filter);
  const shown = [];
  let nextStageAt = null;
  for (const p of all) {
    const end = stageEnd(p, now);
    if (end !== null && (nextStageAt === null || end < nextStageAt)) nextStageAt = end;
    if (stage !== "全部" && stageOf(p, now) !== stage || !rosterFilters[filter](s, p, now)) continue;
    const row = petRow(s, p, now);
    row.animal.stageEndsAt = end;
    shown.push(row);
  }
  const residents = shown.slice(0, 10).map((row) => row.animal);
  return {
    title: "动物房间",
    art: cfg.art,
    animals: residents.map((p) => p.art),
    animalStages: residents.map((p) => p.stage),
    presentation: { kind: "rooms", species: cfg.name, count: all.length, matchedCount: shown.length, residents, nextStageAt },
    subtitle: "名册 " + shown.length + " 只 · " + filter + " · " + stage,
    rows: [
      link(room.job ? "查看正在繁育的一窝" : "进入繁育台", room.job ? "预计 " + describeRemaining(room.job.endsAt - now) + " 后出生" : "挑选亲本，查看幼体的缺陷率和完美无缺率", "breed", { species }),
      ...room.lastLitter ? [link("最近出生的一窝", room.lastLitter.ids.length + " 只", "litter", { species })] : [],
      ...room.openingReceipt ? [link("查看入住回执", "购房时的两只幼体、成年时刻与余款", "roomReceipt", { species })] : [],
      ...shown,
      ...!shown.length ? [{ title: "当前筛选下没有动物。" }] : []
    ],
    tabs: options(s, "rooms", species),
    filters: [
      Object.keys(rosterFilters).map((v) => ({ ...go(v, "rooms", { species, filter: v, stage }), active: v === filter })),
      ["全部", ...stageNames].map((v) => ({ ...go(v, "rooms", { species, filter, stage: v }), active: v === stage }))
    ]
  };
}
function checkin(s, now) {
  const signed = s.care.signedDay === dayAt(now);
  const rows = [{ title: "今日后备种源", text: "原色幼兔一公一母，栗野花色，六维均为 B。每天北京时间零点更新。" }];
  if (signed) rows.push(...s.pets.filter((p) => s.care.claimIds.includes(p.id)).map((p) => petRow(s, p, now)));
  return {
    title: "每日签到",
    art: "shop-modules/checkin",
    subtitle: signed ? "今日已领取" : "今日可领取",
    rows,
    presentation: { kind: "checkin", date: dayAt(now), signed },
    actions: [...signed ? [] : [act("领养两只幼兔", "care.checkin", {}, void 0, "profile")], go("查看兔房名册", "rooms", { species: "rabbit" })]
  };
}
function ageDescription(ms) {
  const minutes = Math.max(0, Math.floor(ms / 6e4));
  if (!minutes) return "不足 1 分钟";
  const days = Math.floor(minutes / 1440), hours = Math.floor(minutes / 60) % 24;
  return [days && days + " 天", hours && hours + " 小时", minutes % 60 && minutes % 60 + " 分钟"].filter(Boolean).join(" ");
}
function priceRows(s, p, now) {
  const v = valuation(s, p, now), dead = v.stage === "已故";
  const total = salePrice(s, p, now, dead ? "recycle" : "market");
  const terms = [
    { title: "品种和品质", text: "品种基价 " + v.base + " 金币 · 六维及标签折算品质系数约 " + Number((v.qualityUnits / 600).toFixed(4)) },
    { title: "荣誉加价", text: v.honor + " 金币 · 取该动物历来最高荣誉" },
    { title: "店铺加成", text: "成交额 +" + Number(((v.multiplier - 1e4) / 100).toFixed(2)) + "%" }
  ];
  if (dead) terms.splice(1, 0, { title: "已故回收", text: "保底 " + v.minimum + " 金币" + (v.honor ? "，成年估值 " + v.adult + " 的 10% 加荣誉的 50%，取整后与保底取高。" : "，本只按保底回收。") });
  else terms.splice(1, 0, { title: "阶段与繁育", text: v.stage + "按 " + v.stagePercent + "% 估值 " + v.value + " 金币。" + (p.bred ? "已繁育保留 " + v.bredRate + "%，计 " + v.retained + " 金币（保底 " + v.minimum + "）。" : "未繁育，计 " + v.retained + " 金币。") });
  terms.push({ title: dead ? "当前回收估值" : "当前市场估值", text: total + " 金币" + (p.retained ? " · 已留种保护" : isBusy(s, p) ? " · 繁育中" : "") });
  return terms;
}
function detail(s, a, now) {
  const p = s.pets.find((p2) => p2.id === a.id);
  if (!p) return empty("动物档案", "这只动物已离店。");
  const stage = stageOf(p, now), until = stageEnd(p, now), dates = lifeDates(p);
  const history = p.reviewHistory ?? [], unrecorded = p.reviews - history.length;
  return {
    title: "个体档案",
    art: petArt(p),
    stage,
    subtitle: breedName(p) + " · " + coatName(p) + " · " + p.sex,
    presentation: { kind: "pet", species: SPECIES[p.species].name, speciesKey: p.species, animal: specimen(s, p, now), traits: p.traits },
    rows: [
      { title: stage + " · " + stockStatus(s, p), text: until ? "距离下一阶段约 " + describeRemaining(until - now) : p.retained ? "取消留种后可交给研究所回收。" : "已故个体可由研究所回收。" },
      { title: "身份 #" + number(p), text: p.source + (p.motherId ? " · 母 " + p.motherName + " / 父 " + p.fatherName : "") + (p.mixed ? " · 外形 " + BREEDS[p.breedKey].name : "") },
      ...p.traits.map((t) => ({ title: t.type + " · " + t.grade, text: t.label + " · " + t.rarity })),
      { title: "复评 " + p.reviews + " / 3 次", text: "已获最高荣誉系数 " + p.honor },
      { title: stage === "已故" ? "寿终时年龄" : "实际年龄", text: ageDescription(Math.min(now, dates.deathAt) - p.bornAt) },
      { title: "出生时刻", text: beijingTime(p.bornAt) + "（北京）" },
      { title: "成年时刻", text: beijingTime(dates.adultAt) + "（北京）" },
      ...stage === "已故" ? [{ title: "自然寿终", text: beijingTime(dates.deathAt) + "（北京）" }] : [],
      ...priceRows(s, p, now),
      ...unrecorded > 0 ? [{ title: "早期复评", text: "此前 " + unrecorded + " 次复评仅留有次数。" }] : [],
      ...history.map((h) => ({ title: fields[h.field] + "复评", text: beijingTime(h.at) + "（北京） · " + h.before + "（" + h.beforeRarity + "） → " + h.after + "（" + h.afterRarity + "） · 评分 " + h.grade }))
    ],
    actions: [
      ...stage !== "已故" || p.retained ? [{ label: p.retained ? "取消留种" : "留种", type: "care.retain", args: { id: p.id, retained: !p.retained } }] : [],
      ...canBreed(s, p, now) ? [go("去繁育台配对", "breed", { species: p.species, [p.sex === "公" ? "father" : "mother"]: p.id })] : [],
      ...!isBusy(s, p) && stage !== "已故" ? [go("特征复评", "review", { species: p.species, id: p.id })] : [],
      ...!isBusy(s, p) && !p.retained ? [stage === "已故" ? go("前往研究所回收", "recycle", { species: p.species, preselectId: p.id }) : go("前往自由市场", "market", { preselectId: p.id })] : []
    ]
  };
}
function offspringRateRow({ defectPercent, perfectPercent, obviousPercent, mildPercent }) {
  const percent2 = (value) => Number(value.toFixed(2)) + "%";
  return {
    rateSummary: true,
    title: "每只幼体的出生概率",
    text: "缺陷率 " + percent2(defectPercent) + " · 完美无缺率 " + percent2(perfectPercent) + "\n明显缺陷 " + percent2(obviousPercent) + " · 轻微缺陷 " + percent2(mildPercent)
  };
}
function pairPage(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room) return closedRoom(s, species, "breed", now);
  if (room.job) return {
    title: "繁育台",
    art: cfg.art,
    subtitle: "繁育进行中",
    presentation: {
      kind: "breeding",
      species: cfg.name,
      endsAt: room.job.endsAt,
      remaining: room.job.endsAt - now,
      parents: [room.job.mother, room.job.father].map((p) => specimen(s, p, now))
    },
    rows: [{ title: room.job.mother.name + " × " + room.job.father.name, text: "预计 " + describeRemaining(room.job.endsAt - now) + " 后出生。离开店铺也会继续计时。" }],
    tabs: options(s, "breed", species),
    actions: [go("前往动物房间", "rooms", { species })]
  };
  const choices = s.pets.filter((p) => p.species === species && canBreed(s, p, now));
  const mother = choices.find((p) => p.id === a.mother && p.sex === "母"), father = choices.find((p) => p.id === a.father && p.sex === "公");
  const args = { species, ...mother ? { mother: mother.id } : {}, ...father ? { father: father.id } : {} };
  const allowed = mother && father ? fields.slice(0, 5).map((_, i) => i).filter((i) => mother.traits[i].grade !== father.traits[i].grade) : [];
  const guide = allowed.includes(a.guide) && room.items.guide > 0 ? a.guide : -1;
  const [rare = 0, mutation = 0] = s.research?.[species] ?? [];
  const preview = mother && father ? mutationPreview(mother, father, guide, mutation, !!room.mutationEnabled) : void 0;
  if (!mother || !father || a.picking) {
    const sex = !mother ? "母" : "公", pool = choices.filter((p) => p.sex === sex);
    return {
      title: "繁育台",
      art: "shop-modules/breeding-guide",
      subtitle: "挑选一公一母 · 目前可配 " + choices.length + " 只",
      presentation: {
        kind: "pair",
        species: cfg.name,
        wait: cfg.wait,
        parents: [mother, father].map((p) => p ? specimen(s, p, now) : null),
        mutationPreview: preview,
        candidates: choices.map((p) => specimen(s, p, now)),
        confirm: mother && father ? go("核对亲本", "breed", args) : null
      },
      rows: [
        ...preview ? [offspringRateRow(preview.defect)] : [],
        { title: mother ? "母本：" + mother.name : father ? "父本：" + father.name : "选择亲本", text: "点选一只可配的" + sex + "性作为" + (sex === "母" ? "母本" : "父本") + "。" },
        ...pool.map((p) => petRow(s, p, now, "breed", { ...args, [sex === "母" ? "mother" : "father"]: p.id })),
        ...!pool.length ? [{ title: "暂无合适的" + sex + "性亲本", text: "成年、老年且未繁育的空闲动物可参与配对。" }] : []
      ],
      tabs: options(s, "breed", species),
      actions: [...room.lastLitter ? [go("查看最近一窝", "litter", { species })] : [], go("查看房间", "rooms", { species })]
    };
  }
  const motherLook = BREEDS[mother.breedKey].name, fatherLook = BREEDS[father.breedKey].name;
  const registration = mixedOffspring(mother, father) ? "杂交" : motherLook;
  const appearance = mother.breedKey === father.breedKey ? "幼体都是" + motherLook + "外形。" : "每只幼体独立决定外形，" + motherLook + "和" + fatherLook + "各占 50%。";
  return {
    title: "确认配对",
    subtitle: mother.name + " × " + father.name,
    art: cfg.art,
    animals: [petArt(mother), petArt(father)],
    animalStages: [stageOf(mother, now), stageOf(father, now)],
    presentation: {
      kind: "pairConfirm",
      species: cfg.name,
      wait: cfg.wait,
      parents: [mother, father].map((p) => specimen(s, p, now)),
      guide: { count: room.items.guide, index: guide },
      mutationPreview: preview
    },
    rows: [
      { title: "后代登记品种 · " + registration, text: appearance },
      offspringRateRow(preview.defect),
      { title: "一生仅一次繁育", text: "开始后不可取消或换亲本。等待 " + cfg.wait + " 分钟，预计 " + cfg.min + "–" + (cfg.min + cfg.litter.length - 1) + " 只。" },
      ...fields.map((field, i) => {
        const m = mother.traits[i], f = father.traits[i];
        const gap = i < 5 ? " · 相差 " + Math.abs(GRADES.indexOf(m.grade) - GRADES.indexOf(f.grade)) + " 档" : "";
        return { title: field, text: "母 " + m.grade + " " + m.label + "　父 " + f.grade + " " + f.label + gap };
      }),
      { title: "出生研究加成", text: "重抽稀有率 +" + rare * 5 + "% · 五维升档率 +" + (room.mutationEnabled ? mutation * 3 : 0) + "%（相对基础）" },
      { title: "选育指导单 " + room.items.guide + " 张", text: guide >= 0 ? "已选「" + fields[guide] + "」。每只幼体有 80% 的机会从较高分起算，20% 从较低分起算，之后仍可能升降。若比赛目标较低，指导可能让幼体离目标更远。" : "从前五项选一项父母评分不同的特征，让这一窝幼体更容易随分数高的一方。" }
    ],
    actions: [
      act("开始繁育", "care.breed", { ...args, guide }, "确认让 " + mother.name + " 和 " + father.name + " 使用一生唯一的繁育机会？" + (mother.retained || father.retained ? "幼体出生时，双亲自动取消留种。" : "") + (guide >= 0 ? "将使用一张选育指导单。若目标偏低，按高分选育可能更难匹配。" : ""), "breed", { species }),
      go("修改亲本", "breed", { ...args, picking: true }),
      act(room.mutationEnabled ? "关闭五维加成" : "启用五维加成", "care.toggle", { species, enabled: !room.mutationEnabled }, void 0, "breed", { ...args, guide }),
      ...[-1, ...room.items.guide > 0 ? allowed : []].map((i) => ({
        ...go(i === -1 ? "不使用指导单" : "指导" + fields[i], "breed", { ...args, guide: i }),
        active: i === guide,
        replace: true
      }))
    ]
  };
}
function litterParents(s, litter2, children, now) {
  const child = children[0];
  const parents = litter2.parents ?? [
    { id: child?.motherId, name: litter2.mother, sex: "母" },
    { id: child?.fatherId, name: litter2.father, sex: "公" }
  ];
  return parents.map((parent) => {
    const resident = parent.id && s.pets.find((p) => p.id === parent.id);
    const record = resident || (Number.isFinite(parent.bornAt) ? parent : null);
    const whenBorn = record ? stageOf(record, litter2.bornAt) === "已故" ? "本窝出生时已自然寿终。" : "本窝出生时仍在世，已完成一生唯一的一窝。" : "旧记录未保存出生当刻的生命状态。";
    let current2 = "";
    if (resident) current2 = stageOf(resident, now) === "已故" ? "自然寿终于 " + beijingTime(lifeDates(resident).deathAt) + "（北京）。" : "目前仍在房内，已繁育。";
    else if (parent.id) {
      const sale = s.sales?.find((entry) => entry.lines.some((line) => line.id === parent.id));
      if (sale) current2 = beijingTime(sale.at) + (sale.channel === "recycle" ? " 已由研究所回收。" : " 已出售离店。");
    }
    return { title: (parent.sex === "母" ? "母本" : "父本") + " · " + parent.name, text: whenBorn + current2 };
  });
}
function litter(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], l = room?.lastLitter;
  if (!l) return empty("出生记录", "这间房还没有出生记录。");
  const residents = new Map(s.pets.map((p) => [p.id, p]));
  const birthRecords = new Map((l.children ?? []).map((p) => [p.id, p]));
  const missing = new Set(l.ids.filter((id) => !residents.has(id) && !birthRecords.has(id)));
  const historicalNames = /* @__PURE__ */ new Map();
  if (missing.size) {
    for (const { pet } of Object.values(s.show?.entries ?? {})) {
      if (!missing.has(pet?.id)) continue;
      if (pet.name) historicalNames.set(pet.id, pet.name);
      if (SPECIES[species].breeds.includes(pet.breedKey) && BREEDS[pet.breedKey].coats[pet.coatIndex - 1] && ["公", "母"].includes(pet.sex)) birthRecords.set(pet.id, pet);
    }
    for (const sale of s.sales ?? []) for (const line of sale.lines) if (missing.has(line.id) && line.name) historicalNames.set(line.id, line.name);
  }
  const children = l.ids.map((id) => {
    const current2 = residents.get(id);
    if (current2) return { ...petRow(s, current2, now), litterMember: true };
    const p = birthRecords.get(id), tag = "#" + number({ id });
    if (!p) return { litterMember: true, title: (historicalNames.get(id) || "同窝幼体") + " · " + tag, text: "已离店 · 早期记录未保存外观" };
    const animal = { id, number: number(p), name: p.name, sex: p.sex, breed: breedName(p), coat: coatName(p), stage: "幼年", status: "已离店", art: petArt(p), departed: true };
    return { litterMember: true, title: p.name + " · " + p.sex, text: [animal.breed, animal.coat, tag, "已离店 · 出生时外观"].join(" · "), animal, art: animal.art, stage: animal.stage };
  });
  const portraits = children.filter((row) => row.art);
  return {
    title: "这一窝出生了",
    subtitle: l.mother + " × " + l.father + " · 共 " + l.ids.length + " 只",
    presentation: { kind: "litter", species: SPECIES[species].name, count: l.ids.length, bornAt: l.bornAt },
    art: SPECIES[species].art,
    animals: portraits.map((row) => row.art),
    animalStages: portraits.map((row) => row.stage),
    rows: [
      { title: "本窝出生", text: beijingTime(l.bornAt) + "（北京时间） · 共 " + l.ids.length + " 只" },
      ...litterParents(s, l, l.ids.map((id) => residents.get(id)).filter(Boolean), now),
      ...children
    ],
    actions: [go("挑选留种", "litterKeep", { species, bornAt: l.bornAt }), go("前往动物房间", "rooms", { species })]
  };
}
function litterSelection(s, page, a, now) {
  const species = speciesKey(a), latest = s.rooms[species]?.lastLitter;
  if (!latest || latest.bornAt !== a.bornAt) {
    return { title: "出生记录已更新", rows: [{ title: "请重新打开这间房的出生记录。" }], actions: [go("查看出生记录", "litter", { species })] };
  }
  const members = litterMembers(s, latest, now), eligible2 = members.filter((p) => !p.retained);
  const identity = { species, bornAt: latest.bornAt };
  if (page === "litterKeep") {
    return {
      title: "挑选留种",
      subtitle: "已有种源自动保留。勾选本次留种的动物，其余进入出售核价。",
      selectionLabel: "留养",
      rows: members.map((p) => ({ ...petRow(s, p, now), ...!p.retained && { select: p.id } })),
      empty: "这一窝当前没有可出售的动物。",
      actions: eligible2.length ? [{
        ...go("核对其余动物售价", "litterSale", { ...identity, offered: eligible2.map((p) => p.id) }),
        useSelection: true,
        allowEmptySelection: true
      }] : [go("查看出生记录", "litter", { species })]
    };
  }
  const candidates = new Set(eligible2.map((p) => p.id));
  if (!Array.isArray(a.offered) || a.offered.length !== candidates.size || new Set(a.offered).size !== candidates.size || !a.offered.every((id) => candidates.has(id)) || !Array.isArray(a.ids) || new Set(a.ids).size !== a.ids.length || !a.ids.every((id) => candidates.has(id))) {
    return { title: "本窝名册已变化", rows: [{ title: "请重新勾选要留养的动物。" }], actions: [go("重新挑选", "litterKeep", identity)] };
  }
  const keep = new Set(a.ids);
  const sell = eligible2.filter((p) => !keep.has(p.id)).map((p) => p.id);
  const decision = { ...identity, keepIds: a.ids }, keptCount = members.length - sell.length;
  if (!sell.length) return {
    title: "整窝留种",
    subtitle: "本次出售 0 只",
    rows: [{ title: "留下 " + keptCount + " 只动物", text: "确认后显示「种源」标签。" }],
    actions: [...keep.size ? [{ label: "确认留种", type: "care.keepLitter", args: decision }] : [], { label: "修改选择", type: "ui.editSelection" }]
  };
  const quote = businessPage(s, "saleQuote", { channel: "market", ids: sell }, now);
  quote.subtitle = "留养 " + keptCount + " 只 · " + quote.subtitle;
  quote.actions = quote.actions.map((action2) => action2.type === "sale.commit" ? { ...action2, args: { ...action2.args, litterRetention: decision } } : action2);
  return quote;
}
function shelves(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room) return closedRoom(s, species, "shelf", now);
  return {
    title: cfg.name + "种源货架",
    art: "shop-modules/lab",
    subtitle: "本批剩余 " + describeRemaining(room.openedAt + (room.shelf.number + 1) * 18e5 - now),
    rows: room.shelf.offers.map((p, i) => p ? link(
      p.name + " · " + p.sex,
      breedName(p) + " · " + coatName(p) + " · " + purchasePrice(s, youngPurchaseBase(p)) + " 金币",
      "offer",
      { species, id: p.id },
      { art: petArt(p), stage: "幼年" }
    ) : { title: (i === 0 ? "公" : "母") + "幼体 · 本批已售", text: "本批不再补货。下一批的品种和标签随机。" }),
    tabs: options(s, "shelf", species)
  };
}
function offerPage(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], p = room?.shelf.offers.find((x) => x?.id === a.id);
  if (!p) return { title: "种源货位", rows: [{ title: "该幼体已经售出或换批。" }], actions: [go("查看本批货架", "shelf", { species })] };
  const base = youngPurchaseBase(p), price = purchasePrice(s, base);
  return {
    title: p.name + " · " + p.sex,
    subtitle: breedName(p) + " · " + coatName(p) + " · 幼年",
    art: petArt(p),
    stage: "幼年",
    rows: [
      { title: "采购报价", text: "基准 " + base + " · 实付 " + price + " 金币" },
      ...offerOrderRows(s, p, now),
      { title: "估价有效条件", text: "按当前店铺评分、订单和幼体状态估算。成长、获奖或订单变化后，交付时会重新核价。" },
      ...p.traits.map((t) => ({ title: t.type + " · " + t.grade, text: t.label + " · " + t.rarity }))
    ],
    actions: [act("购买幼体", "care.buyPet", { species, id: p.id, batch: room.shelf.number, price }, "支付 " + price + " 金币购买 " + p.name + "？", "shelf", { species })]
  };
}
function services(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room) return closedRoom(s, species, "services", now);
  return {
    title: cfg.name + "用服务单",
    art: "shop-modules/lab",
    rows: Object.keys(itemName).map((item) => {
      const price = purchasePrice(s, cfg[item]);
      const effect = item === "review" ? "选一项特征重新抽标签。可能抽回原词或降稀有度，仍消耗一次，评分不变。每只动物最多用 3 张。" : "从前五项选一项父母评分不同的特征。每只幼体有 80% 的机会按高分起算。若比赛目标较低，可能更难匹配。";
      return {
        title: itemName[item] + " · 持有 " + room.items[item] + " 张",
        text: effect + "\n每张 " + price + " 金币" + (price === cfg[item] ? "" : "（原价 " + cfg[item] + " 金币）")
      };
    }),
    tabs: options(s, "services", species),
    actions: [
      ...Object.keys(itemName).map((item) => {
        const price = purchasePrice(s, cfg[item]);
        return act(
          "购买" + itemName[item],
          "care.buyItem",
          { species, item, price },
          "购买一张" + cfg.name + "用" + itemName[item] + "？基准 " + cfg[item] + " 金币，实付 " + price + " 金币。",
          "services",
          { species }
        );
      }),
      go("选择动物复评", "review", { species }),
      go("前往繁育台", "breed", { species })
    ]
  };
}
function review(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species];
  if (!room) return closedRoom(s, species, "review", now);
  const animals2 = s.pets.filter((p2) => p2.species === species && stageOf(p2, now) !== "已故" && !isBusy(s, p2) && p2.reviews < 3);
  const p = animals2.find((p2) => p2.id === a.id);
  if (!p) return {
    title: "选择复评动物",
    subtitle: SPECIES[species].name + "用复评单 " + room.items.review + " 张",
    rows: animals2.map((p2) => petRow(s, p2, now, "review", { species, id: p2.id })),
    empty: "没有符合条件的动物。",
    actions: [go("购入服务单", "services", { species })]
  };
  return {
    title: p.name + " · 特征复评",
    art: petArt(p),
    stage: stageOf(p, now),
    subtitle: "剩余次数 " + (3 - p.reviews) + " · 持有 " + room.items.review + " 张",
    rows: [
      { title: "想换哪项特征？", text: "普通、少见、稀有的机会分别是 70%、20%、10%。新标签直接替换原标签，评分不变。即使同词或稀有度降低，也消耗一张单和一次额度，无法选回。" },
      ...p.traits.slice(0, 5).map((t, i) => ({
        title: t.type + " · " + t.label,
        text: t.rarity + " · " + t.grade,
        ...room.items.review ? { action: { type: "care.review", args: { species, id: p.id, field: i }, confirm: "给「" + p.name + "」重抽" + t.type + "标签「" + t.label + "」？同词或降档也消耗 1 张单和 1 次额度，无法选回。评分仍是 " + t.grade + "。", go: "pet", goArgs: { id: p.id } } } : {}
      }))
    ],
    actions: [go("购入服务单", "services", { species }), go("查看档案", "pet", { id: p.id })]
  };
}
function carePage(s, page, args = {}, now) {
  switch (page) {
    case "roomReceipt":
      return openingReceipt(s, speciesKey(args));
    case "rooms":
    case "roomRoster":
      return roster(s, args, now);
    case "profile":
      return checkin(s, now);
    case "pet":
      return detail(s, args, now);
    case "breed":
      return pairPage(s, args, now);
    case "litter":
      return litter(s, args, now);
    case "litterKeep":
    case "litterSale":
      return litterSelection(s, page, args, now);
    case "shelf":
      return shelves(s, args, now);
    case "offer":
      return offerPage(s, args, now);
    case "services":
      return services(s, args, now);
    case "review":
      return review(s, args, now);
    default:
      return null;
  }
}
var MINUTE = 6e4;
var DAY = 24 * 60 * MINUTE;
var BATCH = 30 * MINUTE;
var SPECIES = {
  rabbit: { name: "兔", breeds: ["domestic", "lop", "angora", "lionhead"], young: 12, growth: 18, adult: 3, old: 1, wait: 2, min: 3, litter: [25, 50, 25], roomCost: 0, review: 40, guide: 250, art: "shop-modules/rabbit-room" },
  cat: { name: "猫", breeds: ["british", "american", "persian", "maine"], young: 30, growth: 60, adult: 4, old: 2, wait: 7, min: 2, litter: [20, 55, 25], roomCost: 3e3, review: 300, guide: 350, art: "rooms/cat-room" },
  dog: { name: "狗", breeds: ["shiba", "corgi", "poodle", "dachshund"], young: 40, growth: 80, adult: 5, old: 2, wait: 10, min: 2, litter: [15, 35, 35, 15], roomCost: 2e4, review: 330, guide: 400, art: "rooms/dog-room" }
};
var BREEDS = {};
var catalog = {
  domestic: ["原色兔", "栗野 灰野 黑白花斑 橘白花斑 纯黑 雪白"],
  lop: ["垂耳兔", "奶油 蓝灰 巧克力 纯白 黑白花斑 焦糖白花斑"],
  angora: ["安哥拉兔", "雪白 奶油 蓝灰 巧克力 橘黄 黑白花斑"],
  lionhead: ["狮子兔", "金黄 黑色 灰白 巧克力 奶油 黑白花斑"],
  british: ["英国短毛猫", "蓝灰 乳白 黑白双色 金渐层 银虎斑 巧克力"],
  american: ["美国短毛猫", "银虎斑 棕虎斑 橘虎斑 黑白双色 纯白 纯黑"],
  persian: ["波斯猫", "纯白 炭黑 奶油 蓝灰 橘虎斑 海豹重点"],
  maine: ["缅因猫", "棕虎斑 银虎斑 橘白 黑烟 纯白 蓝灰白"],
  shiba: ["柴犬", "赤色 黑褐 奶油白 赤胡麻 黑胡麻 白底赤斑"],
  corgi: ["柯基犬", "黄白 赤白 貂色 黑头三色 虎斑白 蓝陨石"],
  poodle: ["贵宾犬", "黑色 白色 杏色 巧克力 银灰 黑白花"],
  dachshund: ["腊肠犬", "赤棕 黑褐 巧克力褐 银灰陨石 虎斑 红白花"]
};
for (const [species, config] of Object.entries(SPECIES)) {
  config.breeds.forEach((key, index) => {
    BREEDS[key] = { species, name: catalog[key][0], coats: catalog[key][1].split(" "), tier: index + 1 };
  });
}
var TRAITS = [
  [["温顺", "好奇", "亲人"], ["沉稳", "大胆"], ["从容"]],
  [["圆眼", "清秀"], ["秀眉", "眼神明亮"], ["眼神灵动"]],
  [["柔软", "顺毛"], ["细密", "绒感"], ["丝光", "绒光"]],
  [["匀称", "舒展"], ["步态轻盈", "站姿端正"], ["仪态出众"]],
  [["紧凑", "修长"], ["骨架匀整", "轮廓流畅"], ["比例匀美"]]
];
var breedingFields = ["性格", "品相", "毛发", "体态", "体型"];
var fields = [...breedingFields, "缺陷"];
var rarities = ["普通", "少见", "稀有"];
var coatWeights = [25, 25, 18, 14, 10, 8];
var dayAt = (t) => new Date(t + 8 * 60 * MINUTE).toISOString().slice(0, 10);
var itemName = { review: "特征复评单", guide: "选育指导单" };
var sample = (list, rnd = Math.random) => list[Math.floor(rnd() * list.length)];
function weighted2(weights, rnd = Math.random) {
  let value = rnd() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < weights.length; i++) if ((value -= weights[i]) < 0) return i;
  return weights.length - 1;
}
function deterministic(key) {
  let sequence = 0;
  return () => createHash2("sha256").update(key + ":" + sequence++).digest().readUInt32LE() / 4294967296;
}
function requireValue2(test, message) {
  if (!test) throw new Error(message);
}
function speciesOf(value) {
  const key = value ?? "rabbit";
  requireValue2(Object.hasOwn(SPECIES, key), "没有这个物种的房间。");
  return key;
}
function roomOf(s, species) {
  const room = s.rooms[speciesOf(species)];
  requireValue2(room, "请先开放对应房间。");
  return room;
}
var stageNames = ["幼年", "成长", "成年", "老年", "已故"];
function lifeDates(p) {
  const cfg = SPECIES[p.species];
  const growthAt = p.bornAt + cfg.young * MINUTE, adultAt = growthAt + cfg.growth * MINUTE;
  const oldAt = adultAt + cfg.adult * DAY;
  return { growthAt, adultAt, oldAt, deathAt: oldAt + cfg.old * DAY };
}
var beijingTime = (ms) => new Date(ms + 8 * 60 * MINUTE).toISOString().slice(0, 19).replace("T", " ");
function ageBand(p, now) {
  const { growthAt, adultAt, oldAt, deathAt } = lifeDates(p);
  const ends = [growthAt, adultAt, oldAt, deathAt];
  const i = ends.findIndex((end) => now < end);
  return i < 0 ? ["已故", null] : [stageNames[i], ends[i]];
}
var stageOf = (p, now) => ageBand(p, now)[0];
var stageEnd = (p, now) => ageBand(p, now)[1];
function isBusy(s, p) {
  const job = s.rooms[p.species]?.job;
  return Boolean(job && (p.id === job.motherId || p.id === job.fatherId));
}
var breedName = (p) => p.mixed ? "杂交" : BREEDS[p.breedKey].name;
var mixedOffspring = (mother, father) => Boolean(mother.mixed || father.mixed || mother.breedKey !== father.breedKey);
var petArt = (p) => "pets/" + p.breedKey + "-coat" + String(p.coatIndex).padStart(2, "0") + "_" + (p.sex === "公" ? "male" : "female");
var coatName = (p) => BREEDS[p.breedKey].coats[p.coatIndex - 1];
var canBreed = (s, p, now) => !p.bred && !isBusy(s, p) && ["成年", "老年"].includes(stageOf(p, now));
var stockStatus = (s, p) => isBusy(s, p) ? "繁育中" : p.bred ? "已繁育" : "未繁育";
var rosterFilters = {
  全部: () => true,
  种源: (_s, p) => p.retained === true,
  未繁育: (s, p, now) => stageOf(p, now) !== "已故" && stockStatus(s, p) === "未繁育"
};
var legacyFilters = { 在养: "全部", 后备种源: "种源", 可配对: "未繁育" };
function rosterFilter(value) {
  if (typeof value !== "string") return "全部";
  if (Object.hasOwn(legacyFilters, value)) return legacyFilters[value];
  return Object.hasOwn(rosterFilters, value) ? value : "全部";
}
function rosterStage(value, filter) {
  if (stageNames.includes(value)) return value;
  return filter === "已故" ? "已故" : "全部";
}
function fixedTraits(first = "温顺") {
  return [first, "清秀", "柔软", "匀称", "紧凑"].map((label, i) => ({ type: fields[i], label, rarity: "普通", grade: "B" })).concat(defectTrait("B"));
}
function makePet(usedNames, species, breedKey, sex, now, source, data = {}) {
  const name = takePetName(usedNames, Math.random(), data.name);
  return {
    id: randomUUID2(),
    species,
    breedKey,
    sex,
    bornAt: now,
    source,
    coatIndex: 1,
    mixed: false,
    bred: false,
    traits: fixedTraits(),
    honor: 0,
    reviews: 0,
    motherId: null,
    fatherId: null,
    ...data,
    name
  };
}
function newRoom(now) {
  return { openedAt: now, job: null, lastLitter: null, shelf: null, items: { review: 0, guide: 0 }, mutationEnabled: true };
}
function rolledTrait(i, rarity, grade, rnd) {
  return { type: fields[i], label: sample(TRAITS[i][rarity], rnd), rarity: rarities[rarity], grade };
}
function shelfBatch(s, species, number2, usedNames) {
  const seed = s.care.seed + ":stock-v1:" + species + ":" + number2;
  const breedKey = SPECIES[species].breeds[weighted2([40, 30, 20, 10], deterministic(seed + ":breed"))];
  const offers = ["公", "母"].map((sex, slot) => {
    const rnd = (field) => deterministic(seed + ":" + slot + ":" + field);
    const rare = rnd("rare")() < 0.1 ? Math.floor(rnd("rare-slot")() * 5) : -1;
    const traits = breedingFields.map((_, i) => {
      const grade = GRADES[weighted2([0, 10, 40, 42, 8, 0, 0], rnd("grade-" + i))];
      return rolledTrait(i, i === rare ? 2 : weighted2([80, 20], rnd("rarity-" + i)), grade, rnd("tag-" + i));
    }).concat(defectTrait("B"));
    const id = createHash2("sha256").update(seed + ":" + slot + ":id").digest("hex").slice(0, 32);
    return { id, name: takePetName(usedNames, rnd("name")()), species, sex, breedKey, mixed: false, coatIndex: 1 + weighted2(coatWeights, rnd("coat")), traits };
  });
  return { number: number2, offers };
}
function initCare(s, now) {
  if (s.care) return;
  s.care = { seed: randomBytes(16).toString("hex"), signedDay: null, claimIds: [], parentRetentionChecked: true, defectGradesUpdated: true };
  s.rooms = { rabbit: newRoom(now) };
  const usedNames = /* @__PURE__ */ new Set();
  s.pets = [
    makePet(usedNames, "rabbit", "angora", "母", now - 30 * MINUTE, "开店种兔", { name: "小花" }),
    makePet(usedNames, "rabbit", "angora", "公", now - 30 * MINUTE, "开店种兔", { name: "小白", coatIndex: 2, traits: fixedTraits("好奇") })
  ];
  tickCare(s, now);
}
function repairLegacyParentRetention(s) {
  const candidates = new Map(s.pets.filter((p) => p.bred === true && p.retained === true && !isBusy(s, p)).map((p) => [p.id, { pet: p, paired: 0, marked: 0 }]));
  if (!candidates.size) return false;
  const parents = /* @__PURE__ */ new Set();
  for (const child of s.pets) {
    if (child.bornAt <= s.clock) {
      parents.add(child.motherId);
      parents.add(child.fatherId);
    }
  }
  for (const room of Object.values(s.rooms)) {
    const litter2 = room?.lastLitter;
    if (litter2?.bornAt <= s.clock) for (const p of litter2.parents || []) parents.add(p.id);
  }
  for (const receipt of Object.values(s.receipts)) {
    const version = receipt?.result?.version;
    if (!Number.isSafeInteger(version) || version < 1 || version > s.version) return false;
    let command;
    try {
      command = JSON.parse(receipt.key);
    } catch {
      return false;
    }
    if (!Array.isArray(command) || command.length !== 2) return false;
    const [type, args] = command;
    if (!args || typeof args !== "object") return false;
    if (type === "care.breed") {
      for (const id of [args.mother, args.father]) {
        const parent = candidates.get(id);
        if (parent) parent.paired = Math.max(parent.paired, version);
      }
    } else {
      let kept;
      if (type === "care.retain" && args.retained === true) kept = [args.id];
      else if (type === "care.keepLitter") kept = args.keepIds;
      else if (type === "sale.commit" && args.litterRetention) kept = args.litterRetention.keepIds;
      else continue;
      if (!Array.isArray(kept)) return false;
      for (const id of kept) {
        const parent = candidates.get(id);
        if (parent) parent.marked = Math.max(parent.marked, version);
      }
    }
  }
  let changed = false;
  for (const [id, { pet, paired, marked }] of candidates) {
    if (parents.has(id) && marked > 0 && marked < paired) {
      pet.retained = false;
      changed = true;
    }
  }
  return changed;
}
function birthIdentity({ id, name, sex, breedKey, coatIndex, mixed }) {
  return { id, name, sex, breedKey, coatIndex, mixed: !!mixed };
}
function tickCare(s, now) {
  let changed = false;
  if (!s.care.defectGradesUpdated) {
    const updateLabel = (pet) => {
      if (pet) pet.traits[5] = defectTrait(pet.traits[5].grade);
    };
    s.pets.forEach(updateLabel);
    for (const room of Object.values(s.rooms)) {
      room.shelf?.offers.forEach(updateLabel);
      if (room.job) {
        updateLabel(room.job.mother);
        updateLabel(room.job.father);
        room.job.offspring.forEach(updateLabel);
      }
    }
    s.care.defectGradesUpdated = true;
    changed = true;
  }
  const refreshes = [];
  for (const [species, room] of Object.entries(s.rooms)) {
    const number2 = Math.max(0, Math.floor((now - room.openedAt) / BATCH));
    if (!room.shelf || number2 > room.shelf.number) refreshes.push({ species, room, number: number2 });
    const job = room.job;
    if (job && now >= job.endsAt) {
      for (const p of s.pets) if (p.id === job.motherId || p.id === job.fatherId) {
        p.bred = true;
        p.retained = false;
      }
      s.pets.push(...job.offspring);
      room.lastLitter = {
        ids: job.offspring.map((p) => p.id),
        children: job.offspring.map(birthIdentity),
        bornAt: job.endsAt,
        mother: job.mother.name,
        father: job.father.name,
        parents: [job.mother, job.father].map(({ id, name, sex, bornAt }) => ({ id, name, sex, bornAt, species }))
      };
      room.job = null;
      changed = true;
    } else if (room.lastLitter && !room.lastLitter.children) {
      const ids = new Set(room.lastLitter.ids);
      room.lastLitter.children = s.pets.filter((p) => ids.has(p.id)).map(birthIdentity);
      changed = true;
    }
  }
  if (refreshes.length) {
    const retiring = refreshes.flatMap(({ room }) => room.shelf?.offers ?? []);
    const usedNames = occupiedPetNames(s, retiring);
    for (const { species, room, number: number2 } of refreshes) room.shelf = shelfBatch(s, species, number2, usedNames);
    changed = true;
  }
  return changed;
}
function gradeBaseline(grades2, guided) {
  return guided ? { first: grades2[0] > grades2[1] ? 0 : 1, chance: 0.8 } : { first: 0, chance: 0.5 };
}
function mutationPreview(mother, father, guide, level, enabled) {
  const defect = defectProbabilities(mother.traits, father.traits);
  return { enabled, level, defect, fields: breedingFields.map((name, i) => {
    const m = mother.traits[i].grade, f = father.traits[i].grade;
    const grades2 = [GRADES.indexOf(m), GRADES.indexOf(f)];
    const { first, chance } = gradeBaseline(grades2, i === guide);
    const a = grades2[first], b = grades2[1 - first];
    const rise = (lv) => Number((100 * (chance * scoreRiseChance(a, b, lv) + (1 - chance) * scoreRiseChance(b, a, lv))).toFixed(3));
    return { name, mother: m, father: f, off: rise(0), on: rise(level) };
  }) };
}
function inherit(mother, father, options2, defect) {
  const traits = breedingFields.map((_, i) => {
    const parents = [mother.traits[i], father.traits[i]];
    const grades2 = parents.map((t) => GRADES.indexOf(t.grade));
    const { first, chance } = gradeBaseline(grades2, i === options2.guide);
    const j = Math.random() < chance ? first : 1 - first;
    const base = grades2[j], ref = grades2[1 - j];
    const up = scoreRiseChance(base, ref, options2.positive);
    const roll = Math.random(), next = base + (roll < up ? 1 : roll < up + 0.1 ? -1 : 0);
    const grade = GRADES[Math.max(0, Math.min(6, Math.max(...grades2) + 1, next))];
    const from = Math.random();
    if (from < 0.8) return { ...parents[from < 0.4 ? 1 : 0], grade };
    const rare = rareRedrawPercent(options2.rare);
    return rolledTrait(i, weighted2([80 - rare, 20, rare]), grade, Math.random);
  });
  traits.push(defectTrait(GRADES[weighted2(defect.gradePercents)]));
  return traits;
}
function startLitter(s, args, now) {
  const species = speciesOf(args.species), room = roomOf(s, species), cfg = SPECIES[species];
  requireValue2(!room.job, "这间房已有一窝正在培育。");
  const mother = s.pets.find((p) => p.id === args.mother), father = s.pets.find((p) => p.id === args.father);
  requireValue2(mother?.species === species && father?.species === species && mother.sex === "母" && father.sex === "公" && canBreed(s, mother, now) && canBreed(s, father, now), "请选择仍在店、可繁育的一公一母成年或老年动物。");
  const guide = args.guide ?? -1;
  requireValue2(Number.isInteger(guide) && guide >= -1 && guide < breedingFields.length, "请选择前五项中有效的指导维度。");
  if (guide >= 0) {
    requireValue2(room.items.guide > 0, "该物种的选育指导单不足。");
    requireValue2(mother.traits[guide].grade !== father.traits[guide].grade, "两只亲本此维评分相同，不能使用指导。");
  }
  const [rare = 0, mutation = 0] = s.research?.[species] ?? [];
  const options2 = { rare, positive: room.mutationEnabled ? mutation : 0, guide };
  const endsAt = now + cfg.wait * MINUTE, n = cfg.min + weighted2(cfg.litter);
  const mixed = mixedOffspring(mother, father);
  const defect = defectProbabilities(mother.traits, father.traits);
  const usedNames = occupiedPetNames(s);
  const offspring = Array.from({ length: n }, () => {
    const look = Math.random() < 0.5 ? mother : father;
    return makePet(usedNames, species, look.breedKey, Math.random() < 0.5 ? "公" : "母", endsAt, "本店繁育", {
      motherId: mother.id,
      fatherId: father.id,
      motherName: mother.name,
      fatherName: father.name,
      mixed,
      coatIndex: Math.random() < 0.85 ? look.coatIndex : weighted2(coatWeights) + 1,
      traits: inherit(mother, father, options2, defect)
    });
  });
  if (guide >= 0) room.items.guide--;
  room.job = { motherId: mother.id, fatherId: father.id, mother: structuredClone(mother), father: structuredClone(father), options: options2, endsAt, offspring };
  return "已开始繁育，预计 " + cfg.wait + " 分钟后出生。";
}
function charge(s, expected, base) {
  const amount = purchasePrice(s, base);
  requireValue2(expected === amount, "报价有变化，请返回重新核对。");
  requireValue2(s.coins >= amount, "金币不足。需要 " + amount + " 金币。");
  s.coins -= amount;
}
function litterMembers(s, litter2, now) {
  const ids = new Set(litter2.ids);
  return s.pets.filter((p) => ids.has(p.id) && !isBusy(s, p) && stageOf(p, now) !== "已故");
}
function retainedLitterPets(s, decision, soldIds, now) {
  const litter2 = s.rooms[decision.species]?.lastLitter;
  requireValue2(litter2 && litter2.bornAt === decision.bornAt, "出生记录已更新，请重新挑选。");
  const eligible2 = litterMembers(s, litter2, now).filter((p) => !p.retained);
  requireValue2(Array.isArray(decision.keepIds) && Array.isArray(soldIds), "本窝选单无效。");
  const all = [...decision.keepIds, ...soldIds], chosen = new Set(all), keep = new Set(decision.keepIds);
  requireValue2(
    chosen.size === all.length && all.length === eligible2.length && eligible2.every((p) => chosen.has(p.id)),
    "本窝名册已变化，请重新挑选。"
  );
  return eligible2.filter((p) => keep.has(p.id));
}
function careAction(s, type, args, now) {
  if (!type.startsWith("care.")) return void 0;
  if (type === "care.retain") {
    const p = s.pets.find((p2) => p2.id === args.id);
    requireValue2(p, "这只动物已离店。");
    requireValue2(typeof args.retained === "boolean", "请选择留种或取消留种。");
    requireValue2(!args.retained || stageOf(p, now) !== "已故", "已故动物无法新留种。");
    p.retained = args.retained;
    return p.name + (p.retained ? "已标记为种源。" : "已取消留种。");
  }
  if (type === "care.keepLitter") {
    const kept = retainedLitterPets(s, args, [], now);
    requireValue2(kept.length > 0, "本窝没有可留种的动物。");
    for (const p of kept) p.retained = true;
    return "本窝 " + kept.length + " 只动物已标记为种源。";
  }
  if (type === "care.checkin") {
    const today = dayAt(now);
    requireValue2(s.care.signedDay !== today, "今天的两只幼兔已领取。");
    const usedNames = occupiedPetNames(s);
    const firstNames = s.care.signedDay == null ? ["谷穗", "小麦"] : [];
    const pair = ["母", "公"].map((sex, i) => makePet(usedNames, "rabbit", "domestic", sex, now, "每日签到", { name: firstNames[i] }));
    s.pets.push(...pair);
    s.care.signedDay = today;
    s.care.claimIds = pair.map((p) => p.id);
    return "已领取两只基础原色幼兔，一公一母。";
  }
  if (type === "care.breed") return startLitter(s, args, now);
  const species = speciesOf(args.species), cfg = SPECIES[species];
  if (type === "care.unlock") {
    requireValue2(!s.rooms[species] && cfg.roomCost > 0, "这间房已经开放。");
    charge(s, args.price, cfg.roomCost);
    const usedNames = occupiedPetNames(s);
    s.rooms[species] = newRoom(now);
    s.rooms[species].shelf = shelfBatch(s, species, 0, usedNames);
    const pair = ["公", "母"].map((sex) => makePet(usedNames, species, cfg.breeds[0], sex, now, "新房种源"));
    s.pets.push(...pair);
    s.rooms[species].openingReceipt = {
      paid: args.price,
      balance: s.coins,
      bornAt: now,
      adultAt: lifeDates(pair[0]).adultAt,
      pair: pair.map(({ id, name, sex, breedKey, coatIndex }) => ({ id, name, sex, breedKey, coatIndex }))
    };
    return cfg.name + "房已开放，两只幼体已入住。";
  }
  const room = roomOf(s, species);
  if (type === "care.buyPet") {
    const index = room.shelf.offers.findIndex((p) => p?.id === args.id);
    requireValue2(index >= 0 && room.shelf.number === args.batch, "货位已售空或批次已更新。");
    const offer = room.shelf.offers[index];
    charge(s, args.price, youngPurchaseBase(offer));
    const pet = makePet(occupiedPetNames(s, [offer]), species, offer.breedKey, offer.sex, now, "研究所采购", offer);
    s.pets.push(pet);
    room.shelf.offers[index] = null;
    if (pet.name !== offer.name) return "原货架名“" + offer.name + "”已被占用，已取名“" + pet.name + "”入住" + cfg.name + "房。";
    return pet.name + "已入住" + cfg.name + "房。";
  }
  if (type === "care.buyItem") {
    requireValue2(Object.hasOwn(itemName, args.item), "没有这张服务单。");
    charge(s, args.price, cfg[args.item]);
    room.items[args.item]++;
    return "已购入" + cfg.name + "用" + itemName[args.item] + "一张。";
  }
  if (type === "care.toggle") {
    requireValue2(typeof args.enabled === "boolean", "请选择开启或关闭。");
    room.mutationEnabled = args.enabled;
    return "下次开始繁育时" + (args.enabled ? "采用" : "关闭") + "五维选育加成。";
  }
  if (type === "care.review") {
    const p = s.pets.find((p2) => p2.id === args.id);
    const i = args.field;
    requireValue2(p?.species === species && stageOf(p, now) !== "已故" && !isBusy(s, p), "请选择在店空闲的活体。");
    requireValue2(Number.isInteger(i) && i >= 0 && i < 5, "只能复评前五栏中的一栏。");
    requireValue2(p.reviews < 3 && room.items.review > 0, "复评次数或服务单不足。");
    const old = p.traits[i];
    p.traits[i] = rolledTrait(i, weighted2([70, 20, 10]), old.grade, Math.random);
    (p.reviewHistory ??= []).push({
      at: now,
      field: i,
      before: old.label,
      after: p.traits[i].label,
      beforeRarity: old.rarity,
      afterRarity: p.traits[i].rarity,
      grade: old.grade
    });
    p.reviews++;
    room.items.review--;
    return fields[i] + "复评结果：" + old.label + " → " + p.traits[i].label + "，评分仍为 " + old.grade + "。";
  }
  return void 0;
}
var show_events_default = [
  { id: "P01", name: "暖阳陪伴赛", targets: ["B", "B", "B", "B", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P02", name: "春日轻盈赛", targets: ["B", "B", "C", "A", "C", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P03", name: "绒毛小憩赛", targets: ["C", "B", "A", "B", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P04", name: "庭院漫步赛", targets: ["A", "C", "B", "A", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P05", name: "小巧玲珑赛", targets: ["B", "A", "B", "C", "C", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P06", name: "清秀初见赛", targets: ["C", "A", "B", "B", "A", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P07", name: "安静午后赛", targets: ["C", "C", "B", "C", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P08", name: "舒展时光赛", targets: ["B", "B", "C", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P09", name: "亲近晨光赛", targets: ["A", "B", "C", "B", "A", "C"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P10", name: "柔绒邀约赛", targets: ["B", "C", "A", "A", "B", "C"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P11", name: "匀美身姿赛", targets: ["C", "A", "C", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P12", name: "朴素风采赛", targets: ["C", "C", "C", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P13", name: "温雅仪态赛", targets: ["A", "A", "B", "S", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P14", name: "月下绒光赛", targets: ["B", "A", "S", "C", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P15", name: "明眸相逢赛", targets: ["A", "S", "C", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P16", name: "流畅轮廓赛", targets: ["C", "B", "A", "B", "S", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P17", name: "从容迎宾赛", targets: ["S", "B", "B", "A", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P18", name: "健朗日常赛", targets: ["B", "C", "A", "C", "B", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P19", name: "均衡新星赛", targets: ["A", "A", "A", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P20", name: "反差风采赛", targets: ["C", "S", "C", "S", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P21", name: "圆融雅集赛", targets: ["S", "C", "A", "B", "S", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P22", name: "绒感典藏赛", targets: ["A", "B", "S", "C", "S", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P23", name: "晨星仪态赛", targets: ["B", "S", "A", "S", "C", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P24", name: "端正风华赛", targets: ["S", "A", "C", "A", "S", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P25", name: "一眼惊鸿赛", targets: ["B", "S+", "A", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P26", name: "丝绒之冠赛", targets: ["C", "B", "S+", "A", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P27", name: "比例之美赛", targets: ["A", "C", "B", "A", "S+", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P28", name: "从容压轴赛", targets: ["S+", "A", "C", "S", "B", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "O01", name: "四季相伴公开赛", targets: ["B", "A", "B", "A", "B", "A"], weights: [20, 20, 15, 15, 10, 20] },
  { id: "O02", name: "春风轻步公开赛", targets: ["C", "B", "A", "S", "C", "A"], weights: [10, 15, 15, 30, 15, 15] },
  { id: "O03", name: "晴窗明眸公开赛", targets: ["A", "S", "C", "B", "A", "B"], weights: [15, 30, 10, 15, 10, 20] },
  { id: "O04", name: "月色柔绒公开赛", targets: ["B", "A", "S", "C", "B", "S"], weights: [10, 15, 30, 10, 15, 20] },
  { id: "O05", name: "庭院轮廓公开赛", targets: ["C", "B", "A", "A", "S", "A"], weights: [10, 15, 15, 20, 25, 15] },
  { id: "O06", name: "从容相逢公开赛", targets: ["S", "C", "B", "A", "A", "S"], weights: [30, 10, 10, 15, 15, 20] },
  { id: "O07", name: "清简风采公开赛", targets: ["C", "C", "A", "B", "C", "A"], weights: [15, 20, 20, 15, 10, 20] },
  { id: "O08", name: "双星仪态公开赛", targets: ["B", "S", "C", "S", "A", "S"], weights: [10, 25, 10, 25, 10, 20] },
  { id: "O09", name: "绒光映月公开赛", targets: ["A", "B", "S+", "C", "S", "A"], weights: [15, 10, 30, 10, 20, 15] },
  { id: "O10", name: "均衡雅集公开赛", targets: ["A", "A", "A", "A", "A", "A"], weights: [20, 15, 20, 15, 10, 20] },
  { id: "O11", name: "风华典藏公开赛", targets: ["S", "C", "A", "S+", "B", "S"], weights: [20, 10, 15, 25, 10, 20] },
  { id: "O12", name: "星辉轮廓公开赛", targets: ["C", "S", "B", "A", "S+", "S"], weights: [10, 20, 10, 20, 25, 15] }
];
var shop_feature_levels_default = {
  featureLevels: {
    rooms: 1,
    login: 1,
    orders: 2,
    show: 4,
    lab: 2,
    market: 1,
    profile: 1,
    breed: 1,
    decor: 8,
    guest: 3,
    collection: 4
  },
  maxLevel: 60,
  levelUpCosts: [10, 10, 10, 30, 40, 50, 70],
  laterCostPerLevel: 10,
  raceOpensDay: { private: 2, public: 3 },
  saleXp: { base: 10, coinsPerBonus: 200, maxBonus: 20 }
};
var featureNames = {
  rooms: "动物房间",
  login: "店主登记簿",
  orders: "普通订单",
  show: "宠物赛展",
  lab: "研究所",
  market: "自由市场",
  profile: "每日签到",
  breed: "繁育台",
  decor: "店铺装饰",
  guest: "特殊来客",
  collection: "奖杯收藏"
};
function featureAccess(rules, level) {
  return Object.fromEntries(Object.keys(featureNames).map((key) => {
    const requiredLevel = rules.featureLevels[key];
    return [key, { name: featureNames[key], requiredLevel, unlocked: level >= requiredLevel }];
  }));
}
var owner = /* @__PURE__ */ new Map();
var sections = {
  rooms: ["roomRoster", "roomReceipt", "pet", "care.unlock", "care.retain"],
  login: ["payment"],
  orders: ["orderDesk", "credits", "order.cancel", "order.buyCredit"],
  lab: [
    "shelf",
    "offer",
    "services",
    "review",
    "recycle",
    "research",
    "researchNode",
    "researchTable",
    "care.buyPet",
    "care.buyItem",
    "care.review",
    "research.upgrade"
  ],
  profile: ["care.checkin"],
  breed: ["litter", "litterKeep", "litterSale", "care.breed", "care.toggle", "care.keepLitter"],
  decor: ["decor.buy", "decor.place"],
  guest: ["guest.dismiss"]
};
for (const [feature, keys] of Object.entries(sections)) {
  for (const key of keys) owner.set(key, feature);
}
var saleFeatures = /* @__PURE__ */ new Map([["market", "market"], ["order", "orders"], ["guest", "guest"], ["recycle", "lab"]]);
function operationFeature(key, args) {
  if (key === "sale" || key === "saleQuote" || key === "sale.commit") return saleFeatures.get(args.channel);
  if (Object.hasOwn(featureNames, key)) return key;
  if (key.startsWith("show.")) return "show";
  if (key.startsWith("collection.")) return "collection";
  return owner.get(key);
}
function shopProgress(rules, totalXp) {
  let level = 1, intoLevel = totalXp;
  while (level < rules.maxLevel) {
    const cost2 = rules.levelUpCosts[level - 1] ?? rules.laterCostPerLevel * level;
    if (intoLevel < cost2) return { level, total: totalXp, intoLevel, toNext: cost2, maxLevel: rules.maxLevel };
    intoLevel -= cost2;
    level++;
  }
  return { level, total: totalXp, intoLevel, toNext: 0, maxLevel: rules.maxLevel };
}
function saleExperience(rules, channel, lines) {
  if (!["market", "order", "guest"].includes(channel)) return 0;
  const { base, coinsPerBonus, maxBonus } = rules.saleXp;
  return lines.reduce((sum, line) => sum + base + Math.min(maxBonus, Math.floor(line.amount / coinsPerBonus)), 0);
}
function shopRaceAccess(rules, createdAt, now) {
  const day2 = 864e5, beijingOffset = 8 * 36e5;
  const openingMidnight = Math.floor((createdAt + beijingOffset) / day2) * day2 - beijingOffset;
  const shopDay = Math.max(1, 1 + Math.floor((now - openingMidnight) / day2));
  const raceAccess = Object.fromEntries(Object.entries(rules.raceOpensDay).map(([mode, opensDay]) => {
    const opensAt = Math.max(createdAt, openingMidnight + (opensDay - 1) * day2);
    return [mode, { opensDay, opensAt, unlocked: now >= opensAt }];
  }));
  return { shopDay, raceAccess };
}
var GAME_EPOCH = Date.parse("2026-11-09T20:00:00+08:00");
var HOUR = 36e5;
var DAY2 = 24 * HOUR;
var WEEK = 7 * DAY2;
var grades = ["E", "D", "C", "B", "A", "S", "S+"];
var dimensions = ["性格", "品相", "毛发", "体态", "体型", "缺陷"];
var animals = { rabbit: "兔", cat: "猫", dog: "狗" };
var speciesPortrait = { rabbit: "pets/angora-coat01_female", cat: "pets/british-coat01_female", dog: "pets/shiba-coat01_male" };
var trophies = { bronze: "铜杯", silver: "银杯", gold: "金杯", memorial: "纪念杯", laurel: "桂冠杯" };
var tiers = { private: ["gold", "silver", "bronze"], public: ["laurel", "gold", "silver", "bronze", "memorial"] };
var points = { private: { bronze: 20, silver: 60, gold: 100 }, public: { memorial: 50, bronze: 100, silver: 200, gold: 400, laurel: 600 } };
var honors = { private: { bronze: 0, silver: 0.4, gold: 0.8 }, public: { memorial: 0, bronze: 0.2, silver: 0.4, gold: 0.6, laurel: 0.8 } };
var dateFormat = new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
var time = (value) => dateFormat.format(value);
var lookup = (records, key) => Object.hasOwn(records, key) ? records[key] : null;
var gradeList = (values) => values.map((g) => grades[g]).join(" / ");
var topicArt = "shop-modules/stage";
var PNAME = { private: "私人赛", public: "本地模拟公开赛" };
var themes = show_events_default.map(({ id, name, targets, weights }) => ({
  id,
  name,
  mode: id[0] === "P" ? "private" : "public",
  targets: targets.map((x) => grades.indexOf(x)),
  weights
}));
var groups = { private: themes.filter((t) => t.mode === "private"), public: themes.filter((t) => t.mode === "public") };
var byTheme = Object.fromEntries(themes.map((t) => [t.id, t]));
function initShow(s, now) {
  s.show ??= { epoch: s.gameEpoch ?? GAME_EPOCH, activePrivate: null, weeks: {}, entries: {}, cups: {} };
  ensureCalendar(s, now);
  s.ratingBps ??= 0;
}
function ensureCalendar(s, now) {
  if (s.show.calendar) return;
  const openedAt = Number.isFinite(s.createdAt) ? s.createdAt : null;
  let first = openedAt === null ? null : Math.max(0, Math.ceil((openedAt - s.show.epoch - 5 * DAY2) / WEEK));
  if (openedAt === null) for (const w of Object.values(s.show.weeks)) {
    if (Number.isSafeInteger(w.index) && w.index >= 0) first = first === null ? w.index : Math.min(first, w.index);
  }
  first ??= Math.max(0, Math.floor(((now ?? s.show.epoch) - s.show.epoch) / WEEK));
  s.show.calendar = { version: 1, firstWeek: first, themes: structuredClone(groups.public) };
}
function roundStart(s, mode, index) {
  return s.show.epoch + index * (mode === "public" ? WEEK : DAY2);
}
function period(s, mode, now) {
  const index = Math.floor((now - s.show.epoch) / (mode === "public" ? WEEK : DAY2));
  if (index < 0) return null;
  const start = roundStart(s, mode, index);
  return { id: mode + "-" + index, index, start, close: start + (mode === "public" ? 94 : 22) * HOUR, result: start + (mode === "public" ? 5 * DAY2 : DAY2), payout: mode === "public" ? start + 6 * DAY2 : null };
}
function digest(key, ...fields2) {
  return createHmac("sha256", key).update(JSON.stringify(fields2), "utf8").digest();
}
function offset(key, profile, event, species, bot, dim) {
  for (let counter = 0; ; counter++) {
    const value = digest(key, 1, "bot_score_v1", profile, event, species, bot, dim, counter).readUInt32BE();
    if (value >= 4294967200) continue;
    const n = value % 100;
    return n < 5 ? -3 : n < 15 ? -2 : n < 35 ? -1 : n < 65 ? 0 : n < 85 ? 1 : n < 95 ? 2 : 3;
  }
}
function publicTheme(s, index) {
  const cycle = s.show.calendar.themes;
  return cycle[index % cycle.length];
}
function makeWeek(s, round, kinds = Object.keys(animals)) {
  const theme = structuredClone(publicTheme(s, round.index)), key = Buffer.from(s.rootSeed, "hex");
  const bots = {};
  for (const kind of kinds) {
    bots[kind] = Array.from({ length: 99 }, (_, i) => theme.targets.map((target, dim) => Math.max(0, Math.min(6, target + offset(key, s.profileId, round.id, kind, i + 1, dim)))));
  }
  const seed = digest(key, 1, "tie_seed_v1", s.profileId, round.id, "", "", "", 0);
  return { ...round, theme, bots, version: 1, seed: seed.toString("hex"), commit: createHash3("sha256").update(seed).digest("hex") };
}
function syncRounds(s, now) {
  const daily2 = period(s, "private", now);
  if (daily2 && s.show.activePrivate?.id !== daily2.id) {
    const choices = [0, 9, 18].map((shift) => structuredClone(groups.private[(daily2.index + shift) % 28]));
    s.show.activePrivate = { ...daily2, choices };
  }
  const week = period(s, "public", now);
  if (week && !s.show.weeks[week.id]) s.show.weeks[week.id] = makeWeek(s, week);
}
function matchScores(scores, theme) {
  const dims = theme.targets.map((target, i) => [100, 70, 30, 0][Math.min(3, Math.abs(scores[i] - target))]);
  const total = theme.weights.reduce((n, w, i) => n + w * dims[i], 0);
  const divisor = theme.weights.reduce((sum, w) => sum + w, 0);
  const order = [0, 1, 2, 3, 4, 5].sort((a, b) => theme.weights[b] - theme.weights[a] || a - b);
  const key = [total, Math.min(...dims), dims.filter((x) => x === 100).length, ...order.map((i) => dims[i])];
  return { dims, total, divisor, key };
}
var displayScore = (m) => String(Number((m.total / m.divisor).toFixed(2)));
var qualifies = (m) => m.total >= 68 * m.divisor;
function compareKeys(a, b) {
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return b[i] - a[i];
  return 0;
}
function publicTier(position, count) {
  if (position < 1 || position > count) return null;
  const cutoff = [5, 20, 50, 80, 100].findIndex((p) => position <= Math.floor(p * count / 100));
  return tiers.public[cutoff];
}
function rankCash(position, tied, nq) {
  if (nq < 2) return 0;
  const top = Math.max(3, Math.ceil(nq / 10)), next = Math.max(10, Math.ceil(3 * nq / 10));
  let sum = 0;
  for (let p = position; p < position + tied; p++) sum += p === 1 ? 540 : p <= top ? 270 : p <= next ? 120 : 0;
  return Math.floor(sum * Math.min(9, nq - 1) / (9 * tied));
}
function privateTier(match) {
  const { total: n, divisor: d } = match;
  return n >= 95 * d ? "gold" : n >= 82 * d ? "silver" : n >= 68 * d ? "bronze" : null;
}
function drawToken(seed, input) {
  return createHmac("sha256", Buffer.from(seed, "hex")).update(input, "utf8").digest("hex");
}
function board(s, week, species) {
  const entries = week.bots[species].map((scores, i) => {
    const ordinal = String(i + 1).padStart(2, "0");
    return { accountId: "bot-" + species + "-" + ordinal, name: "模拟" + animals[species] + ordinal, scores };
  });
  const reg = s.show.entries[week.id];
  if (reg && !reg.voided && reg.pet.species === species) {
    entries.push({ accountId: s.profileId, name: reg.pet.name, scores: reg.pet.scores, player: true });
  }
  for (const e of entries) {
    e.match = matchScores(e.scores, week.theme);
    e.draw = drawToken(week.seed, week.id + "|" + e.accountId);
  }
  entries.sort((a, b) => {
    const sort = compareKeys(a.match.key, b.match.key);
    if (sort) return sort;
    if (a.draw !== b.draw) return a.draw < b.draw ? -1 : 1;
    return drawToken(week.seed, "tie-again|" + week.id + "|" + a.accountId).localeCompare(drawToken(week.seed, "tie-again|" + week.id + "|" + b.accountId));
  });
  const nq = entries.filter((e) => qualifies(e.match)).length;
  for (let i = 0; i < entries.length; ) {
    let end = i + 1;
    while (end < entries.length && compareKeys(entries[i].match.key, entries[end].match.key) === 0) end++;
    const qualified = qualifies(entries[i].match);
    const rankReward = qualified ? rankCash(i + 1, end - i, nq) : 0;
    for (let j = i; j < end; j++) Object.assign(entries[j], { position: j + 1, tieRank: i + 1, tieSize: end - i, tier: publicTier(j + 1, entries.length), guarantee: qualified ? 20 : 0, rankReward });
    i = end;
  }
  return { entries, nq };
}
function recordCup(s, entry, outcome) {
  const tier = outcome.tier;
  if (!tier) return;
  const key = entry.theme.id + "-" + tier;
  const cups = s.show.cups;
  const previous = Object.values(cups).filter((c) => c.themeId === entry.theme.id).reduce((max, c) => Math.max(max, points[entry.mode][c.tier]), 0);
  if (!cups[key]) cups[key] = { themeId: entry.theme.id, tier, count: 0, first: entry.id, firstAt: entry.result, source: entry.mode === "public" ? "local_sim" : "private" };
  cups[key].count++;
  s.ratingBps += Math.max(0, points[entry.mode][tier] - previous);
  const pet = s.pets.find((p) => p.id === entry.pet.id);
  if (pet) pet.honor = Math.max(pet.honor || 0, honors[entry.mode][tier]);
}
function settle(s, e) {
  const match = matchScores(e.pet.scores, e.theme);
  if (e.mode === "private") e.outcome = { match, tier: privateTier(match), guarantee: 0, rankReward: 0 };
  else {
    const ranked = board(s, s.show.weeks[e.id], e.pet.species), own = ranked.entries.find((r) => r.player);
    e.outcome = { match, tier: own.tier, position: own.position, tieRank: own.tieRank, tieSize: own.tieSize, n: ranked.entries.length, nq: ranked.nq, guarantee: own.guarantee, rankReward: own.rankReward };
  }
  recordCup(s, e, e.outcome);
  s.coins += e.outcome.guarantee;
}
function tickShow(s, now) {
  ensureCalendar(s, now);
  syncRounds(s, now);
  const due = [];
  for (const e of Object.values(s.show.entries)) {
    if (e.voided) continue;
    if (!e.outcome && e.result <= now) due.push({ at: e.result, e, step: "result" });
    if (e.payout && !e.cashClosed && e.payout <= now) due.push({ at: e.payout, e, step: "cash" });
  }
  due.sort((a, b) => a.at - b.at || a.e.id.localeCompare(b.e.id));
  for (const { e, step } of due) {
    if (step === "result") settle(s, e);
    else {
      const { guarantee, rankReward } = e.outcome;
      e.cashPaid = Math.max(0, rankReward - guarantee);
      s.coins += e.cashPaid;
      e.cashClosed = true;
    }
  }
}
function current(s, mode, now) {
  const slot = period(s, mode, now);
  return slot && (mode === "private" ? s.show.activePrivate : s.show.weeks[slot.id]);
}
function eligible(s, p, now) {
  return p && Object.hasOwn(animals, p.species) && ["成年", "老年"].includes(stageOf(p, now)) && !isBusy(s, p);
}
function petSummary(p, now) {
  return {
    id: p.id,
    name: p.name,
    species: p.species,
    breed: breedName(p),
    breedKey: p.breedKey,
    mixed: Boolean(p.mixed),
    coatIndex: p.coatIndex,
    sex: p.sex,
    art: petArt(p),
    stage: stageOf(p, now),
    scores: p.traits.map((t) => grades.indexOf(t.grade)),
    traits: p.traits.map((t) => ({ type: t.type, label: t.label, rarity: t.rarity, grade: t.grade }))
  };
}
var privateFees = { rabbit: 20, cat: 100, dog: 120 };
function feeFor(s, mode, species) {
  return mode === "private" ? Math.ceil(privateFees[species] * (2e5 - s.ratingBps) / 2e6) * 10 : 0;
}
function nextRegistration(s, mode, access, now) {
  let opens = Math.max(now, s.show.epoch, access.opensAt);
  let slot = period(s, mode, opens);
  if (opens >= slot.close || s.show.entries[slot.id] || s.show.voids?.[slot.id]) {
    opens = roundStart(s, mode, slot.index + 1);
    slot = period(s, mode, opens);
  }
  return "下一次可报名 " + time(opens) + "，截止 " + time(slot.close) + "，公布结果 " + time(slot.result) + "（北京时间）。";
}
function registrationOpens(s, mode, access, now) {
  return (mode === "private" ? "私人赛" : "公开赛") + "需开店第 " + access.opensDay + " 天。" + nextRegistration(s, mode, access, now);
}
function review2(s, a, now, rules) {
  const mode = a.mode;
  if (!Object.hasOwn(PNAME, mode)) throw Error("请选择私人赛或本地模拟公开赛。");
  const access = shopRaceAccess(rules, s.createdAt, now).raceAccess[mode];
  if (!access.unlocked) throw Error(registrationOpens(s, mode, access, now));
  const round = current(s, mode, now);
  if (!round || round.id !== a.event || now >= round.close) throw Error("该轮报名已截止。" + nextRegistration(s, mode, access, now));
  if (s.show.voids?.[round.id]) throw Error("本期技术作废。" + nextRegistration(s, mode, access, now));
  if (s.show.entries[round.id]) throw Error("本轮已经提交过报名。" + nextRegistration(s, mode, access, now));
  const choices = mode === "private" ? round.choices : [round.theme], theme = choices.find((t) => t.id === a.theme);
  if (!theme) throw Error("本轮没有这场主题赛。");
  const pet = s.pets.find((p) => p.id === a.pet);
  if (!eligible(s, pet, now)) throw Error("请选店内成年或老年、空闲的动物。");
  const snapshot = petSummary(pet, now), fee = feeFor(s, mode, pet.species);
  const token = createHash3("sha256").update(JSON.stringify([round.id, theme, snapshot, fee])).digest("hex");
  return { round, theme, snapshot, fee, token, match: matchScores(snapshot.scores, theme) };
}
function showAction(s, type, args, now, rules = shop_feature_levels_default) {
  if (type !== "show.enter") return void 0;
  const { round, theme, snapshot, fee, token } = review2(s, args, now, rules);
  if (args.token !== token) throw Error("报名动物或报价已变化，请重新核对快照。");
  if (s.coins < fee) throw Error("金币不足，无法支付私人赛报名费。");
  s.coins -= fee;
  s.show.entries[round.id] = {
    id: round.id,
    mode: args.mode,
    theme: structuredClone(theme),
    submitted: now,
    fee,
    pet: snapshot,
    close: round.close,
    result: round.result,
    payout: round.payout,
    source: args.mode === "public" ? "local_sim" : "private"
  };
  return snapshot.name + "已报名「" + theme.name + "」，" + time(round.result) + "出结果。";
}
var link2 = (page, args = {}) => ({ page, args });
var action = (label, page, args = {}) => ({ label, page, args });
function themeLine(theme) {
  return "目标 " + gradeList(theme.targets);
}
function eventHome(s, now, rules) {
  const rows = [];
  const schedule = {};
  const day2 = shopRaceAccess(rules, s.createdAt, now);
  for (const mode of ["private", "public"]) {
    const round = current(s, mode, now);
    const access = day2.raceAccess[mode];
    if (!round) {
      rows.push({ title: PNAME[mode] + "尚未开赛", text: nextRegistration(s, mode, access, now), visual: { mode } });
      continue;
    }
    const start = rows.length;
    schedule[mode] = { close: time(round.close), result: time(round.result), payout: round.payout ? time(round.payout) : "", entered: !!s.show.entries[round.id] };
    const entry = s.show.entries[round.id];
    const status = now >= round.close ? "本轮已截止" : access.unlocked ? "报名至 " + time(round.close) : "开店第 " + access.opensDay + " 天开放报名";
    const cancelled = s.show.voids?.[round.id];
    if (cancelled) {
      rows.push({
        title: PNAME[mode] + " · 本期技术作废",
        text: cancelled.reason,
        ...entry ? { link: link2("show.result", { event: entry.id }) } : {}
      });
    } else if (mode === "private") {
      if (entry) rows.push({ title: "私人赛 · " + entry.theme.name, text: "本轮已报名 " + entry.pet.name, link: link2("show.result", { event: entry.id }) });
      else for (const t of round.choices) rows.push({
        title: t.name,
        text: "私人三选一 · " + status,
        link: link2("show.round", { mode, event: round.id, theme: t.id })
      });
    } else {
      rows.push({
        title: round.theme.name,
        text: "本地模拟公开赛 · " + (entry ? "已报名 " + entry.pet.name : status),
        link: link2(entry ? "show.result" : "show.round", { event: round.id, mode, theme: round.theme.id })
      });
      if (now >= round.result && round.index >= s.show.calendar.firstWeek) rows.push({ title: "本周公开赛榜单", text: "兔、猫、狗分榜 · 查看实际获档名单", link: link2("show.board", { event: round.id }) });
    }
    if (now >= round.close || !access.unlocked || entry || cancelled) {
      rows.push({ title: "后续参赛时间", text: nextRegistration(s, mode, access, now) });
    }
    for (const row of rows.slice(start)) row.visual = { mode };
  }
  const model = s.pets.find((p) => eligible(s, p, now));
  return {
    title: "比赛",
    art: topicArt,
    visual: { schedule, ...day2, pet: model ? petArt(model) : null, petStage: model ? stageOf(model, now) : null },
    subtitle: "北京时间 · 同一轮只可报名一只动物",
    rows,
    empty: "赛历 " + time(s.show.epoch) + " 开放",
    actions: [action("奖杯收藏", "collection"), action("参赛记录", "show.history"), action("公开赛历届榜单", "show.archive")]
  };
}
function roundPage(s, a, now, rules) {
  const mode = a.mode, round = Object.hasOwn(PNAME, mode) ? current(s, mode, now) : null;
  if (!round || round.id !== a.event) return eventHome(s, now, rules);
  const theme = (mode === "private" ? round.choices : [round.theme]).find((t) => t.id === a.theme);
  if (!theme) return eventHome(s, now, rules);
  const day2 = shopRaceAccess(rules, s.createdAt, now), access = day2.raceAccess[mode];
  const rows = [
    { title: "六维目标", text: dimensions.map((d, i) => d + " " + grades[theme.targets[i]]).join(" · ") },
    { title: "匹配规则", text: "距目标0/1/2/更多档，依次得100/70/30/0分。高于和低于目标同样扣分。" },
    { title: "报名截止 " + time(round.close), text: "结果 " + time(round.result) + (round.payout ? " · 排名现金 " + time(round.payout) : "") }
  ];
  if (mode === "public") {
    const order = [0, 1, 2, 3, 4, 5].sort((x, y) => theme.weights[y] - theme.weights[x] || x - y);
    rows.push(
      { title: "六维权重", text: dimensions.map((d, i) => d + " " + theme.weights[i] + "%").join(" · ") },
      { title: "同分比较", text: "先比最低单维和命中数，再比 " + order.map((i) => dimensions[i]).join("、") + "。仍并列时抽签定杯，现金按并列平分。" },
      { title: "本地模拟抽签承诺 · SHA-256", text: round.commit }
    );
  } else rows.push({ title: "奖杯门槛", text: "68 分铜杯，82 分银杯，95 分金杯。" });
  const reg = s.show.entries[round.id];
  if (s.show.voids?.[round.id]) rows.push({ title: "本期技术作废", text: s.show.voids[round.id].reason + " · " + nextRegistration(s, mode, access, now) });
  else if (reg) rows.push({ title: "本轮已报名 · " + reg.pet.name, text: nextRegistration(s, mode, access, now), link: link2("show.result", { event: reg.id }) });
  else if (now < round.close && !access.unlocked) rows.push({ title: "报名尚未开放", text: registrationOpens(s, mode, access, now) });
  else if (now < round.close) {
    const pets = s.pets.filter((p) => eligible(s, p, now));
    if (!pets.length) rows.push({ title: "暂无可报名动物", text: "需店内成年或老年、未在繁育中的动物。" });
    for (const p of pets) rows.push({
      title: p.name,
      text: breedName(p) + " · " + stageOf(p, now) + " · 报名 " + feeFor(s, mode, p.species) + " 金币",
      art: petArt(p),
      stage: stageOf(p, now),
      link: link2("show.review", { mode, event: round.id, theme: theme.id, pet: p.id })
    });
  } else rows.push({ title: "本期报名已截止", text: nextRegistration(s, mode, access, now) });
  const actions = mode === "public" && !s.show.voids?.[round.id] && now >= round.result && round.index >= s.show.calendar.firstWeek ? [action("查看物种榜", "show.board", { event: round.id })] : [];
  return { title: theme.name, subtitle: PNAME[mode], visual: day2, rows, actions };
}
function reviewPage(s, a, now, rules) {
  let v;
  try {
    v = review2(s, a, now, rules);
  } catch (error) {
    return { title: "报名核对", rows: [{ title: error.message }], actions: [action("回到赛事台", "show")] };
  }
  const { snapshot: p, match, theme, fee, token } = v;
  return { title: "报名核对", subtitle: PNAME[a.mode] + " · " + theme.name, art: p.art, stage: p.stage, rows: [
    { title: p.name + " · " + p.breed, text: p.sex + " · " + p.stage + " · " + gradeList(p.scores) },
    { title: "六维匹配 " + displayScore(match) + " 分", text: themeLine(theme) + "\n逐维 " + match.dims.join(" / ") },
    { title: "本次实付 " + fee + " 金币", text: (a.mode === "private" ? "基准 " + privateFees[p.species] + " 金币。" : "公开赛免费。") + "提交后固定动物快照，占用本轮唯一机会。参赛后仍可出售或配对。" }
  ], actions: [
    {
      label: "提交报名",
      type: "show.enter",
      args: { mode: a.mode, event: a.event, theme: a.theme, pet: a.pet, token },
      confirm: "确定为「" + p.name + "」报名 " + theme.name + "？" + (a.mode === "private" ? "基准 " + privateFees[p.species] + " 金币，" : "") + "实付 " + fee + " 金币，提交后不能更换动物。",
      go: "show.result",
      goArgs: { event: a.event }
    },
    action("重选参赛动物", "show.round", { mode: a.mode, event: a.event, theme: a.theme })
  ] };
}
function resultPage(s, id) {
  const e = lookup(s.show.entries, id);
  if (!e) return { title: "参赛记录", rows: [], empty: "还没有这场报名。" };
  const o = e.outcome, p = e.pet;
  const rows = [
    { title: e.theme.name, text: PNAME[e.mode] + " · 报名 " + time(e.submitted) + " · 实付 " + e.fee + " 金币" },
    { title: "报名快照 · " + p.name, text: p.breed + " · " + p.sex + " · 报名时" + p.stage + "\n" + gradeList(p.scores), art: p.art, stage: p.stage },
    { title: "比赛目标", text: themeLine(e.theme) + "\n权重 " + e.theme.weights.join(" / ") }
  ];
  if (e.voided) rows.push({ title: "本期技术作废", text: e.voided + " · 已退 " + e.fee + " 金币" });
  else if (!o) rows.push({ title: "已报名，等待结果", text: "公布 " + time(e.result) });
  else {
    rows.push({
      title: o.tier ? "获得" + trophies[o.tier] : "本场未获杯",
      art: o.tier ? "awards/" + o.tier : void 0,
      text: displayScore(o.match) + " 分 · " + time(e.result) + "\n逐维 " + o.match.dims.join(" / ")
    });
    if (e.mode === "public") rows.push(
      { title: "第 " + o.position + " / " + o.n + " 位 · 达标 " + o.nq + " 位", text: "真正并列 " + o.tieSize + " 人，起始名次 " + o.tieRank },
      { title: "达标现金 +" + o.guarantee, text: e.cashClosed ? "周日补差 +" + e.cashPaid + "，现金已结清。" : "排名补差 " + time(e.payout) + " 结算。" }
    );
    if (o.tier) rows.push({ title: "本档权益", text: "本档覆盖较低收益资格；收藏仅计本次实际获得的" + trophies[o.tier] + "。" });
  }
  const actions = [action("奖杯收藏", "collection")];
  if (e.mode === "public" && o) actions.unshift(action("五档名单", "show.board", { event: id, species: p.species }));
  return { title: "参赛记录", rows, actions };
}
function collectionPage(s, mode) {
  const selected = mode === "public" ? "public" : "private";
  const held = Object.values(s.show.cups).filter((c) => byTheme[c.themeId]?.mode === selected);
  return {
    title: "奖杯收藏",
    subtitle: PNAME[selected] + " · 已收集 " + held.length + " / " + groups[selected].length * tiers[selected].length,
    rows: groups[selected].map((t) => {
      const earned = held.filter((c) => c.themeId === t.id);
      return { title: t.name, text: earned.length ? earned.map((c) => trophies[c.tier] + " ×" + c.count).join(" · ") : "尚未获杯 · " + themeLine(t), link: link2("collection.theme", { theme: t.id }) };
    }),
    actions: [action("私人杯册", "collection", { mode: "private" }), action("模拟公开杯册", "collection", { mode: "public" })]
  };
}
function collectionTheme(s, id) {
  const t = lookup(byTheme, id);
  if (!t) return collectionPage(s, "private");
  return { title: t.name, subtitle: PNAME[t.mode] + " · " + themeLine(t), rows: tiers[t.mode].map((tier) => {
    const c = s.show.cups[t.id + "-" + tier];
    if (!c) return { title: trophies[tier] + " · 未收集", text: "需在该赛事实际获得此档。", art: "awards/" + tier, visual: { uncollected: true } };
    const first = s.show.entries[c.first];
    return {
      title: trophies[tier] + " ×" + c.count,
      art: "awards/" + tier,
      text: "首获 " + time(c.firstAt) + " · " + first.pet.name + " · " + displayScore(first.outcome.match) + " 分",
      link: link2("show.result", { event: first.id })
    };
  }), actions: [action("选择其他主题", "collection", { mode: t.mode })] };
}
function lastPublished(s, now) {
  return Math.floor((now - s.show.epoch - 5 * DAY2) / WEEK);
}
function archivePage(s, now, cursor = 0) {
  const first = s.show.calendar.firstWeek, last = lastPublished(s, now), size = 8;
  const totalPages = Math.max(1, Math.ceil((last - first + 1) / size));
  const p = Number.isSafeInteger(cursor) ? Math.min(Math.max(0, cursor), totalPages - 1) : 0;
  const top = last - size * p, rows = [];
  for (let i = top; i >= Math.max(first, top - size + 1); i--) {
    const id = "public-" + i, saved = s.show.weeks[id];
    const theme = saved?.theme ?? publicTheme(s, i), at = saved?.result ?? roundStart(s, "public", i) + 5 * DAY2;
    const cancelled = s.show.voids?.[id];
    rows.push(cancelled ? { title: theme.name + " · 技术作废", text: cancelled.reason } : { title: theme.name, text: "公布 " + time(at), link: link2("show.board", { event: id }) });
  }
  const actions = [action("当前赛事", "show", { mode: "public" })];
  if (p > 0) actions.push(action("较近的赛期", "show.archive", { cursor: p - 1 }));
  if (p + 1 < totalPages) actions.push(action("更早的赛期", "show.archive", { cursor: p + 1 }));
  return { title: "本地模拟公开赛", subtitle: "已公布的物种榜 · 第 " + (p + 1) + " / " + totalPages + " 页", rows, actions, empty: "首期结果将在周六20:00公布。" };
}
function publishedWeek(s, id, species, now) {
  if (typeof id !== "string" || !/^public-(0|[1-9]\d*)$/.test(id)) return null;
  if (s.show.voids?.[id]) return null;
  const index = Number(id.slice(7));
  if (!Number.isSafeInteger(index) || index < s.show.calendar.firstWeek || index > lastPublished(s, now)) return null;
  const saved = lookup(s.show.weeks, id);
  if (saved) return now >= saved.result ? saved : null;
  return makeWeek(s, period(s, "public", roundStart(s, "public", index)), [species]);
}
function boardPage(s, a, now, list) {
  const species = Object.hasOwn(animals, a.species) ? a.species : "rabbit";
  const w = publishedWeek(s, a.event, species, now);
  if (!w) return { title: "本地模拟公开赛", rows: [], empty: "本期暂无可查看的结果。" };
  const { entries, nq } = board(s, w, species);
  const actions = Object.keys(animals).map((id) => action(animals[id] + "榜", "show.board", { event: w.id, species: id }));
  if (list) {
    const tier = tiers.public.includes(a.tier) ? a.tier : "laurel";
    const selected = entries.filter((e) => e.tier === tier);
    const snapshot = s.show.entries[w.id]?.pet;
    return {
      title: trophies[tier] + "名单",
      subtitle: "本地模拟公开赛 · " + animals[species] + "榜 · " + w.theme.name,
      visual: { tierOptions: tiers.public.map((t) => ({
        title: trophies[t],
        art: "awards/" + t,
        text: entries.filter((e) => e.tier === t).length + " 位",
        link: { ...link2("show.tier", { event: w.id, species, tier: t }), active: t === tier, replace: true }
      })) },
      rows: selected.map((e) => ({
        title: e.position + ". " + (e.player ? "本店 · " : "") + e.name,
        art: e.player && snapshot.art ? snapshot.art : speciesPortrait[species],
        ...e.player && snapshot.art ? { stage: snapshot.stage } : {},
        text: (e.player ? "本店参赛 · " + s.profileId.slice(-6) + (snapshot.art ? "" : " · 物种示意图") : "模拟选手 · " + e.accountId) + " · " + displayScore(e.match) + " 分\n逐维 " + e.match.dims.join(" / "),
        link: e.player ? link2("show.result", { event: w.id }) : link2("show.bot", { event: w.id, species, id: e.accountId })
      })),
      actions: Object.keys(animals).map((id) => action(animals[id] + "榜", "show.tier", { event: w.id, species: id, tier })),
      empty: "本物种榜没有获得此档的动物。"
    };
  }
  const rows = tiers.public.map((tier) => ({
    title: trophies[tier],
    art: "awards/" + tier,
    text: entries.filter((e) => e.tier === tier).length + " 位",
    link: link2("show.tier", { event: w.id, species, tier })
  }));
  rows.push({ title: "模拟抽签校验", text: "种子 " + w.seed + "\nSHA-256 承诺 " + w.commit });
  return { title: "本地模拟公开赛", subtitle: w.theme.name + " · " + animals[species] + "榜 " + entries.length + " 位，现金达标 " + nq + " 位", rows, actions };
}
function botPage(s, a, now) {
  const species = a.species;
  if (!Object.hasOwn(animals, species)) return archivePage(s, now);
  const w = publishedWeek(s, a.event, species, now);
  if (!w) return archivePage(s, now);
  const e = board(s, w, species).entries.find((entry) => !entry.player && entry.accountId === a.id);
  if (!e) return archivePage(s, now);
  return { title: e.name, subtitle: "本地模拟公开赛 · " + w.theme.name, rows: [
    { title: "模拟选手 " + e.accountId, art: speciesPortrait[species], text: "第 " + e.position + " 名 · " + trophies[e.tier] + " · " + displayScore(e.match) + " 分\n头像为" + animals[species] + "榜物种示意。" },
    { title: "六维快照", text: gradeList(e.scores) + "\n目标 " + gradeList(w.theme.targets) },
    { title: "抽签摘要", text: e.draw }
  ] };
}
function showPage(s, page, args = {}, now, rules = shop_feature_levels_default) {
  switch (page) {
    case "show":
      return eventHome(s, now, rules);
    case "show.round":
      return roundPage(s, args, now, rules);
    case "show.review":
      return reviewPage(s, args, now, rules);
    case "show.result":
      return resultPage(s, args.event);
    case "show.archive":
      return archivePage(s, now, args.cursor);
    case "show.board":
      return boardPage(s, args, now, false);
    case "show.tier":
      return boardPage(s, args, now, true);
    case "show.bot":
      return botPage(s, args, now);
    case "show.history":
      return { title: "参赛记录", rows: Object.values(s.show.entries).sort((a, b) => b.submitted - a.submitted).map((e) => ({
        title: e.theme.name,
        text: time(e.submitted) + " · " + PNAME[e.mode] + " · " + e.pet.name + " · " + (e.voided ? "已作废" : e.outcome ? "已公布" : "等待公布"),
        link: link2("show.result", { event: e.id })
      })), actions: [action("当前赛事", "show")], empty: "尚无报名记录。" };
    case "collection":
      return collectionPage(s, args.mode);
    case "collection.theme":
      return collectionTheme(s, args.theme);
    default:
      return null;
  }
}
var cupNames = { bronze: "铜杯", silver: "银杯", gold: "金杯", memorial: "纪念杯", laurel: "桂冠杯" };
var sessionTimeout = 45e3;
var close = { label: "合上账簿", type: "ui.back" };
function initVisitBook(s, existing) {
  if (s.visitBook) return false;
  s.visitBook = { lastSeenAt: existing ? s.clock : null, opening: !existing, away: [], stories: [] };
  if (!existing) s.visitBook.tutorial = { bred: false, bought: false, claimed: false, ordersViewed: false, marketViewed: false };
  const firstSale = s.sales?.find((sale) => ["market", "guest", "order"].includes(sale.channel));
  const firstNote = s.journal.find((note) => note.key === "trade");
  if (existing && firstNote) {
    if (firstSale) firstNote.at = firstSale.at;
    else if (Array.isArray(s.sales)) s.journal = s.journal.filter((note) => note !== firstNote);
  }
  if (existing && finishStory(s, s.clock)) s.visitBook.stories.push({ id: randomUUID3(), text: ending });
  return true;
}
var ending = "开门、等候、挑选、记账。小店有了自己的日常，账簿仍会继续往后写。";
function finishStory(s, now) {
  if (s.journal.some((n) => n.key === "closing") || !["trade", "room", "guest"].every((key) => s.journal.some((n) => n.key === key))) return false;
  s.journal.push({ key: "closing", text: ending, at: now });
  return true;
}
var tutorialSteps = [
  ["开始兔子繁育", "在繁育台挑选一公一母，核对后确认配对。一生只能繁育一窝。"],
  ["购入一只种兔", "到研究所的兔种源货架查看两只幼兔，挑一只按当前报价购买。"],
  ["签到领养幼兔", "在每日签到簿领取一公一母两只基础幼兔。"],
  ["查看订单和自由市场", "分别看看普通订单的委托条件和自由市场的动物报价。"]
];
var linkTo = (label, page, args = {}) => ({ label, page, args });
var completedSteps = (t) => [t.bred, t.bought, t.claimed, t.ordersViewed && t.marketViewed];
function tutorialStatus(s) {
  const t = s.visitBook.tutorial;
  if (!t) return void 0;
  const index = completedSteps(t).indexOf(false);
  return {
    step: index === -1 ? 4 : index + 1,
    total: 4,
    title: index === -1 ? "开店引导已完成" : tutorialSteps[index][0],
    completed: index === -1,
    ordersViewed: t.ordersViewed,
    marketViewed: t.marketViewed
  };
}
function tutorialAccess(s, key, args = {}) {
  const t = s.visitBook.tutorial;
  if (!t) return false;
  if (key === "orders") return t.bred && t.bought && t.claimed;
  return t.bred && (args.species ?? "rabbit") === "rabbit" && (["shelf", "offer"].includes(key) || key === "care.buyPet" && !t.bought);
}
function visitTutorialDestination(s, page) {
  const field = page === "market" ? "marketViewed" : page === "orders" ? "ordersViewed" : null;
  const t = s.visitBook.tutorial;
  if (!t || !field || t[field]) return s;
  return { ...s, visitBook: { ...s.visitBook, tutorial: { ...t, [field]: true } } };
}
function tutorialPage(s, now, access) {
  const summary = tutorialStatus(s), done = summary ? completedSteps(s.visitBook.tutorial) : [];
  const rows = tutorialSteps.map(([title, text], i) => ({ title: i + 1 + ". " + title, text, done: !!done[i], current: !!summary && !summary.completed && summary.step === i + 1 }));
  const actions = [];
  if (summary && !summary.completed) {
    const rabbit = { species: "rabbit" };
    if (summary.step === 1) {
      const candidates = s.pets.filter((p) => p.species === "rabbit" && canBreed(s, p, now));
      if (["公", "母"].every((sex) => candidates.some((p) => p.sex === sex))) actions.push(linkTo("前往兔繁育台", "breed", rabbit));
      else {
        const potential = s.pets.filter((p) => p.species === "rabbit" && !p.bred && !isBusy(s, p)).map((p) => ({ sex: p.sex, ...lifeDates(p) })).filter((p) => p.deathAt > now).sort((a, b) => a.adultAt - b.adultAt);
        const aliveUntil = { "公": 0, "母": 0 };
        const next = potential.find((p) => {
          aliveUntil[p.sex] = p.deathAt;
          return aliveUntil[p.sex === "公" ? "母" : "公"] > Math.max(now, p.adultAt);
        });
        rows[0].text = next ? "现有后备兔最早于北京时间 " + beijingTime(next.adultAt) + " 配对，可到兔房查看成长。" : (s.care.signedDay === dayAt(now) ? "今天已经签到，明天可再领一对幼兔。" : "当前缺少可配对的公母兔，可先签到领养一对幼兔。") + "幼兔成年后再回来配对。";
        actions.push(linkTo("查看兔房", "rooms", rabbit), linkTo("查看签到簿", "profile"));
        if (access.lab.unlocked) actions.push(linkTo("查看兔种源货架", "shelf", rabbit));
      }
    } else if (summary.step === 2) actions.push(linkTo("前往兔种源货架", "shelf", rabbit));
    else if (summary.step === 3) actions.push(linkTo("前往签到簿", "profile"));
    else {
      rows[3].text = "普通订单" + (summary.ordersViewed ? "已查看" : "待查看") + " · 自由市场" + (summary.marketViewed ? "已查看" : "待查看");
      if (!summary.ordersViewed) actions.push(linkTo("查看普通订单", "orders"));
      if (!summary.marketViewed) actions.push(linkTo("查看自由市场", "market"));
    }
  }
  if (!actions.length) actions.push(close);
  return {
    title: "开店四步",
    subtitle: summary ? summary.completed ? "四步已完成" : "第 " + summary.step + " / 4 步" : "开店步骤说明",
    presentation: { kind: "tutorial", ...summary ?? { archived: true } },
    rows,
    actions
  };
}
function recordMilestone(s, type, args, now) {
  const t = s.visitBook.tutorial;
  if (t) {
    if (type === "care.breed" && (args.species ?? "rabbit") === "rabbit") t.bred = true;
    if (type === "care.buyPet" && (args.species ?? "rabbit") === "rabbit") t.bought = true;
    if (type === "care.checkin") t.claimed = true;
  }
  const lines = [];
  const add = (key, text) => {
    if (s.journal.some((n) => n.key === key)) return;
    s.journal.push({ key, text, at: now });
    lines.push(text);
  };
  if (type === "care.unlock") add("room", "研究所联络员送来" + SPECIES[args.species].name + "房资料：“这对幼崽有自己的成长周期，看看它们什么时候成年吧。”");
  if (type === "sale.commit" && ["market", "order", "guest"].includes(args.channel)) {
    add("trade", "第一笔生意完成了。你在账簿上记下收入，也重新看了看店里留下的动物。");
    if (args.channel === "guest") add("guest", "书店来客收下了心仪的动物。你之前选出的特征，正好合了这次委托。");
  }
  if (!lines.length) return;
  if (finishStory(s, now)) lines.push(ending);
  s.visitBook.stories.push({ id: randomUUID3(), text: lines.join("\n") });
}
function awayEvents(s, from, to) {
  const events = [];
  function add(at, title, text) {
    if (at > from && at <= to) events.push({ at, title, text });
  }
  for (const [key, room] of Object.entries(s.rooms)) {
    const litter2 = room.lastLitter;
    if (litter2) add(litter2.bornAt, SPECIES[key].name + "房出生 " + litter2.ids.length + " 只", litter2.mother + " × " + litter2.father);
  }
  for (const p of s.pets) {
    const { adultAt, deathAt } = lifeDates(p);
    add(adultAt, p.name + " 已成年", SPECIES[p.species].name + " · " + p.sex + " · #" + p.id.slice(0, 5).toUpperCase());
    add(deathAt, p.name + " 自然死亡", SPECIES[p.species].name + " · " + p.sex + " · #" + p.id.slice(0, 5).toUpperCase());
  }
  s.orders.forEach((slot, i) => {
    if (slot.order?.refilledAt) add(slot.order.refilledAt, "第 " + (i + 1) + " 槽普通订单已补单", "新委托已放入订单夹。");
  });
  for (const e of Object.values(s.show.entries)) {
    if (!e.outcome || e.voided) continue;
    const name = e.pet.name + " · " + e.theme.name;
    add(e.result, name, e.outcome.tier ? "获得" + cupNames[e.outcome.tier] + "。" : "本次未获杯。");
    if (e.cashClosed) add(e.payout, name + " · 排名结算", "追加到账 " + e.cashPaid + " 金币。");
  }
  return events.sort((a, b) => a.at - b.at);
}
function seedRecoveryRows(s, now, access) {
  const paired = Object.keys(s.rooms).some((species) => {
    if (s.rooms[species].job) return true;
    const candidates = s.pets.filter((p) => p.species === species && stageOf(p, now) !== "已故" && !p.bred && !isBusy(s, p));
    return candidates.some((p) => p.sex === "母") && candidates.some((p) => p.sex === "公");
  });
  if (paired) return [];
  const signed = s.care.signedDay === dayAt(now);
  const rows = [{
    title: "当前后备种源不足",
    text: signed ? "今天已签到，次日可再领一对基础幼兔。" : "今日签到可领一公一母两只基础幼兔。",
    link: { page: "profile" }
  }];
  if (!access.lab.unlocked) {
    rows.push({ title: "研究所尚未开放", text: "店铺 " + access.lab.requiredLevel + " 级开放种源货架。" });
    return rows;
  }
  for (const [species, room] of Object.entries(s.rooms)) {
    const stock = room.shelf.offers.filter(Boolean);
    rows.push({
      title: SPECIES[species].name + "房当前货架",
      text: stock.length ? stock.map((p) => p.name + "（" + p.sex + "）" + purchasePrice(s, youngPurchaseBase(p)) + " 金币").join("、") : "本批已售空。",
      link: { page: "shelf", args: { species } }
    });
  }
  return rows;
}
function summaryPage(s, events, now, access) {
  const rows = events.map((e) => ({ title: e.title, text: beijingTime(e.at) + "　" + e.text }));
  return { title: "离店期间", subtitle: "北京时间 · 以下事项均已结算", rows: [...rows, ...seedRecoveryRows(s, now, access)], actions: [close] };
}
function openingPage(revisit, activeTutorial) {
  return { title: "旧店交接", subtitle: "账簿的第一页", rows: [
    { title: "街角的小店", text: "柜台上压着钥匙和一本旧账簿。原店主写道：“先别急着把店做大，看看进门的人需要什么。”" },
    { title: "兔房里的一对种兔", text: "小花和小白在开店时已经成年。到繁育台选好亲本，核对后就能开始第一窝。" },
    { title: "第一窝以后", text: "去研究所货架挑一只种兔，再去签到簿领养后备幼兔。最后看看普通订单与自由市场，为店里的兔子选择去处。" }
  ], actions: [{ label: revisit || !activeTutorial ? "查看开店四步" : "开始新手引导", page: "tutorial" }, revisit ? close : { label: "跳过，进店", type: "ui.back" }] };
}
function visitHistoryPage(s, key, now, access) {
  if (key === "tutorial") return { ...tutorialPage(s, now, access), readNoteIds: s.visitBook.opening ? ["opening"] : [] };
  if (key === "openingGuide") return { ...openingPage(true, !!s.visitBook.tutorial), readNoteIds: s.visitBook.opening ? ["opening"] : [] };
  if (key === "lastVisit" && s.visitBook.lastReport) return summaryPage(s, s.visitBook.lastReport, now, access);
  return null;
}
function unreadLetter(s, now, access) {
  const book = s.visitBook;
  if (book.away.length) return { ids: book.away.map((b) => b.id), page: summaryPage(s, book.away.flatMap((b) => b.events), now, access) };
  if (book.opening) return { ids: ["opening"], page: openingPage(false, !!book.tutorial) };
  if (book.stories.length) return { ids: book.stories.map((n) => n.id), page: {
    title: "账簿新页",
    rows: book.stories.map((n) => ({ title: "经营手记", text: n.text })),
    actions: [close]
  } };
  return null;
}
function updateVisit(s, sessions, clientId, foreground, reader, now) {
  for (const [key, session] of sessions) if (now - session.at > sessionTimeout * 2) sessions.delete(key);
  if ((sessions.get(clientId)?.seq ?? -1) >= reader.seq) return;
  const active = Array.from(sessions.values()).some((session) => session.foreground && now - session.at <= sessionTimeout);
  const previous = sessions.get(clientId);
  const book = s.visitBook;
  if (foreground && !active && book.lastSeenAt !== null) {
    const events = awayEvents(s, book.lastSeenAt, now);
    if (events.length) book.away.push({ id: randomUUID3(), events });
  }
  if (foreground || previous?.foreground && now - previous.at <= sessionTimeout) book.lastSeenAt = now;
  sessions.set(clientId, { at: now, foreground, seq: reader.seq });
  const read = new Set(reader.read || []);
  if (read.has("opening")) book.opening = false;
  if (read.size) {
    const archived = book.away.filter((b) => read.has(b.id));
    if (archived.length) book.lastReport = archived.flatMap((b) => b.events);
    book.away = book.away.filter((b) => !read.has(b.id));
    book.stories = book.stories.filter((b) => !read.has(b.id));
  }
}
var legacyEntrances = Object.keys(featureNames).filter((key) => key !== "collection");
var pageHandlers = [carePage, businessPage, showPage];
var actionHandlers = [careAction, businessAction, showAction];
var minute2 = 6e4;
var GameError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
  }
};
function newState(now) {
  const id = randomUUID4();
  const state = {
    schema: 1,
    mode: "local_sim",
    profileId: id,
    profile_id: id,
    rootSeed: randomBytes2(32).toString("hex"),
    createdAt: now,
    clock: now,
    version: 1,
    coins: 680,
    shopXp: 0,
    receipts: {},
    journal: []
  };
  initCare(state, now);
  initShow(state, now);
  initBusiness(state, now);
  initVisitBook(state, false);
  return state;
}
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((k) => [k, canonical(value[k])]));
  return value;
}
function publicShop(s, now, rules) {
  const { level, ...shopExperience } = shopProgress(rules, s.shopXp);
  const access = featureAccess(rules, level);
  const hints = [];
  const dayClaimed = s.care.signedDay === dayAt(now);
  if (access.guest.unlocked && s.visitors.active) hints.push({ id: s.visitors.active.id, text: "有位客人正在等，到来客簿看看吧。" });
  for (const room of Object.values(s.rooms)) {
    const litter2 = room.lastLitter;
    if (access.breed.unlocked && litter2 && now - litter2.bornAt < 864e5) hints.push({ id: "litter-" + litter2.ids[0], text: "新的一窝出生了，去繁育台看看小家伙吧。" });
  }
  const order = access.orders.unlocked && readyOrderId(s, now);
  if (order) hints.push({ id: "order-" + order, text: "有只动物符合委托，订单夹里可以查看。" });
  return {
    protocol: 1,
    profileId: s.profileId,
    version: s.version,
    mode: s.mode,
    name: "宠物店",
    coins: s.coins,
    shopLevel: level,
    shopExperience,
    ...shopRaceAccess(rules, s.createdAt, now),
    featureAccess: access,
    entrances: legacyEntrances.filter((key) => access[key].unlocked),
    ...s.visitBook.tutorial && { tutorial: tutorialStatus(s) },
    now,
    hints,
    dayClaimed,
    decor: Object.keys(s.decor || {}).filter((k) => s.decor[k]?.placed),
    rooms: Object.keys(s.rooms || {}).filter((k) => s.rooms[k]),
    notice: s.journal.at(-1) ?? null
  };
}
function accountPage(s, now, access) {
  return {
    title: "店主登记簿",
    subtitle: "本机经营档",
    art: "shop-modules/opening",
    readNoteIds: s.visitBook.stories.map((story) => story.id),
    rows: [
      { title: "店铺资产", text: s.coins + " 金币 · " + s.pets.length + " 只在册动物" },
      { title: "店主编号", text: s.profileId },
      { title: "开店交接", text: "重读旧店主留下的第一页。", link: { page: "openingGuide" } },
      { title: "开店四步", text: s.visitBook.tutorial ? "查看新手引导进度。" : "重读开店步骤说明。", link: { page: "tutorial" } },
      ...s.visitBook.lastReport ? [{ title: "上次回店摘要", text: "查看离开期间已结算的事项。", link: { page: "lastVisit" } }] : [],
      ...seedRecoveryRows(s, now, access),
      { title: "设备时间", text: "请保持设备时间准确。向前调时会立即推进成长和比赛，可能让动物自然寿终。调回时钟无法撤销已经结算的事件。" },
      ...s.clockEvent ? [{ title: "校时记录", text: s.clockEvent.text }] : [],
      ...s.recoveredFrom ? [{ title: "存档恢复", text: "最近一次从备份 " + s.recoveredFrom + " 恢复。" }] : [],
      ...s.journal.slice(-5).reverse().map((j) => ({ title: j.text, text: new Date(j.at).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" }) }))
    ],
    actions: [{ label: "奖杯收藏册", page: "collection" }, { label: "模拟支付演示", page: "payment" }]
  };
}
function validateState(s) {
  const obj = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
  if (!obj(s) || s.schema !== 1 || s.mode !== "local_sim" || !s.profileId || !Number.isFinite(s.clock) || typeof s.rootSeed !== "string" || !/^[0-9a-f]{64}$/i.test(s.rootSeed) || !Number.isSafeInteger(s.version) || !Array.isArray(s.pets) || !obj(s.receipts) || !obj(s.rooms?.rabbit) || !Array.isArray(s.journal) || !obj(s.care) || !obj(s.research) || !obj(s.decor) || !Array.isArray(s.orders) || s.orders.length !== 3 || !obj(s.businessDay) || !obj(s.visitors?.sessions) || !Array.isArray(s.visitors?.intervals) || !obj(s.show?.weeks) || !obj(s.show?.entries) || !obj(s.show?.cups) || s.pets.some((p) => !p?.id || !obj(s.rooms[p.species]) || !Array.isArray(p.traits) || p.traits.length !== 6) || !Number.isSafeInteger(s.coins) || s.shopXp !== void 0 && (!Number.isSafeInteger(s.shopXp) || s.shopXp < 0)) throw new GameError("经营存档结构不完整。", 503);
  return s;
}
var ShopEngine = class {
  constructor({ wall = Date.now, monotonic = () => performance.now(), rules = shop_feature_levels_default } = {}) {
    this.wall = wall;
    this.monotonic = monotonic;
    this.rules = rules;
    this.readers = /* @__PURE__ */ new Map();
  }
  ensure() {
    if (!this.state) this.initialize(null);
  }
  initialize(restored, { fromBackup = false, resetConnections = false } = {}) {
    const s = restored ?? newState(this.wall());
    const checkParents = s.care.parentRetentionChecked !== true;
    if (checkParents) {
      if (repairLegacyParentRetention(s)) s.version++;
      s.care.parentRetentionChecked = true;
    }
    const needsVisitBook = initVisitBook(s, !!restored);
    const needsOpening = !Number.isFinite(s.createdAt);
    if (needsOpening) s.createdAt = Number.isFinite(s.rooms.rabbit.openedAt) ? s.rooms.rabbit.openedAt : s.clock;
    const needsXp = s.shopXp === void 0;
    if (needsXp) s.shopXp = (s.sales ?? []).reduce((sum, sale) => sum + (sale.saleExperience ?? saleExperience(this.rules, sale.channel, sale.lines)), 0);
    if (restored && resetConnections && s.visitors) {
      s.visitors.sessions = {};
      s.visitors.intervals = [];
    }
    if (restored && this.wall() < s.clock) s.clockEvent = { at: s.clock, text: "检测到设备时钟回拨，经营时间从上次存档继续。" };
    this.anchor = Math.max(s.clock, this.wall());
    this.mark = this.monotonic();
    this.savedAt = s.clock;
    if (!restored || checkParents || needsXp || needsOpening || needsVisitBook || fromBackup || s.clockEvent && s.clockEvent.at === s.clock) this.save(s);
    this.state = s;
  }
  now() {
    const mono = this.monotonic();
    const estimated = this.anchor + Math.max(0, mono - this.mark), wall = this.wall();
    if (wall - estimated > 2e3) this.clockChange = { at: wall, text: "设备时间向前调整，已按新的时刻结算经营事件。" };
    else if (wall < estimated - 2e3 && !this.lagging) this.clockChange = { at: Math.floor(estimated), text: "检测到设备时钟回拨，经营时间按原进度继续。" };
    this.lagging = wall < estimated - 2e3;
    this.anchor = Math.max(wall, estimated);
    this.mark = mono;
    return Math.floor(this.anchor);
  }
  save(s) {
    this.state = s;
    this.savedAt = s.clock;
  }
  advance(forceCheckpoint = false) {
    this.ensure();
    const now = this.now();
    const s = structuredClone(this.state);
    const world = ({ receipts, clock, ...fields2 }) => JSON.stringify(fields2);
    const before = world(s);
    tickCare(s, now);
    tickShow(s, now);
    tickBusiness(s, now);
    if (this.clockChange) s.clockEvent = this.clockChange;
    const changed = before !== world(s);
    if (changed || now - this.savedAt >= minute2 || forceCheckpoint && now !== this.savedAt) {
      s.clock = now;
      if (changed) s.version++;
      this.save(s);
    }
    this.clockChange = null;
    return now;
  }
  shop() {
    const now = this.advance();
    return publicShop(this.state, now, this.rules);
  }
  requireFeature(level, key) {
    if (key && level < this.rules.featureLevels[key]) {
      throw new GameError(featureNames[key] + "需要店铺达到 " + this.rules.featureLevels[key] + " 级。", 403);
    }
  }
  page(page, args) {
    const now = this.advance(), s = this.state;
    const level = shopProgress(this.rules, s.shopXp).level;
    if (!tutorialAccess(s, page, args)) this.requireFeature(level, operationFeature(page, args));
    const data = structuredClone(s);
    const access = featureAccess(this.rules, level);
    let view = page === "login" ? accountPage(data, now, access) : visitHistoryPage(data, page, now, access);
    for (const get of pageHandlers) {
      if (view) break;
      view = get(data, page, args, now, this.rules);
    }
    if (!view) throw new GameError("这个页面暂不可用，请返回店铺。", 404);
    if (!access.lab.unlocked && s.visitBook.tutorial?.bought && ["shelf", "offer"].includes(page)) {
      view.actions = [{ label: "返回新手引导", page: "tutorial" }];
      view.subtitle = (view.subtitle ? view.subtitle + " · " : "") + "本次引导采购已完成，再次采购需店铺 " + access.lab.requiredLevel + " 级。";
    }
    if (page === "orders" && tutorialAccess(s, page, args) && (!access.orders.unlocked || !tutorialStatus(s).completed)) {
      const preview = !access.orders.unlocked;
      if (preview) {
        view.rows = view.rows.map(({ title, text }) => ({ title, text }));
        view.actions = [];
        view.subtitle = "委托预览 · 店铺 " + access.orders.requiredLevel + " 级开放交付与取消。";
        view.visual = { ...view.visual, preview: true };
      }
      if (!s.visitBook.tutorial.marketViewed) view.actions.push({ label: "去自由市场", page: "market" });
      view.actions.push({ label: "返回新手引导", page: "tutorial" });
    }
    const sale = view.actions?.find((a) => a.type === "sale.commit");
    if (sale) {
      this.requireFeature(level, operationFeature(sale.type, sale.args));
      const xp = saleExperience(this.rules, sale.args.channel, sale.args.amounts.map((amount) => ({ amount })));
      sale.args.saleExperience = xp;
      view.visual = { ...view.visual, saleExperience: xp };
      if (xp) view.subtitle += " · 店铺经验 +" + xp;
    }
    const viewed = visitTutorialDestination(s, page);
    if (viewed !== s) {
      viewed.clock = now;
      this.save(viewed);
    }
    return { shop: publicShop(viewed, now, this.rules), page: view };
  }
  receipt(id) {
    this.ensure();
    if (!Object.hasOwn(this.state.receipts, id)) throw new GameError("尚未找到该请求回执。", 404);
    return this.state.receipts[id].result;
  }
  act({ requestId, profileId, version, type, args }) {
    const now = this.advance(), current2 = this.state;
    if (typeof requestId !== "string" || !/^[\w-]{12,100}$/.test(requestId) || typeof type !== "string" || !args || Array.isArray(args) || typeof args !== "object") throw new GameError("请求格式不正确。", 400);
    if (profileId !== current2.profileId) throw new GameError("存档已切换，请重新打开店铺。");
    const key = JSON.stringify(canonical([type, args]));
    const old = Object.hasOwn(current2.receipts, requestId) && current2.receipts[requestId];
    if (old) {
      if (old.key !== key) throw new GameError("请求编号与原操作不符。");
      return old.result;
    }
    if (version !== current2.version) {
      if (type === "sale.commit") {
        try {
          validateSaleQuote(current2, args, now);
        } catch (error) {
          throw new GameError(error.message);
        }
      }
      throw new GameError("店内情况已变化，请查看最新资料后重新确认。");
    }
    const level = shopProgress(this.rules, current2.shopXp).level;
    if (!tutorialAccess(current2, type, args)) this.requireFeature(level, operationFeature(type, args));
    if (type === "sale.commit" && args.litterRetention) this.requireFeature(level, "breed");
    const s = structuredClone(current2);
    let message;
    for (const run of actionHandlers) {
      message = run(s, type, args, now, this.rules);
      if (message !== void 0) break;
    }
    if (message === void 0) throw new GameError("未识别的经营操作。", 400);
    if (typeof message !== "string" || !Number.isSafeInteger(s.coins) || s.coins < 0) throw Error("经营数据校验失败。");
    let awarded, levelUp;
    if (type === "sale.commit") {
      const sale = s.sales.at(-1);
      awarded = saleExperience(this.rules, sale.channel, sale.lines);
      if (args.saleExperience !== void 0 && args.saleExperience !== awarded) throw new GameError("店铺经验报价已变化，请重新核价。");
      sale.saleExperience = awarded;
      s.shopXp += awarded;
      if (!Number.isSafeInteger(s.shopXp)) throw Error("店铺经验超出可保存范围。");
      if (awarded) message = message.replace(/。$/, "") + "，店铺经验 +" + awarded + "。";
      const next = shopProgress(this.rules, s.shopXp).level;
      if (next > level) {
        const unlocked = Object.keys(featureNames).filter((key2) => this.rules.featureLevels[key2] > level && this.rules.featureLevels[key2] <= next);
        levelUp = { from: level, to: next, unlocked };
        message += "店铺升至 " + next + " 级" + (unlocked.length ? "，解锁" + unlocked.map((key2) => featureNames[key2]).join("、") : "") + "。";
      }
    }
    recordMilestone(s, type, args, now);
    s.clock = now;
    s.version++;
    const result = { requestId, message, version: s.version, ...awarded !== void 0 && { saleExperience: awarded }, ...levelUp && { levelUp } };
    s.receipts[requestId] = { key, result };
    this.save(s);
    return result;
  }
  heartbeat(clientId, foreground, reader) {
    if (typeof clientId !== "string" || !/^[\w-]{8,100}$/.test(clientId) || typeof foreground !== "boolean") throw new GameError("心跳格式无效。", 400);
    const now = this.advance(), s = structuredClone(this.state);
    if (reader && (reader.profileId !== s.profileId || !Number.isSafeInteger(reader.seq) || reader.seq < 0 || reader.read !== void 0 && (!Array.isArray(reader.read) || reader.read.some((id) => typeof id !== "string")))) {
      throw new GameError("店铺已切换或账簿参数无效，请重新打开店铺。", 409);
    }
    const readers = new Map(this.readers);
    if (reader && reader.seq <= (readers.get(clientId)?.seq ?? -1)) return publicShop(s, now, this.rules);
    if (reader) updateVisit(s, readers, clientId, foreground, reader, now);
    const guestUnlocked = shopProgress(this.rules, s.shopXp).level >= this.rules.featureLevels.guest;
    if (!guestUnlocked && !reader) return publicShop(s, now, this.rules);
    const guest = s.visitors?.active?.id;
    if (guestUnlocked) businessHeartbeat(s, { clientId, foreground }, now);
    if (guest !== s.visitors?.active?.id) s.version++;
    s.clock = now;
    this.save(s);
    this.readers = readers;
    const shop = publicShop(s, now, this.rules);
    if (reader && foreground) shop.letter = unreadLetter(s, now, shop.featureAccess);
    return shop;
  }
  checkpoint(force = false) {
    if (this.state) this.advance(force);
  }
};
var RequestGameStore = class extends ShopEngine {
  constructor(snapshot = null, options2 = {}) {
    super(options2);
    this.dirty = false;
    if (snapshot === null) {
      this.initialize(null);
      return;
    }
    const readers = snapshot?.readers;
    if (!Array.isArray(readers)) throw new GameError("经营档的会话记录无法读取。", 503);
    for (const pair of readers) {
      if (!Array.isArray(pair) || pair.length !== 2) throw new GameError("经营档的会话记录无法读取。", 503);
      const [id, entry] = pair;
      if (typeof id !== "string" || !/^[-\w]{8,100}$/.test(id) || this.readers.has(id) || !Number.isFinite(entry?.at) || typeof entry.foreground !== "boolean" || !Number.isSafeInteger(entry.seq) || entry.seq < 0)
        throw new GameError("经营档的会话记录无法读取。", 503);
      this.readers.set(id, { at: entry.at, foreground: entry.foreground, seq: entry.seq });
    }
    this.initialize(structuredClone(validateState(snapshot.state)));
  }
  save(s) {
    super.save(s);
    this.dirty = true;
  }
  snapshot() {
    return structuredClone({ state: this.state, readers: [...this.readers] });
  }
};
function accountName(input) {
  const name = typeof input === "string" ? input.trim().normalize("NFKC") : "";
  if (!/^[\p{L}\p{M}\p{N}._@-]{1,32}$/u.test(name)) {
    throw new GameError("账号名限 1 至 32 个字，可用中文、字母、数字及 ._@-。", 400);
  }
  return { name, key: name.toLowerCase() };
}
var format = "scrypt-32768-8-3";
var cost = { N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 };
var dummySalt = "00000000000000000000000000000000";
function validPassword(password) {
  if (typeof password !== "string" || password.length > 256) return false;
  const length = Array.from(password).length;
  return length >= 8 && length <= 128;
}
function passwordRecord(password) {
  const salt = randomBytes3(16).toString("hex");
  return [format, salt, scryptSync(password, Buffer2.from(salt, "hex"), 32, cost).toString("hex")].join("$");
}
function matchesPassword(password, record) {
  const [type, salt, digest2] = (record || "").split("$");
  const usable = type === format && /^[a-f0-9]{32}$/.test(salt) && /^[a-f0-9]{64}$/.test(digest2);
  const derived = scryptSync(password, Buffer2.from(usable ? salt : dummySalt, "hex"), 32, cost);
  return usable && timingSafeEqual(derived, Buffer2.from(digest2, "hex"));
}
var prefix = "/petshop-api/v1/";
var sites = /* @__PURE__ */ new Set(["https://play.zhu-li-4212.xyz", "https://petshop-trial.pages.dev", "https://petshop.zhu-li-4212.xyz"]);
var sessionLifetime = 30 * 864e5;
var hash = (value) => createHash4("sha256").update(value).digest("hex");
var json = (value, status = 200) => new Response(JSON.stringify(value), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
async function body(request, limit) {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") {
    throw new GameError("请求需要 JSON。", 415);
  }
  const stream = request.body?.getReader();
  if (!stream) throw new GameError("请求内容为空。", 400);
  let length = 0, content = "";
  const decoder = new TextDecoder();
  while (true) {
    const chunk = await stream.read();
    if (chunk.done) break;
    length += chunk.value.byteLength;
    if (length > limit) {
      await stream.cancel();
      throw new GameError("请求数据太大。", 413);
    }
    content += decoder.decode(chunk.value, { stream: true });
  }
  try {
    const parsed = JSON.parse(content + decoder.decode());
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
  } catch {
  }
  throw new GameError("请求内容无效。", 400);
}
async function limitAuth(db, key, maximum) {
  const now = Date.now(), windowMs = 6e5;
  const bucket = hash(key);
  const updated = await db.prepare(`INSERT INTO trial_auth_limits VALUES (?,1,?)
    ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN expires_at<=? THEN 1 ELSE attempts+1 END,
    expires_at=CASE WHEN expires_at<=? THEN excluded.expires_at ELSE expires_at END
    WHERE expires_at<=? OR attempts<? RETURNING attempts`).bind(bucket, now + windowMs, now, now, now, maximum).first();
  if (!updated) throw new GameError("操作过于频繁，请稍后再试。", 429);
  if (updated.attempts === 1) await db.prepare("DELETE FROM trial_auth_limits WHERE expires_at<=?").bind(now).run();
}
async function setLegacyPassword(db, input, key) {
  const now = Date.now();
  const proof = input.legacyProof;
  const code = typeof input.code === "string" ? input.code.trim().toLowerCase() : "";
  let condition, values;
  if (/^[0-9a-f]{16}$/.test(code)) {
    condition = "EXISTS (SELECT 1 FROM trial_sessions s WHERE s.account_id=trial_accounts.id AND s.setup_digest=? AND s.setup_expires_at>? AND s.expires_at>?)";
    values = [hash(code), now, now];
  } else if (typeof proof?.profileId === "string" && proof.profileId.length <= 128 && typeof proof.rootSeed === "string" && /^[0-9a-f]{64}$/.test(proof.rootSeed)) {
    condition = "json_extract(snapshot,'$.state.profileId')=? AND json_extract(snapshot,'$.state.rootSeed')=?";
    values = [proof.profileId, proof.rootSeed];
  } else {
    throw new GameError("请输入有效的一次性验证码，或使用原浏览器的旧店凭据。", 403);
  }
  const eligible2 = "name_key=? AND password_hash IS NULL AND " + condition;
  const unavailable = () => new GameError("旧店凭据无效、已过期，或此账号已设密码。", 403);
  const account = await db.prepare("SELECT id,username FROM trial_accounts WHERE " + eligible2).bind(key, ...values).first();
  if (!account) throw unavailable();
  const record = passwordRecord(input.password);
  const token = randomBytes4(32).toString("base64url");
  const batch = await db.batch([
    db.prepare("UPDATE trial_accounts SET password_hash=? WHERE " + eligible2).bind(record, key, ...values),
    db.prepare("DELETE FROM trial_sessions WHERE account_id=? AND EXISTS(SELECT 1 FROM trial_accounts WHERE id=? AND password_hash=?)").bind(account.id, account.id, record),
    db.prepare("INSERT INTO trial_sessions(digest,account_id,expires_at) SELECT ?,id,? FROM trial_accounts WHERE id=? AND password_hash=?").bind(hash(token), now + sessionLifetime, account.id, record)
  ]);
  if (!batch[0].meta.changes) throw unavailable();
  return json({ username: account.username, token, accountId: account.id });
}
async function legacySetupCode(db, token, digest2) {
  const now = Date.now(), expires = now + 9e5;
  const codeAt = (expiry) => createHmac2("sha256", token).update("trial-password-setup:" + expiry).digest("hex").slice(0, 16);
  const session = await db.prepare(`UPDATE trial_sessions SET
    setup_digest=CASE WHEN setup_expires_at>? THEN setup_digest ELSE ? END,
    setup_expires_at=CASE WHEN setup_expires_at>? THEN setup_expires_at ELSE ? END
    WHERE digest=? AND expires_at>? RETURNING setup_expires_at`).bind(now, hash(codeAt(expires)), now, expires, digest2, now).first();
  if (!session) throw new GameError("请重新登录试玩账号。", 401);
  return codeAt(session.setup_expires_at);
}
async function authenticate(db, request, route) {
  const peer = request.headers.get("cf-connecting-ip") || "local";
  await limitAuth(db, route + ":" + peer, route === "auth/register" ? 120 : 600);
  const registering = route === "auth/register";
  const input = await body(request, registering ? 18e5 : 4096);
  const { name, key } = accountName(input.username);
  if (!validPassword(input.password)) throw new GameError("请输入 8 至 128 个字符的密码。", 400);
  if (!registering) await limitAuth(db, route + ":account:" + key, 30);
  if (route === "auth/set-password") return setLegacyPassword(db, input, key);
  const token = randomBytes4(32).toString("base64url");
  const now = Date.now();
  const statements = [db.prepare("DELETE FROM trial_sessions WHERE expires_at<=?").bind(now)];
  let account;
  if (registering) {
    let snapshot;
    try {
      const game = new RequestGameStore(input.legacySnapshot ?? null);
      snapshot = game.snapshot();
      snapshot.readers = [];
      snapshot.state.visitors.sessions = {};
      snapshot.state.visitors.intervals = [];
    } catch {
      throw new GameError("无法读取旧店存档。原存档仍保留在这个浏览器。", 422);
    }
    account = { id: randomUUID5(), username: name };
    statements.push(db.prepare("INSERT INTO trial_accounts(id,name_key,username,snapshot,password_hash) VALUES(?,?,?,?,?)").bind(account.id, key, name, JSON.stringify(snapshot), passwordRecord(input.password)));
  } else {
    account = await db.prepare("SELECT id,username,password_hash FROM trial_accounts WHERE name_key=?").bind(key).first();
    if (!matchesPassword(input.password, account?.password_hash)) throw new GameError("账号名或密码不正确。旧账号请先设置密码。", 401);
  }
  statements.push(db.prepare("INSERT INTO trial_sessions(digest,account_id,expires_at) VALUES(?,?,?)").bind(hash(token), account.id, now + sessionLifetime));
  try {
    await db.batch(statements);
  } catch (error) {
    if (registering && await db.prepare("SELECT id FROM trial_accounts WHERE name_key=?").bind(key).first()) {
      throw new GameError("这个账号名已注册。", 409);
    }
    throw error;
  }
  return json({ username: account.username, token, accountId: account.id });
}
function play(game, route, data, username) {
  if (route === "shop") return game.shop();
  if (route.startsWith("receipts/")) return game.receipt(route.slice(9));
  if (route === "heartbeat") return game.heartbeat(data.clientId, data.foreground, data.reader);
  if (route === "action") return game.act(data);
  if (typeof data.page !== "string" || data.args != null && (typeof data.args !== "object" || Array.isArray(data.args))) {
    throw new GameError("页面参数无效。", 400);
  }
  if (data.page === "multiplayerAccount") return { shop: game.shop(), page: { title: "切换账号", rows: [] } };
  const result = game.page(data.page, data.args || {});
  if (data.page === "login") {
    result.page.subtitle = "试玩账号 · " + username;
    result.page.actions.push({ label: "切换账号", page: "multiplayerAccount" });
    const clock = result.page.rows.find((row) => row.title === "设备时间");
    if (clock) {
      clock.title = "经营时间";
      clock.text = "换设备输入同一账号与密码，可继续经营这家店。";
    }
  }
  return result;
}
async function dispatch(request, db, route) {
  const get = request.method === "GET";
  if (get && route === "health") {
    await db.prepare("SELECT 1 FROM trial_accounts LIMIT 1").first();
    return json({ service: "petshop", storage: "trial-accounts", status: "ok", protocol: 1, gameplay: 1 });
  }
  if (request.method === "POST" && ["auth/register", "auth/login", "auth/set-password"].includes(route)) return authenticate(db, request, route);
  const read = route === "shop" || /^receipts\/[\w-]+$/.test(route);
  if (!read && !["auth/logout", "page", "heartbeat", "action"].includes(route)) throw new GameError("接口不存在。", 404);
  if (request.method !== (read ? "GET" : "POST")) throw new GameError("不支持此请求方法。", 405);
  const token = request.headers.get("authorization")?.match(/^Bearer ([\w-]{43})$/)?.[1];
  if (!token) throw new GameError("请先登录试玩账号。", 401);
  const digest2 = hash(token);
  if (route === "auth/logout") {
    await db.prepare("DELETE FROM trial_sessions WHERE digest=?").bind(digest2).run();
    return json({ ok: true });
  }
  const data = read ? null : await body(request, 512 * 1024);
  for (let attempt = 0; attempt < 8; attempt++) {
    const row = await db.prepare(`SELECT a.id,a.username,a.revision,a.snapshot,(a.password_hash IS NULL) AS legacy FROM trial_sessions s
      JOIN trial_accounts a ON a.id=s.account_id WHERE s.digest=? AND s.expires_at>?`).bind(digest2, Date.now()).first();
    if (!row) throw new GameError("请重新登录试玩账号。", 401);
    const game = new RequestGameStore(JSON.parse(row.snapshot));
    let result, rejected;
    try {
      result = play(game, route, data, row.username);
    } catch (error) {
      if (!(error instanceof GameError) && error.constructor !== Error) throw error;
      rejected = error instanceof GameError ? error : new GameError(error.message);
    }
    if (game.dirty) {
      const written = await db.prepare("UPDATE trial_accounts SET snapshot=?,revision=revision+1 WHERE id=? AND revision=? AND EXISTS(SELECT 1 FROM trial_sessions WHERE digest=? AND expires_at>?)").bind(JSON.stringify(game.snapshot()), row.id, row.revision, digest2, Date.now()).run();
      if (!written.meta.changes) continue;
    }
    if (rejected) throw rejected;
    if (row.legacy && route === "page" && data.page === "login") {
      const code = await legacySetupCode(db, token, digest2);
      result.page.rows.unshift({ title: "设置密码验证码", text: code + "（15 分钟有效）。在另一个标签页打开试玩，点「旧账号设置密码」，输入验证码并设置密码。" });
    }
    const response = json(result);
    if (route === "page" && data.page === "multiplayerAccount") response.headers.set("X-PetShop-Account", "switch");
    return response;
  }
  throw new GameError("另一台设备正在保存，请重试。", 409);
}
var worker_default = {
  async fetch(request, env) {
    const url = new URL(request.url), origin = request.headers.get("origin");
    if (!url.pathname.startsWith(prefix)) return env.ASSETS ? env.ASSETS.fetch(request) : json({ error: "接口不存在。" }, 404);
    const local = ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname);
    const localOrigin = local && origin && /^http:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(origin);
    if (origin && !sites.has(origin) && !localOrigin) return json({ error: "来源不受支持。" }, 403);
    let response;
    try {
      response = request.method === "OPTIONS" ? new Response(null, { status: 204 }) : await dispatch(request, env.DB.withSession?.("first-primary") ?? env.DB, url.pathname.slice(prefix.length));
    } catch (error) {
      if (!(error instanceof GameError)) console.error("Trial account request failed", error.name);
      response = error instanceof GameError ? json({ error: error.message }, error.status) : json({ error: "暂时无法读取或保存试玩店铺。" }, 503);
    }
    response.headers.set("Vary", "Origin");
    if (origin) {
      response.headers.set("Access-Control-Allow-Origin", origin);
      response.headers.set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
      response.headers.set("Access-Control-Allow-Headers", "Authorization,Content-Type");
      response.headers.set("Access-Control-Expose-Headers", "X-PetShop-Account");
    }
    return response;
  }
};

// 外网试玩/accounts/pages-native.mjs
var prefix2 = "/petshop-api/v1/";
var posts = /* @__PURE__ */ new Set(["auth/register", "auth/login", "auth/logout", "auth/set-password", "page", "action", "heartbeat"]);
function failure(status, message) {
  return Response.json({ error: message }, { status, headers: { "Cache-Control": "no-store" } });
}
var pages_native_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith(prefix2)) return env.ASSETS.fetch(request);
    const route = url.pathname.slice(prefix2.length);
    const read = route === "health" || route === "shop" || /^receipts\/[\w-]+$/.test(route);
    if (url.search || !read && !posts.has(route)) return failure(404, "接口不存在。");
    if (request.method !== "OPTIONS" && request.method !== (read ? "GET" : "POST")) {
      return failure(405, "不支持此请求方法。");
    }
    const result = await worker_default.fetch(request, env, ctx);
    const response = new Response(result.body, result);
    response.headers.set("Cache-Control", "no-store");
    return response;
  }
};
export {
  pages_native_default as default
};
