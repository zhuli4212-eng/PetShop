# 宠物店阿里云测试服

测试包适用于 Ubuntu 22.04 或 24.04（x86-64、ARM64）。网页与账号 API 使用同一个来源。新测试库保存在服务器的 `/var/lib/petshop-trial-test/shop.sqlite`。本轮使用测试账号验证注册、原密码重登和店铺存档。

## 安装

1. 把测试发布包上传到服务器上的普通账号目录。在空目录解包，进入含有 `install.sh`、`server.mjs`、`account-service.mjs`、`schema.sql` 与 `public/` 的目录。
2. 在服务器终端运行以下命令。

   ```bash
   sudo apt-get update
   sudo bash ./install.sh
   ```

   安装器优先使用系统已有的 Node.js 24 或更新版本。需要下载时，安装器按官方 Node.js 24 Linux 发布清单核对压缩包的 SHA-256。服务器需要能从 Ubuntu 软件源及 Node.js 官网下载所需文件。首次安装会从 Ubuntu 软件包提取 nginx 程序，使用项目自己的配置运行。两个服务由 systemd 以非 root 用户启动，重启机器后会自动恢复。新版发布包用同一命令安装，测试数据库存放在版本目录之外。

3. 安装器会请求本机网页与 `/petshop-api/v1/health`。出现 `Petshop test site ready` 后，在自己的电脑上打开 PowerShell，运行以下命令，并将用户名与公网 IP 替换为实例的实际值。

   ```powershell
   ssh -N -o ExitOnForwardFailure=yes -L 127.0.0.1:8080:127.0.0.1:8080 用户名@服务器公网IP
   ```

   保持这个窗口开启，浏览器打开 **http://127.0.0.1:8080/**。服务器上的网页和 API 分别仅监听 `127.0.0.1:8080` 和 `127.0.0.1:8787`。SSH 隧道通过现有 SSH 连接传输。

4. 注册一个测试账号，完成一次签到或繁育。关闭浏览器，在新的浏览器窗口用同一账号和密码登录，核对店铺进度。用第二个测试账号分别登录，核对两个店铺各自的进度。

## 查看服务

```bash
curl -fsS http://127.0.0.1:8080/petshop-api/v1/health
systemctl status petshop-trial-test.service petshop-trial-test-web.service --no-pager
sudo journalctl -u petshop-trial-test.service -u petshop-trial-test-web.service -n 40 --no-pager
```

SQLite 采用 WAL 模式。备份运行中的店铺时，使用 SQLite 在线备份接口生成一致快照，再复制到独立存储。修改监听地址、绑定正式域名和迁移正式玩家数据属于正式切换阶段。
