import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, isAbsolute } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

// These are the D1 operations used by the released account service. An entire
// batch executes synchronously on a single SQLite connection and transaction.
class BoundStatement {
  constructor(statement, values = []) {
    this.statement = statement;
    this.values = values;
  }

  bind(...values) {
    return new BoundStatement(this.statement, values);
  }

  first() {
    return this.statement.get(...this.values) ?? null;
  }

  run() {
    const { changes } = this.statement.run(...this.values);
    return { meta: { changes } };
  }
}

export function openAccountDatabase(filename) {
  if (!filename || !isAbsolute(filename)) throw Error('PETSHOP_DB must be an absolute SQLite file path.');
  mkdirSync(dirname(filename), { recursive: true, mode: 0o700 });
  const conn = new DatabaseSync(filename);
  try {
    conn.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
    const schema = readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');
    conn.exec('BEGIN IMMEDIATE;\n' + schema + '\nCOMMIT;');
  } catch (error) {
    conn.close();
    throw error;
  }

  const statements = new Map();
  return {
    prepare(sql) {
      if (!statements.has(sql)) statements.set(sql, conn.prepare(sql));
      return new BoundStatement(statements.get(sql));
    },
    batch(items) {
      conn.exec('BEGIN IMMEDIATE');
      try {
        const results = items.map(item => item.run());
        conn.exec('COMMIT');
        return results;
      } catch (error) {
        if (conn.isTransaction) conn.exec('ROLLBACK');
        throw error;
      }
    },
    close() {
      conn.close();
    },
  };
}
