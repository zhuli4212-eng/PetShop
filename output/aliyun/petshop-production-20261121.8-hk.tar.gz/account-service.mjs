// output/aliyun/source-market-breed-20261121/外网试玩/accounts/worker.mjs
import { createHash as createHash4, createHmac as createHmac2, randomBytes as randomBytes4, randomUUID as randomUUID6 } from "node:crypto";

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-engine.mjs
import { randomBytes as randomBytes2, randomUUID as randomUUID5 } from "node:crypto";

// output/aliyun/source-market-breed-20261121/PetShop/server/care.mjs
import { createHash as createHash2, randomBytes, randomUUID as randomUUID3 } from "node:crypto";

// output/aliyun/source-market-breed-20261121/PetShop/server/business.mjs
import { createHash, randomInt, randomUUID } from "node:crypto";

// output/aliyun/source-market-breed-20261121/PetShop/server/research-effects.mjs
function rareRedrawPercent(level) {
  return 10 * (1 + 0.05 * level);
}
function scoreRiseChance(baseGrade, otherGrade, level) {
  let chance = [0.18, 0.18, 0.18, 0.18, 0.07, 0.03, 0][baseGrade];
  if (otherGrade < baseGrade - 1) chance = Math.min(chance, 0.03);
  return Math.min(0.9, chance * (1 + 0.03 * level));
}
function bredValuePercent(level) {
  return 20 + level * 0.5;
}
function percent(value) {
  return Number(value.toFixed(2)) + "%";
}
function researchBonus(branch, level) {
  if (branch === 2) return percent(bredValuePercent(level));
  return (level ? "+" : "") + percent((branch === 0 ? 5 : 3) * level);
}
function researchBenefit(branch, level, speciesName2, mutationEnabled = true) {
  const maxed = level >= 10, next = maxed ? level : level + 1;
  const currentBonus = researchBonus(branch, level);
  const nextBonus = maxed ? null : researchBonus(branch, next);
  let valueLabel, description, delta, example, overview, currentValue, nextValue, switchNote = "";
  if (branch === 0) {
    valueLabel = "重抽出稀有";
    const from = rareRedrawPercent(level), to = rareRedrawPercent(next);
    currentValue = percent(from);
    nextValue = maxed ? null : percent(to);
    overview = "重抽出稀有 " + currentValue + (maxed ? "" : " → " + nextValue);
    description = "升级后再配对，幼" + speciesName2 + "的前五项特征若重新抽标签，就更容易抽到稀有。";
    delta = maxed ? "" : "升这一级，重抽出稀有的机会增加 0.5 个百分点。";
    example = "重抽一个标签时，稀有机会" + (maxed ? "是 " + currentValue : "从 " + currentValue + " 升到 " + nextValue) + "。";
  } else if (branch === 1) {
    valueLabel = "双亲 B 时升 A";
    const from = 100 * scoreRiseChance(3, 3, level), to = 100 * scoreRiseChance(3, 3, next);
    currentValue = percent(from);
    nextValue = maxed ? null : percent(to);
    overview = "双亲 B 时升 A " + currentValue + (maxed ? "" : " → " + nextValue);
    description = "开启选育加成后再配对，幼" + speciesName2 + "的前五项评分各有机会升一档，最高 S+。机会取决于父母的评分。";
    delta = maxed ? "" : "升这一级，多出原本升档机会的 3%。";
    example = "例如父母毛发都是 B，幼体毛发升 A 的机会" + (maxed ? "是 " + currentValue : "从 " + currentValue + " 升到 " + nextValue + "，多 " + Number((to - from).toFixed(2)) + " 个百分点") + "。";
    if (!mutationEnabled) switchNote = "本房选育加成已关闭，配对前可在繁育台打开。";
  } else {
    valueLabel = "估价 200 时";
    const from = 2 * bredValuePercent(level), to = 2 * bredValuePercent(next);
    currentValue = from + " 金币";
    nextValue = maxed ? null : to + " 金币";
    overview = "估价 200，繁育后保留 " + from + (maxed ? "" : " → " + to) + " 金币";
    description = "卖出繁育过的" + speciesName2 + "时，它能多保留一些原本的身价。荣誉和买家的加价另算。";
    delta = maxed ? "" : "升这一级，基础估价多保留 0.5 个百分点。";
    example = "例如基础估价 200 金币，繁育后" + (maxed ? "保留 " + currentValue : "从 " + currentValue + " 增至 " + nextValue) + "。";
  }
  return {
    bonusLabel: branch === 2 ? "保留比例" : "比基础机会多",
    valueLabel,
    metric: valueLabel,
    description,
    currentBonus,
    nextBonus,
    currentValue,
    nextValue,
    overview,
    delta,
    example,
    switchNote
  };
}

// output/aliyun/source-market-breed-20261121/PetShop/server/defect.mjs
var GRADES = ["E", "D", "C", "B", "A", "S", "S+"];
var defectLabels = ["严重缺陷", "明显缺陷", "轻微缺陷", "基本健全", "状态良好", "接近完美", "完美无缺"];
var traitWeights = [15, 20, 15, 25, 25];
var perfectByGrade = [1, 2, 3, 5, 10, 18, 30];
var gapTable = [
  { gap: 0, e: 0, d: 0.5, c: 1.5, a: 14, match: 1 },
  { gap: 2, e: 1, d: 4, c: 10, a: 10, match: 0.6 },
  { gap: 6, e: 24, d: 27, c: 29, a: 2, match: 0.2 }
];
var defectDisplayLabel = (grade) => defectLabels[GRADES.indexOf(grade)];
function defectTrait(grade) {
  return { type: "缺陷", label: defectDisplayLabel(grade), rarity: "普通", grade };
}
function defectProbabilities(motherTraits, fatherTraits) {
  let gapSum = 0, perfectSum = 0;
  for (const [i, weight] of traitWeights.entries()) {
    const mother = GRADES.indexOf(motherTraits[i].grade);
    const father = GRADES.indexOf(fatherTraits[i].grade);
    gapSum += weight * Math.abs(mother - father);
    perfectSum += weight * perfectByGrade[Math.min(mother, father)];
  }
  const gap = gapSum / 100;
  const segment = gap <= gapTable[1].gap ? 0 : 1;
  const low = gapTable[segment], high = gapTable[segment + 1];
  const fraction = (gap - low.gap) / (high.gap - low.gap);
  const interpolate = (key) => low[key] + (high[key] - low[key]) * fraction;
  const e = interpolate("e"), d = interpolate("d"), c = interpolate("c"), a = interpolate("a");
  const mildPercent = d + c, defectPercent = e + mildPercent;
  const perfectPercent = perfectSum / 100 * interpolate("match");
  const b = 100 - defectPercent - a - perfectPercent;
  const gradePercents = [e, d, c, b, a, perfectPercent * 0.8, perfectPercent / 5];
  return { defectPercent, perfectPercent, obviousPercent: e, mildPercent, gradePercents };
}

// output/aliyun/source-market-breed-20261121/PetShop/server/animal-traits.mjs
var TAG_RULES_VERSION = 2;
var TRAIT_FIELDS = ["性格", "品相", "毛发", "体态", "体型"];
var definitions = [
  [["gentle", "温顺"], ["curious", "好奇"], ["friendly", "亲人"], ["calm", "沉稳"], ["bold", "大胆"], ["composed", "从容"]],
  [["round-eyes", "圆眼"], ["delicate", "清秀"], ["fine-brows", "秀眉"], ["bright-eyes", "眼神明亮"], ["lively-eyes", "眼神灵动"]],
  [["soft", "柔软"], ["smooth", "顺毛"], ["dense", "细密"], ["velvety", "绒感"], ["silky", "丝光"], ["lustrous", "绒光"]],
  [["balanced", "匀称"], ["relaxed", "舒展"], ["light-step", "步态轻盈"], ["upright", "站姿端正"], ["graceful", "仪态出众"]],
  [["compact", "紧凑"], ["slender", "修长"], ["even-frame", "骨架匀整"], ["flowing-outline", "轮廓流畅"], ["well-proportioned", "比例匀美"]]
];
var dimensionIds = ["temperament", "appearance", "coat", "posture", "build"];
function tagIdFor(dimension, label) {
  const entry2 = definitions[dimension]?.find(([, name]) => name === label);
  return entry2 ? dimensionIds[dimension] + ":" + entry2[0] : "legacy:" + dimension + ":" + encodeURIComponent(label);
}
function traitTag(trait, dimension) {
  if (dimension < 0 || dimension >= 5 || !trait || typeof trait.label !== "string" || !trait.label) return null;
  return {
    dimension,
    type: trait.type ?? TRAIT_FIELDS[dimension],
    grade: trait.grade,
    tagId: typeof trait.tagId === "string" && trait.tagId ? trait.tagId : tagIdFor(dimension, trait.label),
    label: trait.label,
    rarity: trait.rarity
  };
}
function getPetTags(pet) {
  return (pet?.traits ?? []).slice(0, 5).flatMap((trait, dimension) => {
    const tag = traitTag(trait, dimension);
    return tag ? [tag] : [];
  });
}
function traitCapacity(pet) {
  const score = pet.traits.reduce((sum, trait) => sum + GRADES.indexOf(trait.grade) * 20, 0);
  const limit = score < 300 ? 1 : score < 400 ? 2 : score < 480 ? 3 : score < 580 ? 4 : 5;
  return { score, band: limit, limit };
}
function cardQualityScore(traits) {
  if (traits?.length !== 6) return void 0;
  const grades2 = traits.map((trait) => GRADES.indexOf(trait?.grade));
  if (grades2.some((grade) => grade < 0)) return void 0;
  const ordinary = grades2.slice(0, 5).reduce((sum, grade) => sum + grade * 20, 0);
  return ordinary * (4 + 2 * grades2[5]) / 10;
}
function taggedTraits(gradedTraits, makeTag, random = Math.random) {
  const { limit } = traitCapacity({ traits: gradedTraits });
  let count = 1;
  for (let slot = 1; slot < limit; slot++) if (random() < 0.8) count++;
  const available = [0, 1, 2, 3, 4], chosen = /* @__PURE__ */ new Set();
  for (let slot = 0; slot < count; slot++) {
    const index = Math.floor(random() * available.length);
    chosen.add(available.splice(index, 1)[0]);
  }
  const traits = gradedTraits.map((trait, dimension) => {
    if (dimension === 5) return { ...trait };
    const result = { type: trait.type ?? TRAIT_FIELDS[dimension], grade: trait.grade, tagId: null, label: null, rarity: null };
    if (chosen.has(dimension)) {
      const tag = makeTag(dimension);
      result.tagId = tag.tagId ?? tagIdFor(dimension, tag.label);
      result.label = tag.label;
      result.rarity = tag.rarity;
    }
    return result;
  });
  return { traits, tagRulesVersion: TAG_RULES_VERSION, tagCount: count };
}
function fixedTagSubset(traits, random = Math.random) {
  return taggedTraits(traits, (dimension) => traits[dimension], random);
}
function inheritedTag(dimension, mother, father, redraw, random = Math.random) {
  const source = random();
  const inherited = source < 0.35 ? traitTag(father.traits[dimension], dimension) : source < 0.7 ? traitTag(mother.traits[dimension], dimension) : null;
  return inherited ?? redraw(dimension);
}
function reviewedRarity(rarity, random = Math.random) {
  if (rarity === "普通") return random() < 0.9 ? "少见" : "稀有";
  if (rarity === "少见") return random() < 0.9 ? "普通" : "稀有";
  if (rarity === "稀有") return random() < 0.2 ? "普通" : "少见";
  throw new Error("这条标签的稀有度无法复评，请重新查看动物档案。");
}
function normalizeAnimalTags(pet) {
  if (!pet?.traits) return false;
  let changed = false;
  for (const tag of getPetTags(pet)) {
    if (!pet.traits[tag.dimension].tagId) {
      pet.traits[tag.dimension].tagId = tag.tagId;
      changed = true;
    }
  }
  if (pet.tagRulesVersion === void 0) {
    pet.tagRulesVersion = 1;
    changed = true;
  }
  if (pet.tagCount === void 0) {
    pet.tagCount = getPetTags(pet).length;
    changed = true;
  }
  return changed;
}
function normalizeStoredTags(state) {
  const animals2 = [...state.pets ?? [], ...state.onboarding?.offers ?? []];
  for (const room of Object.values(state.rooms ?? {})) {
    animals2.push(
      ...room.shelf?.offers ?? [],
      room.reservedSeed?.offer,
      room.job?.mother,
      room.job?.father,
      ...room.job?.offspring ?? []
    );
  }
  let changed = false;
  for (const pet of animals2) if (normalizeAnimalTags(pet)) changed = true;
  return changed;
}

// output/aliyun/source-market-breed-20261121/PetShop/server/business.mjs
var minute = 6e4;
var day = 24 * 60 * minute;
var speciesList = ["rabbit", "cat", "dog"];
var gradeNames = ["E", "D", "C", "B", "A", "S", "S+"];
var baseValues = { rabbit: 100, cat: 1200, dog: 1300 };
var breedFactors = [100, 110, 120, 135];
var stageFactors = { 幼年: 80, 成长: 92, 成年: 100, 老年: 65, 已故: 0 };
var channelNames = { market: "自由市场", order: "订单交付", recycle: "动物回收", guest: "来客委托" };
var researchNames = ["稀有标签研究", "五维选育研究", "繁育后价值研究"];
var researchBases = { rabbit: 100, cat: 250, dog: 400 };
var ornaments = {
  fence: { name: "矮篱", base: 80 },
  lamp: { name: "台灯", base: 60 },
  plant: { name: "盆栽", base: 100 },
  rug: { name: "地毯", base: 120 }
};
var bjDay = (now) => new Date(now + 8 * 60 * minute).toISOString().slice(0, 10);
var timeLabel = (now) => new Date(now + 8 * 60 * minute).toISOString().slice(5, 16).replace("T", " ");
var choose = (list) => list[randomInt(list.length)];
function weighted(weights) {
  let roll = randomInt(weights.reduce((sum, n) => sum + n, 0));
  for (let i = 0; i < weights.length; i++) {
    roll -= weights[i];
    if (roll < 0) return i;
  }
}
var speciesName = (key) => SPECIES[key].name;
var roomKeys = (s, asOf) => speciesList.filter((key) => s.rooms[key] && s.rooms[key].openedAt <= asOf);
var requireValue = (condition, message) => {
  if (!condition) throw new Error(message);
};
var halfUp = (numerator, denominator) => Math.floor((2 * numerator + denominator) / (2 * denominator));
function purchasePrice(s, base) {
  return 10 * Math.ceil(base * (2e5 - (s.ratingBps || 0)) / 2e6);
}
function quality(p) {
  const indexSum = p.traits.reduce((total, trait) => total + gradeNames.indexOf(trait.grade), 0);
  const normalised = getPetTags(p);
  return 600 + 5 * (indexSum - 18) + 18 * normalised.filter((t) => t.rarity === "少见").length + 48 * normalised.filter((t) => t.rarity === "稀有").length;
}
function breedBase(p) {
  const index = SPECIES[p.species].breeds.indexOf(p.breedKey);
  return baseValues[p.species] * (p.mixed ? 100 : breedFactors[index]) / 100;
}
function youngPurchaseBase(p) {
  const youngValue = halfUp(breedBase(p) * 80 * quality(p), 6e4);
  return 10 * Math.ceil(28 * youngValue / 100);
}
function valuation(s, p, now) {
  const base = breedBase(p);
  const q = quality(p);
  const stage = stageOf(p, now);
  const value = halfUp(base * q * stageFactors[stage], 6e4);
  const adult = halfUp(base * q, 600);
  const minimum = Math.max(1, Math.floor(6 * base / 100));
  const bredRate = bredValuePercent(s.research[p.species]?.[2] ?? 0);
  const retained = p.bred ? Math.max(minimum, halfUp(value * bredRate, 100)) : value;
  const honor = Math.floor(base * Math.round((p.honor || 0) * 100) / 100);
  const deadPrice = honor ? Math.max(minimum, Math.floor((adult + 5 * honor) / 10)) : minimum;
  const multiplier = 1e4 + (s.ratingBps || 0);
  return { base, qualityUnits: q, stage, stagePercent: stageFactors[stage], value, adult, minimum, bredRate, retained, honor, deadPrice, multiplier };
}
function salePrice(s, p, now, channel, rate = 100) {
  const { stage, deadPrice, multiplier, retained, honor } = valuation(s, p, now);
  if (channel === "recycle") {
    requireValue(stage === "已故", "研究所只回收已故动物。");
    return halfUp(deadPrice * multiplier, 1e4);
  }
  return halfUp(multiplier * (retained * rate + 100 * honor), 1e6);
}
function reachableOrderTagPool(s, species, rarityIndex, date) {
  const candidates = s.pets.filter((p) => p.species === species && stageOf(p, date) !== "已故");
  candidates.push(...(s.rooms[species].shelf?.offers ?? []).filter(Boolean));
  const reserved = s.rooms[species].reservedSeed;
  if (reserved && date >= reserved.readyAt && date < reserved.expiresAt) candidates.push(reserved.offer);
  const tags = new Set(candidates.flatMap(getPetTags).map((tag) => tag.tagId));
  return TRAITS.some((pools, dimension) => pools[rarityIndex].some((label) => tags.has(tagIdFor(dimension, label))));
}
function makeOrder(s, date, first = false) {
  const species = choose(roomKeys(s, date));
  const diff = first ? 0 : weighted([70, 25, 5]);
  const order = { id: randomUUID(), species, diff, rate: [135, 155, 180][diff] };
  if (diff && randomInt(2)) {
    order.breed = SPECIES[species].breeds[diff === 2 ? 3 : weighted([4, 3, 2])];
  } else if (diff) {
    if (reachableOrderTagPool(s, species, diff - 1, date)) {
      const dimension = randomInt(5);
      order.tag = choose(TRAITS[dimension][diff - 1]);
      order.tagId = tagIdFor(dimension, order.tag);
    } else {
      order.breed = SPECIES[species].breeds[diff === 2 ? 3 : weighted([4, 3, 2])];
    }
  }
  return order;
}
function orderCondition(order) {
  const pet = speciesName(order.species);
  if (order.breed) return "登记品种为" + BREEDS[order.breed].name;
  if (order.tag) return pet + " · 带「" + order.tag + "」标签";
  return pet + " · 任意品种";
}
function matchesOrder(p, order) {
  return p.species === order.species && (!order.breed || !p.mixed && p.breedKey === order.breed) && (!order.tag && !order.tagId || getPetTags(p).some((t) => order.tagId ? t.tagId === order.tagId : t.label === order.tag));
}
function offerIncome(s, offer, order, now) {
  return salePrice(s, { ...offer, bornAt: now }, now, "order", order.rate);
}
function offerOrderRows(s, offer, now) {
  const rows = [];
  for (const [index, { order }] of (s.orders ?? []).entries()) {
    if (!order || !matchesOrder(offer, order)) continue;
    rows.push({ title: "可交第 " + (index + 1) + " 单", text: orderCondition(order) + " · 购入后立即交付，预计收入 " + offerIncome(s, offer, order, now) + " 金币。" });
  }
  return rows.length ? rows : [{ title: "当前普通订单", text: "这只幼体目前没有匹配的普通订单。" }];
}
function orderStockRows(s, order, now) {
  const speciesPets = s.pets.filter((p) => p.species === order.species);
  const matching = speciesPets.filter((p) => matchesOrder(p, order));
  const rows = [{ title: "所需物种 · " + speciesName(order.species), text: "本店持有 " + speciesPets.length + " 只。" }];
  if (order.breed || order.tag) rows.push({
    title: order.breed ? "所需登记品种 · " + BREEDS[order.breed].name : "所需标签 · " + order.tag,
    text: "该物种中符合此项的有 " + matching.length + " 只。"
  });
  const counts = /* @__PURE__ */ new Map();
  for (const p of matching) {
    const reason = saleBlock(s, p, now, "order") || "可交付";
    counts.set(reason, (counts.get(reason) || 0) + 1);
  }
  rows.push({
    title: "本店可交付 " + (counts.get("可交付") || 0) + " 只",
    text: [...counts].filter(([reason]) => reason !== "可交付").map(([reason, n]) => reason + " " + n + " 只").join(" · ") || (matching.length ? "符合条件的在店动物均可交付。" : "当前没有符合全部条件的在册动物。")
  });
  const offers = (s.rooms[order.species]?.shelf?.offers || []).filter((p) => p && matchesOrder(p, order));
  if (offers.length) {
    for (const offer of offers) rows.push({ ...linkRow(
      "可采购 · " + offer.name + "（" + offer.sex + "）",
      "尚未持有 · 购价 " + purchasePrice(s, youngPurchaseBase(offer)) + " 金币 · 立即交付预计收入 " + offerIncome(s, offer, order, now) + " 金币，成交前重新核价。",
      "offer",
      { species: order.species, id: offer.id },
      petArt(offer)
    ), stage: "幼年" });
  } else rows.push({ title: "本批货架", text: "目前没有符合这张订单的在售幼体。下一批随机供货。" });
  return rows;
}
function readyOrderId(s, now) {
  return s.orders.find(({ order }) => order && canFillOrder(s, order, now))?.order.id ?? null;
}
var canFillOrder = (s, order, now) => s.pets.some((p) => !saleBlock(s, p, now, "order") && matchesOrder(p, order));
function daily(s, now) {
  const date = bjDay(now);
  if (s.businessDay?.date !== date) s.businessDay = { date, freeUsed: 0, bought: 0, arrived: 0 };
}
function initBusiness(s, now) {
  s.research ||= Object.fromEntries(speciesList.map((key) => [key, [0, 0, 0]]));
  s.orders ||= Array.from({ length: 3 }, (_, i) => ({ order: makeOrder(s, now, i === 0), readyAt: null }));
  s.cancelCredits ??= 0;
  s.decor ||= Object.fromEntries(Object.keys(ornaments).map((key) => [key, { owned: false, placed: false }]));
  s.visitors ||= { active: null, elapsed: 0, misses: 0, sessions: {}, intervals: [], since: now };
  s.sales ||= [];
  daily(s, now);
}
function endVisit(v, time3) {
  v.active = null;
  v.elapsed = 0;
  v.misses = 0;
  v.intervals = [];
  v.since = time3;
}
function tickBusiness(s, now) {
  daily(s, now);
  for (const slot of s.orders) {
    if (!slot.order && now >= slot.readyAt) {
      slot.order = makeOrder(s, slot.readyAt);
      slot.order.refilledAt = slot.readyAt;
      slot.readyAt = null;
    }
  }
  const v = s.visitors;
  if (v.active && now >= v.active.endsAt) endVisit(v, v.active.endsAt);
  for (const [key, last] of Object.entries(v.sessions)) {
    if (now - last > minute) delete v.sessions[key];
  }
}
function visitorRequirements(p, stage) {
  const base = { species: p.species, breed: p.mixed ? "mixed" : p.breedKey, stage };
  const list = [];
  getPetTags(p).forEach((t) => {
    if (gradeNames.indexOf(t.grade) >= 4) list.push({ ...base, dimension: t.dimension, tag: t.label, tagId: t.tagId, tagRulesVersion: 2 });
  });
  if (gradeNames.indexOf(p.traits[1].grade) >= 4) {
    list.push({ ...base, coat: BREEDS[p.breedKey].coats[p.coatIndex - 1] });
  }
  return list;
}
function pickVisit(s, now) {
  const immediate = [], future = [];
  for (const p of s.pets) {
    if (saleBlock(s, p, now, "guest")) continue;
    let at = now;
    while (at <= now + 25 * minute) {
      const stage = stageOf(p, at), end = stageEnd(p, at);
      if (stage === "已故" || !end || end <= at) break;
      const isNow = at === now;
      if (end - at >= (isNow ? 2 : 5) * minute) {
        (isNow ? immediate : future).push(...visitorRequirements(p, stage));
      }
      at = end;
    }
  }
  const pool = immediate.length && future.length ? randomInt(100) < 70 ? immediate : future : immediate.length ? immediate : future;
  if (!pool.length) return null;
  const species = choose([...new Set(pool.map((r) => r.species))]);
  const bySpecies = pool.filter((r) => r.species === species);
  const tag = choose([...new Set(bySpecies.map((r) => Boolean(r.tag)))]);
  const unique = new Map(bySpecies.filter((r) => Boolean(r.tag) === tag).map((r) => [JSON.stringify(r), r]));
  return choose([...unique.values()]);
}
function matchesVisit(p, request, now) {
  if (p.species !== request.species || (p.mixed ? "mixed" : p.breedKey) !== request.breed || stageOf(p, now) !== request.stage) return false;
  if (request.tag) {
    const trait = getPetTags(p).find((t) => t.dimension === request.dimension);
    return Boolean(trait && (request.tagId ? trait.tagId === request.tagId : trait.label === request.tag) && (request.tagRulesVersion === 2 || trait.rarity === request.rarity) && gradeNames.indexOf(trait.grade) >= 4);
  }
  return request.coat === BREEDS[p.breedKey].coats[p.coatIndex - 1] && gradeNames.indexOf(p.traits[1].grade) >= 4;
}
function visitCondition(v) {
  const r = v.requirement;
  return [
    r.breed === "mixed" ? "杂交" + speciesName(r.species) : BREEDS[r.breed].name,
    r.stage,
    r.tag ? (r.tagRulesVersion === 2 ? "" : r.rarity) + "标签「" + r.tag + "」且该维至少A" : r.coat + "花色且品相至少A"
  ].join(" · ");
}
function addInterval(v, start, end) {
  const intervals = v.intervals.filter((pair2) => pair2[1] >= end - 3e4);
  const previous = intervals.reduce((sum, [a, b]) => sum + b - a, 0);
  intervals.push([start, end]);
  intervals.sort((a, b) => a[0] - b[0]);
  const merged = [];
  for (const pair2 of intervals) {
    const tail = merged.at(-1);
    if (tail && tail[1] >= pair2[0]) tail[1] = Math.max(tail[1], pair2[1]);
    else merged.push([...pair2]);
  }
  v.intervals = merged;
  v.elapsed += merged.reduce((sum, [a, b]) => sum + b - a, 0) - previous;
}
function businessHeartbeat(s, { clientId, foreground }, now) {
  requireValue(typeof clientId === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(clientId), "连接标识无效。");
  const v = s.visitors, key = "client:" + clientId, last = v.sessions[key];
  if (!foreground) {
    delete v.sessions[key];
    return;
  }
  v.sessions[key] = now;
  if (v.active || s.businessDay.arrived >= 6 || last === void 0 || now - last > 3e4 || now <= last) return;
  addInterval(v, Math.max(last, v.since), now);
  if (v.elapsed < 10 * minute) return;
  v.elapsed -= 10 * minute;
  const requirement = pickVisit(s, now);
  if (!requirement) return;
  if (v.misses < 2 && randomInt(100) >= 35) {
    v.misses++;
    return;
  }
  v.active = { id: randomUUID(), requirement, endsAt: now + 30 * minute };
  v.elapsed = 0;
  v.misses = 0;
  s.businessDay.arrived++;
}
function saleTarget(s, args, now) {
  const channel = args.channel;
  requireValue(Object.hasOwn(channelNames, channel), "请选择出售渠道。");
  if (channel === "order") {
    const slot = s.orders.find((entry2) => entry2.order?.id === args.targetId);
    requireValue(slot, "这张委托已经结束，请返回订单夹。");
    const onboarding = s.onboarding;
    const quoteAtBirth = (p) => onboarding?.orderId === slot.order.id && onboarding.litterIds?.includes(p.id);
    return {
      channel,
      rate: slot.order.rate,
      condition: orderCondition(slot.order),
      slot,
      quoteAtBirth,
      eligible: (p) => matchesOrder(p, slot.order)
    };
  }
  if (channel === "guest") {
    const guest = s.visitors.active;
    requireValue(guest && guest.id === args.targetId && now < guest.endsAt, "这位客人已经离店。");
    return { channel, rate: 215, condition: visitCondition(guest), eligible: (p) => matchesVisit(p, guest.requirement, now) };
  }
  if ((channel === "market" || channel === "recycle") && args.species !== void 0) {
    requireValue(Object.hasOwn(SPECIES, args.species), "请选择要出售动物的房间。");
    const name = speciesName(args.species) + "房";
    const condition = channel === "market" ? "收购" + name + "的空闲活体" : name + " · 仅回收已故动物";
    return {
      channel,
      species: args.species,
      rate: 100,
      condition,
      eligible: (p) => p.species === args.species
    };
  }
  return {
    channel,
    rate: 100,
    condition: channel === "market" ? "收购空闲的在店活体" : "仅回收已故动物",
    eligible: () => true
  };
}
function saleBlocks(s, p, now, channel) {
  const reasons = [], deceased = stageOf(p, now) === "已故";
  if (channel === "recycle" && !deceased) reasons.push("活体");
  if (isBusy(s, p)) reasons.push("繁育中");
  if (channel !== "recycle" && deceased) reasons.push("已故");
  if (p.retained) reasons.push("种源保护");
  return reasons;
}
function saleBlock(s, p, now, channel) {
  return saleBlocks(s, p, now, channel)[0];
}
function petCaption(p, now, status = p.bred ? "已繁育" : "未繁育") {
  return [
    breedName(p),
    BREEDS[p.breedKey].coats[p.coatIndex - 1],
    p.sex,
    stageOf(p, now),
    status,
    ...p.retained ? ["种源"] : []
  ].join(" · ");
}
function marketBreed(args, species) {
  if (args.breed === "mixed") return args.breed;
  const config = Object.hasOwn(BREEDS, args.breed) ? BREEDS[args.breed] : void 0;
  return config && (!species || config.species === species) ? args.breed : void 0;
}
function quoteSelection(s, args, now, agreedAmounts) {
  const ids = args.ids;
  requireValue(Array.isArray(ids) && ids.length && new Set(ids).size === ids.length, "请勾选动物，每只只能选一次。");
  let target;
  const filter = args.channel === "market" ? rosterFilter(args.filter) : "全部";
  const stage = args.channel === "market" ? rosterStage(args.stage, args.filter) : "全部";
  const breed = args.channel === "market" ? marketBreed(args, args.species) : void 0;
  const lines = [], issues = [];
  try {
    target = saleTarget(s, args, now);
  } catch (error) {
    if (args.channel !== "order" && args.channel !== "guest") throw error;
    issues.push(error.message);
  }
  const byId = new Map(s.pets.map((p) => [p.id, p]));
  const departed = /* @__PURE__ */ new Map(), missing = new Set(ids.filter((id) => !byId.has(id)));
  if (missing.size) for (const sale of s.sales || []) {
    for (const line of sale.lines) if (missing.has(line.id)) departed.set(line.id, line.name);
  }
  for (const [index, id] of ids.entries()) {
    const p = byId.get(id);
    const name = (p?.name || departed.get(id) || "所选动物") + " #" + String(id).slice(0, 6).toUpperCase();
    if (!p) {
      issues.push(name + "已离店");
      continue;
    }
    const blocked = saleBlock(s, p, now, args.channel);
    if (blocked || target && !target.eligible(p)) {
      const reason = { 活体: "仍在世，研究所只回收已故动物", 种源保护: "已标记为种源" }[blocked] || blocked;
      issues.push(name + (reason ? "（" + reason + "）" : "") + "不再符合交付条件");
      continue;
    }
    if (!rosterFilters[filter](s, p, now)) {
      issues.push(name + "已不符合「" + filter + "」筛选");
      continue;
    }
    if (stage !== "全部" && stageOf(p, now) !== stage) {
      issues.push(name + "已不符合「" + stage + "」筛选，目前为" + stageOf(p, now));
      continue;
    }
    if (breed && (p.mixed ? "mixed" : p.breedKey) !== breed) {
      issues.push(name + "已不符合「" + (breed === "mixed" ? "杂交" : BREEDS[breed].name) + "」筛选");
      continue;
    }
    if (!target) continue;
    const amount = salePrice(s, p, target.quoteAtBirth?.(p) ? p.bornAt : now, args.channel, target.rate);
    if (Array.isArray(agreedAmounts) && agreedAmounts[index] !== amount) {
      issues.push(name + "现价 " + amount + " 金币");
    }
    lines.push({ id, name: p.name, amount });
  }
  if (issues.length) throw new Error(issues.map((text) => text.replace(/。$/, "")).join("。") + "。请重新核价。");
  const selected = new Set(ids), risks = [];
  for (const species of speciesList) for (const sex of ["母", "公"]) {
    const remaining = s.pets.filter((p) => p.species === species && p.sex === sex && !p.bred && !isBusy(s, p) && stageOf(p, now) !== "已故");
    if (remaining.length && remaining.every((p) => selected.has(p.id))) risks.push(speciesName(species) + "房最后的未繁育" + sex + speciesName(species));
  }
  const terms = [target.channel, args.targetId || null, lines, risks];
  if (target.species) terms.push(target.species);
  if (filter !== "全部") terms.push(filter);
  if (stage !== "全部") terms.push({ stage });
  if (breed) terms.push({ breed });
  const hash2 = createHash("sha256").update(JSON.stringify(terms)).digest("hex");
  return { target, lines, risks, hash: hash2, filter, stage, breed, total: lines.reduce((sum, row2) => sum + row2.amount, 0) };
}
function validateSaleQuote(s, args, now) {
  const quote = quoteSelection(s, args, now, args.amounts);
  requireValue(quote.hash === args.hash, "报价或未繁育动物余量已变化，请重新核价后再确认。");
  let kept = [];
  if (args.litterRetention) {
    if (args.channel !== "market") throw new Error("请从本窝的自由市场报价确认。");
    kept = retainedLitterPets(s, args.litterRetention, args.ids, now);
  }
  return { quote, kept };
}
function saleCommit(s, args, now) {
  const { quote, kept } = validateSaleQuote(s, args, now);
  const ids = new Set(args.ids);
  for (const p of kept) p.retained = true;
  s.pets = s.pets.filter((p) => !ids.has(p.id));
  s.coins += quote.total;
  s.sales.push({ at: now, channel: args.channel, targetId: args.targetId || null, lines: quote.lines, total: quote.total });
  if (quote.target.slot) {
    quote.target.slot.order = null;
    quote.target.slot.readyAt = now + 30 * minute;
  }
  if (args.channel === "guest") endVisit(s.visitors, now);
  return "已交付 " + ids.size + " 只，收入 " + quote.total + " 金币。";
}
function researchCost(s, species, target) {
  return purchasePrice(s, researchBases[species] * target * target);
}
function requirements(branch, level) {
  if (level <= 3) return [];
  return (level <= 6 ? [(branch + 1) % 3] : [0, 1, 2].filter((b) => b !== branch)).map((index) => ({ index, needed: level - 3 }));
}
function researchState(s, species, branch) {
  requireValue(speciesList.includes(species) && Number.isInteger(branch) && branch >= 0 && branch < 3, "研究项目不存在。");
  const levels = s.research[species], level = levels[branch];
  if (!s.rooms[species]) return "房间未开放";
  if (level === 10) return "已满级";
  if (requirements(branch, level + 1).some((r) => levels[r.index] < r.needed)) return "前置不足";
  if (s.coins < researchCost(s, species, level + 1)) return "金币不足";
  return "可研究";
}
var nextPage = (label, page, args = {}) => ({ label, page, args });
var linkRow = (title, text, page, args = {}, art) => ({ title, text, art, link: { page, args } });
function marketRoster(s, page, args, target, now) {
  const breed = marketBreed(args, target.species);
  const scope = { channel: "market", ...target.species && { species: target.species }, ...breed && { breed } };
  const breeds = (target.species ? [target.species] : speciesList).flatMap((key) => SPECIES[key].breeds);
  const breedOptions = [["", "全部"], ...breeds.map((key) => [key, BREEDS[key].name])];
  if (breed === "mixed" || s.pets.some((p) => p.mixed && target.eligible(p))) breedOptions.push(["mixed", "杂交"]);
  const rows = [], counts = { "种源保护": 0, "繁育中": 0, "已故": 0 };
  let eligibleCount = 0;
  for (const p of s.pets) {
    if (!target.eligible(p) || breed && (p.mixed ? "mixed" : p.breedKey) !== breed) continue;
    const reasons2 = saleBlocks(s, p, now, "market");
    const animal = specimen(s, p, now), summary = petCaption(p, now, animal.status);
    const visual = { name: animal.name, number: animal.number, summary };
    const row2 = { ...linkRow(p.name, summary + " · #" + animal.number, "pet", { id: p.id }, animal.art), animal, stage: animal.stage, visual };
    if (reasons2.length) {
      for (const reason of reasons2) counts[reason]++;
      visual.blockedReason = reasons2.join(" · ");
      row2.text += " · 不可出售：" + visual.blockedReason;
    } else {
      visual.price = salePrice(s, p, now, "market", target.rate);
      row2.title += "  ·  " + visual.price + " 金币";
      row2.select = p.id;
      eligibleCount++;
    }
    rows.push(row2);
  }
  const reasons = Object.entries(counts).filter(([, count]) => count).map(([reason, count]) => reason + " " + count + " 只");
  return {
    title: channelNames.market,
    subtitle: [target.condition, ...reasons].join(" · "),
    visual: { eligibleCount, protectedCount: counts.种源保护 },
    empty: "当前筛选下没有动物。",
    rows,
    filters: [
      ["", ...speciesList].map((key) => ({ ...nextPage(
        key ? speciesName(key) : "全部",
        page,
        { channel: "market", ...key && { species: key } }
      ), active: key === (target.species ?? "") })),
      breedOptions.map(([key, label]) => ({ ...nextPage(label, page, { channel: "market", ...target.species && { species: target.species }, ...key && { breed: key } }), active: key === (breed ?? "") }))
    ],
    actions: eligibleCount ? [{ ...nextPage("核对所选报价", "saleQuote", scope), useSelection: true }] : []
  };
}
function orderActions(s, id) {
  const source = s.businessDay.freeUsed < 3 ? "free" : "paid";
  const actions = [nextPage("选择交付动物", "sale", { channel: "order", targetId: id })];
  if (source === "free" || s.cancelCredits > 0) {
    actions.push({
      label: source === "free" ? "使用免费次数取消" : "使用已购次数取消",
      type: "order.cancel",
      args: { id, source },
      confirm: "消耗一次" + (source === "free" ? "免费" : "已购") + "取消次数，本槽 30 分钟后更新。确认取消？",
      go: "orders"
    });
  } else actions.push(nextPage("查看额外取消次数", "credits"));
  return actions;
}
function businessPage(s, page, args, now) {
  if (page === "market" || page === "recycle" || page === "sale") {
    const channel = page === "sale" ? args.channel : page;
    const target = saleTarget(s, { ...args, channel }, now);
    if (channel === "market") return marketRoster(s, page, args, target, now);
    const targetArgs = { channel, ...args.targetId && { targetId: args.targetId }, ...target.species && { species: target.species } };
    const eligible2 = [], omitted = { 种源保护: 0, 繁育中: 0, 已故: 0, 活体: 0, 不符需求: 0 };
    for (const p of s.pets) {
      if (target.species && p.species !== target.species) continue;
      const blocked = !target.eligible(p) ? "不符需求" : saleBlock(s, p, now, channel);
      if (blocked) omitted[blocked]++;
      else eligible2.push(p);
    }
    const reasons = Object.entries(omitted).filter(([, count]) => count).map(([reason, count]) => reason + " " + count + " 只");
    return {
      title: channelNames[channel],
      subtitle: [target.condition, ...reasons].join(" · "),
      visual: { protectedCount: omitted.种源保护 },
      empty: (channel === "recycle" ? "当前没有可回收的已故动物。" : "当前没有符合收购条件的动物。") + (omitted.种源保护 ? "种源不可出售，可在个体档案中取消留种。" : ""),
      rows: eligible2.map((p) => {
        const price = salePrice(s, p, target.quoteAtBirth?.(p) ? p.bornAt : now, channel, target.rate);
        return {
          title: p.name + "  ·  " + price + " 金币",
          visual: { name: p.name, price, summary: petCaption(p, now) },
          text: petCaption(p, now) + " · #" + p.id.slice(0, 6).toUpperCase(),
          art: petArt(p),
          stage: stageOf(p, now),
          select: p.id,
          animal: specimen(s, p, now)
        };
      }),
      actions: eligible2.length ? [{ label: "核对所选报价", page: "saleQuote", args: targetArgs, useSelection: true }] : []
    };
  }
  if (page === "saleQuote") {
    const { target, lines, total, risks, hash: hash2, filter, stage, breed } = quoteSelection(s, args, now);
    const scope = target.species ? { species: target.species } : {};
    const rows = lines.map((line) => ({ title: line.name, text: line.amount + " 金币 · 编号 " + line.id.slice(0, 6).toUpperCase() }));
    if (risks.length) rows.push({ title: "繁育提醒", text: "本批包含" + risks.join("、") + "。" });
    return {
      title: "核对出售",
      subtitle: channelNames[args.channel] + " · " + lines.length + " 只，合计 " + total + " 金币",
      rows,
      actions: [{
        label: "确认交付 · " + total + " 金币",
        type: "sale.commit",
        args: {
          channel: args.channel,
          ...scope,
          ...filter !== "全部" && { filter },
          ...stage !== "全部" && { stage },
          ...breed && { breed },
          ids: args.ids,
          targetId: args.targetId || null,
          amounts: lines.map((line) => line.amount),
          hash: hash2
        }
      }, { label: "修改选择", type: "ui.editSelection" }]
    };
  }
  if (page === "orders") {
    return {
      title: "普通订单",
      subtitle: "普通订单长期有效，交付时核验动物。",
      visual: { remaining: 3 - s.businessDay.freeUsed },
      rows: s.orders.map((slot, i) => {
        if (!slot.order) return { title: "第 " + (i + 1) + " 单 · 等待新客", text: timeLabel(slot.readyAt) + " 更新（北京时间）" };
        const order = slot.order, condition = orderCondition(order), difficulty = ["简单", "普通", "困难"][order.diff];
        const available = canFillOrder(s, order, now);
        const choices = orderActions(s, order.id);
        return {
          ...linkRow("第 " + (i + 1) + " 单 · " + difficulty, condition + " · 基础估值 ×" + order.rate / 100, "orderDesk", { id: order.id }),
          visual: { name: order.breed ? "品种收养委托" : order.tag ? "特征收养委托" : "街坊的委托", condition, difficulty, rate: order.rate / 100, available, choices }
        };
      }),
      actions: [nextPage("额外取消次数", "credits")]
    };
  }
  if (page === "orderDesk") {
    const slot = s.orders.find((item) => item.order?.id === args.id);
    if (!slot) return { title: "委托已结束", rows: [], actions: [nextPage("查看订单夹", "orders")] };
    return { title: "普通委托", subtitle: orderCondition(slot.order), rows: [
      ...orderStockRows(s, slot.order, now),
      { title: "订单倍率", text: "基础估值 ×" + slot.order.rate / 100 + "，荣誉另计。" },
      { title: "可用取消次数", text: "今日免费 " + (3 - s.businessDay.freeUsed) + " 次 · 已购 " + s.cancelCredits + " 次" }
    ], actions: orderActions(s, args.id) };
  }
  if (page === "credits") {
    const price = purchasePrice(s, 300);
    return { title: "额外取消次数", rows: [
      { title: "今日免费剩余", text: 3 - s.businessDay.freeUsed + " / 3 次" },
      { title: "已购余额", text: s.cancelCredits + " / 99 次 · 跨日保留" },
      { title: "今日已购买", text: s.businessDay.bought + " / 3 次" },
      { title: "每次基准 300 金币", text: "实付 " + price + " 金币" }
    ], actions: s.businessDay.bought < 3 && s.cancelCredits < 99 && s.coins >= price ? [{
      label: "购买 1 次",
      type: "order.buyCredit",
      args: { price },
      confirm: "支付 " + price + " 金币，增加 1 次额外取消次数？"
    }] : [] };
  }
  if (page === "guest") {
    const v = s.visitors, g = v.active;
    if (!g) return { title: "特殊来客", art: "shop-modules/guest", rows: [
      { title: "正在候客", text: "符合顾客偏好的动物可吸引特殊来客；在店经营时等候到访。" },
      { title: "今日到店", text: s.businessDay.arrived + " / 6 位" }
    ] };
    const hasMatch = s.pets.some((p) => !saleBlock(s, p, now, "guest") && matchesVisit(p, g.requirement, now));
    return { title: "书店来客", subtitle: visitCondition(g), rows: [
      { title: "来客报价", text: "基础估值 ×2.15，荣誉另计。" },
      { title: "离店时间", text: timeLabel(g.endsAt) + "（北京时间）" },
      ...!hasMatch ? [{ title: "暂时无法交付", text: "店内空闲动物尚未满足这份委托，可在客人离店前再次查看。" }] : []
    ], actions: [
      { ...nextPage("挑选动物", "sale", { channel: "guest", targetId: g.id }), disabled: !hasMatch },
      { label: "婉拒来客", type: "guest.dismiss", args: { id: g.id }, confirm: "婉拒后这位客人将离店。" }
    ] };
  }
  if (page === "research" || page === "researchNode" || page === "researchTable") return researchPage(s, page, args);
  if (page === "decor") return decorPage(s);
  return null;
}
function researchPage(s, page, args) {
  const species = args.species ?? "rabbit";
  requireValue(speciesList.includes(species), "物种不存在。");
  const levels = s.research[species];
  const benefitAt = (branch2, level2) => researchBenefit(branch2, level2, speciesName(species), s.rooms[species]?.mutationEnabled !== false);
  if (page === "research") {
    return {
      title: "研究",
      visual: { levels, open: !!s.rooms[species], handbook: speciesName(species) + "房研究手册" },
      subtitle: s.rooms[species] ? "当前总等级 " + levels.reduce((sum, x) => sum + x, 0) + " / 30" : "开放该物种房间后可以研究。",
      tabs: speciesList.map((key) => ({ ...nextPage(speciesName(key) + "房", "research", { species: key }), active: key === species })),
      rows: levels.map((level2, branch2) => {
        const benefit2 = benefitAt(branch2, level2), status2 = researchState(s, species, branch2);
        return { ...linkRow(
          researchNames[branch2] + " · " + level2 + " 级",
          benefit2.overview + " · " + status2,
          "researchNode",
          { species, branch: branch2 }
        ), visual: { benefit: benefit2, status: status2 } };
      })
    };
  }
  const branch = args.branch, status = researchState(s, species, branch);
  const level = levels[branch], target = level + 1;
  const benefit = benefitAt(branch, level), description = benefit.description;
  if (page === "researchTable") {
    return { title: researchNames[branch], subtitle: description, visual: { benefit, status }, rows: Array.from({ length: 11 }, (_, i) => {
      const entry2 = benefitAt(branch, i);
      return { title: i + " 级" + (level === i ? " · 当前" : ""), text: entry2.currentBonus, visual: { benefit: entry2 } };
    }) };
  }
  const rows = [{ title: "当前 · " + level + " 级", text: benefit.currentBonus }];
  const origin = Number.isInteger(args.originBranch) && args.originBranch >= 0 && args.originBranch < levels.length ? args.originBranch : branch;
  const context = origin === branch ? { species, branch } : { species, branch, originBranch: origin };
  const actions = [nextPage("查看 0–10 级效果", "researchTable", context)];
  if (origin !== branch) actions.push(nextPage("查看原研究", "researchNode", { species, branch: origin }));
  if (level < 10) {
    const price = researchCost(s, species, target);
    rows.push(
      { title: "下级 · " + target + " 级", text: benefit.nextBonus },
      { title: "基准 / 实付", text: researchBases[species] * target * target + " / " + price + " 金币" },
      { title: "本分支前置", text: "需要 " + level + " 级 · 已满足" }
    );
    for (const req of requirements(branch, target)) {
      rows.push(linkRow(researchNames[req.index] + " · 前置", levels[req.index] + " / " + req.needed + " 级 · " + (levels[req.index] >= req.needed ? "已满足" : "未满足"), "researchNode", { species, branch: req.index, originBranch: origin }));
    }
    if (status === "可研究") {
      const subject = [
        "重新抽一个标签时，抽到稀有的机会",
        "例如父母毛发都是 B，幼体毛发升到 A 的机会",
        "例如原本估价 200 金币，繁育后能保留的身价"
      ][branch];
      const confirm = [
        speciesName(species) + "房" + researchNames[branch] + "升至 " + target + " 级",
        "花费 " + price + " 金币",
        subject,
        benefit.currentValue + " → " + benefit.nextValue,
        benefit.switchNote
      ].filter(Boolean).join("\n");
      actions.push({ label: "升级至 " + target + " 级", type: "research.upgrade", args: { species, branch, level, price }, confirm });
    }
  }
  return { title: researchNames[branch], subtitle: description + " " + status, visual: { description, status, benefit }, rows, actions };
}
function decorPage(s) {
  return { title: "店内装饰", subtitle: "购入后可随时在固定位置摆出或收起。", rows: Object.entries(ornaments).map(([key, item]) => {
    const record = s.decor[key], price = purchasePrice(s, item.base), art = "decor/" + key;
    if (!record.owned) return {
      title: item.name,
      art,
      text: "基准 " + item.base + " · 实付 " + price + " 金币",
      action: { type: "decor.buy", args: { key, price }, confirm: "购买" + item.name + "？基准 " + item.base + " 金币，实付 " + price + " 金币。" }
    };
    return {
      title: item.name + (record.placed ? " · 已摆出" : " · 已收起"),
      art,
      text: record.placed ? "点此收起" : "点此摆出",
      action: { type: "decor.place", args: { key, placed: !record.placed } }
    };
  }) };
}
function pay(s, price, agreed) {
  requireValue(agreed === price, "实付价格有变化，请重新确认。");
  requireValue(s.coins >= price, "金币不足。");
  s.coins -= price;
}
function businessAction(s, type, args, now) {
  switch (type) {
    case "sale.commit":
      return saleCommit(s, args, now);
    case "order.buyCredit": {
      requireValue(s.businessDay.bought < 3, "今天已经买过 3 次。");
      requireValue(s.cancelCredits < 99, "已购次数达到 99 次。");
      pay(s, purchasePrice(s, 300), args.price);
      s.cancelCredits++;
      s.businessDay.bought++;
      return "已购入 1 次额外取消次数。";
    }
    case "order.cancel": {
      const slot = s.orders.find((entry2) => entry2.order?.id === args.id);
      requireValue(slot, "委托已结束，请查看当前订单。");
      if (args.source === "free") {
        requireValue(s.businessDay.freeUsed < 3, "今日免费次数已用完，请重新选择。");
        s.businessDay.freeUsed++;
      } else {
        requireValue(
          args.source === "paid" && s.businessDay.freeUsed >= 3 && s.cancelCredits > 0,
          "当前取消额度变化，请重新确认。"
        );
        s.cancelCredits--;
      }
      slot.order = null;
      slot.readyAt = now + 30 * minute;
      return "已取消委托，此槽将在 30 分钟后更新。";
    }
    case "guest.dismiss": {
      requireValue(s.visitors.active && s.visitors.active.id === args.id, "这位来客已经离店。");
      endVisit(s.visitors, now);
      return "已送别来客。";
    }
    case "research.upgrade": {
      const { species, branch, level, price } = args;
      const status = researchState(s, species, branch);
      requireValue(status === "可研究", status);
      requireValue(level === s.research[species][branch], "研究等级已变化，请重新确认。");
      pay(s, researchCost(s, species, level + 1), price);
      s.research[species][branch]++;
      return speciesName(species) + "房" + researchNames[branch] + "已升至 " + (level + 1) + " 级。";
    }
    case "decor.buy": {
      const { key, price } = args;
      requireValue(Object.hasOwn(ornaments, key), "装饰不存在。");
      requireValue(!s.decor[key].owned, "该装饰已购买。");
      pay(s, purchasePrice(s, ornaments[key].base), price);
      s.decor[key].owned = true;
      return "已购买" + ornaments[key].name + "，可点选摆出。";
    }
    case "decor.place": {
      const { key, placed } = args;
      requireValue(Object.hasOwn(ornaments, key) && s.decor[key].owned && typeof placed === "boolean", "请先购买该装饰。");
      s.decor[key].placed = placed;
      return ornaments[key].name + (placed ? "已摆出。" : "已收起。");
    }
    default:
      return void 0;
  }
}

// output/aliyun/source-market-breed-20261121/PetShop/server/pet-names.mjs
var petNames = Object.freeze(`
小朵 糯米 芝麻 点点 松子 桃酥 栗子 杏仁 阿团 花生 奶糖 小满 饼干 米粒 绒球 豆花
汤圆 米糕 麻薯 花卷 糖糕 豆包 芋圆 蛋卷 年糕 烧麦 藕粉 桂糕 雪饼 云吞 馒头 豆沙
麦芽 米酥 糖球 豆皮 玉米 红薯 南瓜 青豆 冬瓜 芋头 莲蓉 糖藕 布丁 果冻 软糖 雪糕
果酱 奶盖 可可 拿铁 奶泡 奶酪 奶黄 抹茶 乌龙 果茶 蜜糖 冰粉 甜筒 酸奶 松饼 蛋挞
小柚 青梅 橘子 橙子 柿子 杨桃 山楂 荔枝 龙眼 莲雾 葡萄 蜜瓜 杏子 李子 樱桃 枇杷
青枣 金桔 桑葚 蓝莓 草莓 白桃 杨梅 苹果 柠檬 甘蔗 无花果 石榴 西柚 椰子 梨儿 桃仁
茉莉 白兰 桂花 海棠 木槿 紫苏 丁香 鸢尾 铃兰 雏菊 月桂 栀子 含笑 迎春 玉兰 芍药
青葵 木棉 白芷 茶花 兰草 秋葵 薄荷 云杉 水杉 榆钱 松果 橡果 柳絮 芦苇 莲子 苜蓿
春芽 夏叶 秋实 冬青 小葱 青笋 毛栗 竹笋 芦花 荷叶 桐花 芽尖 青禾 青竹 艾草 三叶
朝露 晚霞 夕照 星星 云朵 彩虹 月牙 晴天 小雨 雨滴 晨雾 霜花 雪团 露珠 海风 山岚
晨星 弯月 银河 星屑 清晖 朝阳 秋分 夏至 春分 白露 立夏 冬至 芒种 谷雨 雨水 初晴
山雀 海盐 溪石 圆石 沙洲 青川 溪流 小舟 竹筏 贝壳 珍珠 珊瑚 银沙 泉眼 涟漪 潮汐
风铃 纸鸢 铃铛 铜铃 纽扣 毛线 绒帽 丝带 风筝 纸船 风车 绣球 花灯 小鼓 团扇 阿绵
木木 阿柴 甜勺 果果 小篓 棠棠 纸鹤 书书 墨滴 竹笛 琴儿 皮皮 桃仔 棉仔 彩彩 铃鼓
团团 圆圆 蓬蓬 暖暖 悠悠 朵朵 萌萌 跳跳 笑笑 呼呼 啾啾 嘟嘟 咕咕 扑扑 弯弯 蹦蹦
绵绵 甜甜 酥酥 噗噗 轻轻 转转 滚滚 绒绒 眯眯 囡囡 闪闪 泡泡 斑斑 星仔 芝仔 果仔
乌梅 阿栗 阿禾 阿梨 阿竹 阿诺 阿布 阿桃 阿杏 阿圆 阿橘 阿蓉 阿巧 阿福 阿乐 阿夏
小溪 小岛 小丘 小径 小桥 小苗 小枝 小瓣 小蕊 小穗 小藤 小葵 小榛 小枫 小栎 小蕨
梨窝 酒窝 眉豆 雪顶 乌豆 金豆 米白 桂圆 青团 麦香 灯芯 琥珀 云母 青瓷 墨玉 青苔 余晖
圆耳 歪耳 短尾 花尾 绒爪 雪爪 棉絮 棉桃 灰团 黑豆 白袜 花袖 半糖 满月 轻舟 飞絮
`.trim().split(/\s+/));
function occupiedPetNames(s, excludedOffers = []) {
  const used = new Set(s.pets.map((p) => p.name));
  for (const room of Object.values(s.rooms)) {
    for (const p of room.shelf?.offers ?? []) {
      if (p && !excludedOffers.includes(p)) used.add(p.name);
    }
    const reserved = room.reservedSeed?.offer;
    if (reserved && !excludedOffers.includes(reserved)) used.add(reserved.name);
    for (const p of room.job?.offspring ?? []) used.add(p.name);
  }
  return used;
}
function takePetName(used, roll, preferred) {
  let name = preferred;
  if (!name || used.has(name)) {
    const start = Math.floor(roll * petNames.length);
    for (let offset2 = 0; offset2 < petNames.length; offset2++) {
      name = petNames[(start + offset2) % petNames.length];
      if (!used.has(name)) break;
    }
    if (used.has(name)) {
      const base = petNames[start];
      let number2 = 2;
      do {
        name = base + "·" + number2++;
      } while (used.has(name));
    }
  }
  used.add(name);
  return name;
}

// output/aliyun/source-market-breed-20261121/PetShop/server/room-nutrition.mjs
var meals = [
  { key: "quality", label: "优质", rate: 1.5, priceRatio: 0.8 },
  { key: "select", label: "精选", rate: 1.8, priceRatio: 0.9 },
  { key: "premium", label: "臻选", rate: 2, priceRatio: 1 }
];
var minutes = 30;
var nutritionDuration = minutes * 6e4;
var animalNames = { rabbit: "兔", cat: "猫", dog: "狗" };
var premiumPrice = { rabbit: 100, cat: 400, dog: 1e3 };
var go = (label, page, args) => ({ label, page, args });
var nutritionTier = (key) => meals.find((meal) => meal.key === key);
var nutritionPrice = (species, meal) => Math.round(premiumPrice[species] * meal.priceRatio);
function nutritionWindow(room) {
  const effect = room?.nutrition;
  const meal = nutritionTier(effect?.tier);
  if (!meal || !Number.isFinite(effect.startsAt) || !Number.isFinite(effect.endsAt) || effect.startsAt >= effect.endsAt) return void 0;
  return { rate: meal.rate, startsAt: effect.startsAt, endsAt: effect.endsAt };
}
function activeNutrition(room, now) {
  const effect = nutritionWindow(room);
  return effect && effect.startsAt <= now && now < effect.endsAt ? effect : void 0;
}
function nutritionStock(room, tier) {
  const count = room?.nutritionStock?.[tier];
  return Number.isSafeInteger(count) && count > 0 ? count : 0;
}
function nutritionPage(s, page, species, tier, now) {
  const animal = animalNames[species], room = animal + "房", name = animal.repeat(2) + "营养餐";
  const roomState = s.rooms[species], current2 = activeNutrition(roomState, now);
  const available = meals.find((m) => nutritionStock(roomState, m.key) > 0);
  const meal = nutritionTier(tier) ?? (page === "roomNutrition" ? available : void 0) ?? meals[0];
  const args = { species, tier: meal.key };
  const icon = (m) => "rooms/" + species + "-nutrition-" + m.key;
  const art = icon(meal);
  const buy = go("去购买", "nutritionShop", args);
  const count = nutritionStock(roomState, meal.key);
  const row2 = (m) => ({
    title: m.label + name,
    art: icon(m),
    visual: {
      rate: m.rate,
      stock: nutritionStock(roomState, m.key),
      selected: m.key === meal.key,
      pick: go("选择", "roomNutrition", { species, tier: m.key }),
      detail: go("查看详情", "nutritionDetail", { species, tier: m.key })
    }
  });
  if (page === "nutritionShop") return {
    title: "培育中心",
    subtitle: "营养餐",
    tabs: Object.entries(animalNames).map(([key, label]) => ({
      ...go(label + "房", "nutritionShop", { species: key }),
      active: key === species
    })),
    rows: meals.map((m) => {
      const price = nutritionPrice(species, m);
      const stock = nutritionStock(roomState, m.key);
      const title = m.label + name;
      const label = !roomState ? "房间未开放" : s.coins < price ? "金币不足" : "购买 1 份";
      return {
        title,
        art: icon(m),
        current: m.key === tier,
        visual: { rate: m.rate, price, stock },
        action: {
          label,
          type: "care.buyNutrition",
          args: { species, tier: m.key, price },
          disabled: !roomState || s.coins < price,
          confirm: "花费 " + price + " 金币购买 1 份" + title + "？"
        }
      };
    })
  };
  if (!s.rooms[species]) return { title: "营养餐", rows: [{ title: "请先开放" + room + "。" }] };
  if (page === "nutritionDetail") return {
    title: "道具详情",
    art,
    rows: [
      row2(meal),
      { title: "作用范围", text: "整间" + room },
      { title: "持续时间", text: minutes + " 分钟" },
      { title: "价格", text: nutritionPrice(species, meal) + " 金币" },
      { title: "库存", text: count + " 份" }
    ],
    visual: { rules: "只加速成年前成长，不影响繁育等待、衰老或死亡。\n离线继续计时，期间出生的幼体共享本房剩余时间。\n效果不叠加，到期后可再次投喂。" },
    actions: [{ label: "返回选择", type: "ui.back" }, buy]
  };
  const hint = current2 ? "本房效果尚未结束，可查看详情。" : !available ? "暂无营养餐，可前往培育中心购买。" : !count ? "所选营养餐库存不足，请选择有库存的营养餐。" : void 0;
  return {
    title: "选择" + name,
    art,
    rows: meals.map(row2),
    visual: { hint },
    actions: [{ label: current2 ? "效果生效中，暂不可使用" : "投喂", type: "care.feed", args, disabled: !!current2 || !count }]
  };
}

// output/aliyun/source-market-breed-20261121/PetShop/server/onboarding.mjs
import { randomUUID as randomUUID2 } from "node:crypto";

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-tasks.mjs
var rabbitPairTask = "rabbit-pair";
var reward = { coins: 40, tier: "premium", quantity: 2 };
var openingReward = [
  { name: "金币", quantity: reward.coins },
  { name: "臻选兔兔营养餐", quantity: reward.quantity, art: "rooms/rabbit-nutrition-premium" }
];
var isPurchasedRabbit = (p) => p?.species === "rabbit" && p.source === "研究所采购";
var rabbit = { species: "rabbit" };
var entry = (title, text, done, page, args = {}) => ({ title, text, done, link: { page, args } });
var groupGoal = (p, total, prior) => p.legacy ? total : total - prior;
var breedTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("安排 " + count + " 窝兔子", "在兔房开始繁育。", p.breeds >= count, "breed", rabbit);
};
var litterTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("查看 " + count + " 窝出生记录", "每一窝出生后打开一次「最近出生的一窝」。", p.litters >= count, "litter", rabbit);
};
var keepTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("给 " + count + " 只兔子留种", "在兔房查看档案并标记种源。同一只只计一次。", p.retained >= count, "rooms", rabbit);
};
var buyTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("购入 " + count + " 只兔子", "在培育中心种源货架选购。", p.bought >= count, "lab", { tab: "seed", fromTasks: true });
};
var marketTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("在市场完成 " + count + " 笔出售", "在自由市场确认出售动物。", p.marketSales >= count, "market");
};
var saleTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("累计售出 " + count + " 只动物", "市场或普通订单都可。批量出售按只数累计。", p.sold >= count, "market");
};
var incomeTask = (p, total, prior = 0) => {
  const amount = groupGoal(p, total, prior);
  return entry("累计交易收入 " + amount + " 金币", "统计自由市场和普通订单的成交金额。", p.income >= amount, "market");
};
var researchTask = (s, p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return !p.legacy && (p.research ?? 0) < count && s.research.rabbit.every((level) => level >= 10) ? entry("查看已满级的兔房研究", "兔房研究已满级，打开手册查看已解锁的效果。", !!p.researchRead, "research", rabbit) : entry("提升兔房研究 " + count + " 级", "在培育中心选择任意兔房研究分支升级。", p.research >= count, "research", rabbit);
};
var orderTask = (p, total, prior = 0) => {
  const count = groupGoal(p, total, prior);
  return entry("处理 " + count + " 份普通委托", "完成交付或取消不适合的委托，等待该槽补单。", p.orders >= count, "orders", { fromTasks: true });
};
var feedTask = (p) => entry("给兔房喂一份营养餐", "在兔房使用一份营养餐。", p.feeds >= 1, "roomNutrition", rabbit);
var earlyGroups = [
  { id: "settle-rabbits", title: "安置兔房", coins: 40, item: "quality", rows: (s, p) => p.legacy ? [
    entry("签到领养幼兔", "点击门口礼盒，领取今日的两只幼兔。", s.care.signedDay != null, "profile"),
    feedTask(p),
    entry(
      "给一只兔子留种",
      "在兔房选一只兔子，打开档案并标记为种源。",
      p.retained >= 1,
      "rooms",
      rabbit
    ),
    entry("查看下一窝幼兔", "新种源的繁育按正常时间进行。出生后查看名册。", p.litters >= 1, "litter", rabbit)
  ] : [
    entry("看看一只种源", "在兔房打开一只已留种兔子的档案。", !!p.seedArchive, "rooms", rabbit),
    feedTask(p),
    entry("逛逛店里能买的种兔", "打开培育中心的种源货架。", !!p.shelf, "lab", { tab: "seed", fromTasks: true })
  ] },
  { id: "manage-first-litters", title: "经营第一批兔子", coins: 40, item: "guide", rows: (_s, p) => [
    entry("在自由市场售出动物", "选一只不打算留种的动物，完成出售。", p.marketSales > 0, "market"),
    entry("查看培育中心种源", "看看当前可买的种源，记录下一次补种的选择。", !!p.shelf, "lab", { tab: "seed", fromTasks: true }),
    entry("安排下一窝兔子", "从已有的成年兔里挑选母本和父本，再开始一窝。", p.breeds >= 1, "breed", rabbit)
  ] },
  { id: "continue-shop", title: "接续店铺经营", coins: 60, rows: (_s, p) => [
    entry("完成下一次交易", "交付普通订单，或再去自由市场完成一笔交易。", p.sales >= groupGoal(p, 2, 1), "orders", { fromTasks: true }),
    entry("查看普通订单", "对照当前委托和兔房名册，挑选要交付的动物。", !!p.orderRead, "orders", { fromTasks: true })
  ] },
  { id: "learn-services", title: "认识培育服务", coins: 60, item: "review", rows: (_s, p) => [
    entry("查看一只兔子的档案", "从兔房挑一只兔子，查看成长时间和属性。", !!p.archive, "rooms", rabbit),
    entry("查看物品", "了解复评单、选育单和药剂的用途。", !!p.services, "lab", { tab: "services", fromTasks: true }),
    keepTask(p, 2)
  ] },
  { id: "add-seeds", title: "添补新种源", coins: 80, item: "select", rows: (_s, p) => [buyTask(p, 2), breedTask(p, 2, 1), litterTask(p, 2, 1)] },
  { id: "rabbit-research", title: "开始兔房研究", coins: 80, rows: (s, p) => [
    entry("打开兔房研究手册", "查看三条研究分支的成长方向。", !!p.researchRead, "research", rabbit),
    researchTask(s, p, 1),
    marketTask(p, 3, 1)
  ] },
  { id: "follow-growth", title: "照看新生幼兔", coins: 80, item: "quality", rows: (_s, p) => [
    entry("查看兔房营养餐状态", "投喂过营养餐后，再打开列表核对剩余库存。", !!p.mealRead, "roomNutrition", rabbit),
    breedTask(p, 3, 2),
    litterTask(p, 3, 2)
  ] },
  { id: "work-orders", title: "处理普通委托", coins: 80, item: "guide", rows: (_s, p) => [orderTask(p, 1), saleTask(p, 6)] },
  { id: "select-breeders", title: "建立后备种群", coins: 100, item: "select", rows: (_s, p) => [keepTask(p, 4, 2), litterTask(p, 4, 3)] },
  { id: "regular-sales", title: "稳定市场出货", coins: 100, rows: (_s, p) => [marketTask(p, 5, 3), incomeTask(p, 1e3)] },
  { id: "improve-research", title: "提高兔房培育水平", coins: 120, item: "review", rows: (s, p) => [researchTask(s, p, 2, 1), buyTask(p, 3, 2), breedTask(p, 5, 3)] },
  { id: "grow-output", title: "扩大兔房供给", coins: 120, item: "premium", rows: (_s, p) => [
    litterTask(p, 5, 4),
    saleTask(p, 12, 6),
    breedTask(p, 6, 5),
    entry("两次投喂兔房", "首份普通营养餐到期后，可以再使用一份。", p.feeds >= 2, "roomNutrition", rabbit)
  ] },
  { id: "upgrade-stock", title: "周转种源和订单", coins: 140, item: "guide", rows: (_s, p) => [
    orderTask(p, 2, 1),
    buyTask(p, 4, 3),
    keepTask(p, 5, 4),
    entry("查看补位订单", "委托处理后约 30 分钟补位。打开普通订单查看新委托。", !!p.refill, "orders", { fromTasks: true })
  ] },
  { id: "prepare-cat-room", title: "筹备猫房经费", coins: 160, item: "select", rows: (s, p) => [incomeTask(p, 2500, 1e3), researchTask(s, p, 3, 2), marketTask(p, 7, 5)] },
  { id: "rabbit-shop-ready", title: "兔房独立经营", coins: 200, item: "premium", rows: (_s, p) => [breedTask(p, 8, 6), litterTask(p, 8, 5), saleTask(p, 20, 12)] }
];
var taskItems = {
  guide: { name: "兔用选育指导单", art: "shop-modules/breeding-guide" },
  review: { name: "兔用复评单", art: "shop-modules/research-review" }
};
function taskItem(key) {
  if (!key) return;
  if (taskItems[key]) return taskItems[key];
  return { name: nutritionTier(key).label + "兔兔营养餐", art: "rooms/rabbit-nutrition-" + key };
}
function groupRewards(group) {
  const entries = [{ name: "金币", quantity: group.coins }];
  const item = taskItem(group.item);
  if (item) entries.push({ ...item, quantity: 1 });
  return entries;
}
function grantGroupRewards(s, group) {
  s.coins += group.coins;
  if (!group.item) return group.coins + " 金币";
  const room = s.rooms.rabbit, key = group.item;
  const stock = taskItems[key] ? room.items : room.nutritionStock ??= {};
  const count = stock[key] ?? 0;
  if (!Number.isSafeInteger(count + 1)) throw new Error("对应道具库存已满。");
  stock[key] = count + 1;
  return group.coins + " 金币和 1 " + (taskItems[key] ? "张" : "份") + taskItem(key).name;
}
var earlyStart = (s) => s.onboarding ? s.onboarding.finishedAt : s.tasks[rabbitPairTask]?.claimedAt;
var earlyDone = (s) => s.tasks.early?.claimed?.[earlyGroups.at(-1).id] !== void 0;
var currentEarlyGroup = (s) => earlyGroups.find((group) => s.tasks.early?.claimed?.[group.id] === void 0);
function earlyTaskGroup(s) {
  const early = s.tasks.early;
  const group = currentEarlyGroup(s) ?? earlyGroups.at(-1);
  const progress = early?.progress ?? {};
  const rows = group.rows(s, { ...progress, legacy: early?.legacy, retained: progress.retainedIds?.length ?? 0 });
  const claimed = early?.claimed?.[group.id] !== void 0;
  return { group, rows: claimed ? rows.map((row2) => ({ ...row2, done: true })) : rows, claimed };
}
function openEarlyGroup(s, now) {
  s.tasks.early = { startedAt: now, claimed: s.tasks.early?.claimed ?? {}, progress: {} };
}
function recordEarlySale(p, sale) {
  if (sale.channel !== "market" && sale.channel !== "order") return;
  p.sales = (p.sales ?? 0) + 1;
  p.sold = (p.sold ?? 0) + sale.lines.length;
  p.income = (p.income ?? 0) + sale.total;
  const metric = sale.channel === "market" ? "marketSales" : "orders";
  p[metric] = (p[metric] ?? 0) + 1;
}
function migrateEarlyGroup(s, now) {
  const started = earlyStart(s);
  if (started === void 0 || earlyDone(s) || s.tasks.early?.startedAt !== void 0) return false;
  const old = s.tasks.early?.progress ?? {};
  const p = {
    ...old,
    feeds: Math.max(old.feeds ?? 0, Number(s.rooms.rabbit.nutrition?.startsAt >= started)),
    retainedIds: [.../* @__PURE__ */ new Set([...old.retainedIds ?? [], ...s.pets.filter((animal) => animal.species === "rabbit" && animal.retained).map((pet) => pet.id)])].slice(0, 5),
    research: s.research.rabbit.reduce((sum, level) => sum + level, 0),
    orders: old.cancelled ?? 0
  };
  const guide = s.onboarding;
  for (const sale of s.sales) {
    if (sale.at < started || sale.channel === "order" && sale.targetId === guide?.orderId || sale.channel === "market" && sale.lines.some((line) => guide?.starters?.includes(line.id))) continue;
    recordEarlySale(p, sale);
  }
  openEarlyGroup(s, now);
  s.tasks.early.legacy = true;
  s.tasks.early.progress = p;
  return true;
}
function visitEarly(s, page, args, now) {
  const early = s.tasks.early;
  if (!early) return s;
  const p = early.progress, updates = {};
  const litter2 = s.rooms.rabbit.lastLitter;
  if (page === "litter" && (args.species ?? "rabbit") === "rabbit" && litter2 && (args.bornAt === void 0 || args.bornAt === litter2.bornAt) && litter2.bornAt > (early.legacy ? s.onboarding?.firstLitterAt ?? 0 : early.startedAt) && litter2.ids[0] !== p.lastLitterId) {
    updates.lastLitterId = litter2.ids[0];
    updates.litters = (p.litters ?? 0) + 1;
  }
  if (page === "lab" && (!args.tab || args.tab === "seed") && !p.shelf) updates.shelf = true;
  if ((page === "lab" && args.tab === "services" || page === "services") && !p.services) updates.services = true;
  if (page === "pet" && (!p.archive || !p.seedArchive)) {
    const pet = s.pets.find((animal) => animal.id === args.id && animal.species === "rabbit");
    if (pet && !p.archive) updates.archive = true;
    if (pet?.retained && !p.seedArchive) updates.seedArchive = true;
  }
  if (page === "research" && (args.species ?? "rabbit") === "rabbit" && !p.researchRead) updates.researchRead = true;
  if (page === "roomNutrition" && (args.species ?? "rabbit") === "rabbit" && !p.mealRead && (p.feeds || activeNutrition(s.rooms.rabbit, now))) updates.mealRead = true;
  if (page === "orders") {
    if (!p.orderRead) updates.orderRead = true;
    if (!p.refill) {
      const firstOrder2 = early.legacy && s.sales.find((sale) => sale.targetId === s.onboarding?.orderId && sale.channel === "order");
      if (s.orders.some((slot) => early.legacy ? slot.order?.refilledAt >= (firstOrder2?.at ?? earlyStart(s)) : slot.order?.refilledAt > early.startedAt)) updates.refill = true;
    }
  }
  if (!Object.keys(updates).length) return s;
  const updated = { ...s, tasks: { ...s.tasks, early: { ...s.tasks.early, progress: { ...p, ...updates } } } };
  return updated;
}
function recordEarlyAction(s, type, args) {
  const p = s.tasks.early.progress;
  const counters = { "care.breed": "breeds", "care.feed": "feeds", "care.buyPet": "bought", "order.cancel": "orders", "research.upgrade": "research" };
  const counter = Object.hasOwn(counters, type) ? counters[type] : null;
  if (counter && (args.species ?? "rabbit") === "rabbit") {
    p[counter] = (p[counter] ?? 0) + 1;
  }
  if (type === "sale.commit") recordEarlySale(p, s.sales.at(-1));
  const kept = type === "care.retain" && args.retained ? [args.id] : type === "care.keepLitter" ? args.ids ?? args.keepIds : type === "sale.commit" ? args.litterRetention?.keepIds : void 0;
  const rabbits = kept?.filter((id) => s.pets.some((p2) => p2.id === id && p2.species === "rabbit"));
  if (!rabbits?.length) return;
  p.retainedIds = [.../* @__PURE__ */ new Set([...p.retainedIds ?? [], ...rabbits])].slice(0, 5);
}
function initTasks(s, now) {
  if (s.tasks?.opening) return migrateEarlyGroup(s, now);
  s.tasks ??= {};
  const { job, lastLitter } = s.rooms.rabbit;
  const old = s.visitBook.tutorial;
  const progress = s.tasks.opening = {
    breed: !!(old?.bred || job || lastLitter),
    buy: !!old?.bought,
    checkin: !!(old?.claimed || s.care.signedDay != null),
    orders: !!old?.ordersViewed,
    market: !!old?.marketViewed
  };
  delete s.visitBook.tutorial;
  const knownParents = job ? [...s.pets, job.mother, job.father] : s.pets;
  const purchasedIds = new Set(knownParents.filter(isPurchasedRabbit).map((p) => p.id));
  if (purchasedIds.size) progress.buy = true;
  let firstRabbitPair = Infinity, qualifyingPair;
  for (const receipt of Object.values(s.receipts)) {
    const version = receipt?.result?.version;
    if (!Number.isSafeInteger(version) || typeof receipt.key !== "string" || !/^\["care\.(breed|buyPet)",/.test(receipt.key)) continue;
    let type, args;
    try {
      [type, args] = JSON.parse(receipt.key);
    } catch {
      continue;
    }
    if (!args || (args.species ?? "rabbit") !== "rabbit") continue;
    if (type === "care.buyPet") {
      progress.buy = true;
      continue;
    }
    progress.breed = true;
    firstRabbitPair = Math.min(firstRabbitPair, version);
    if (purchasedIds.has(args.mother) && purchasedIds.has(args.father) && version > (qualifyingPair?.version ?? 0)) {
      qualifyingPair = { motherId: args.mother, fatherId: args.father, version };
    }
  }
  if (!s.tasks[rabbitPairTask] && qualifyingPair && qualifyingPair.version > firstRabbitPair) s.tasks[rabbitPairTask] = qualifyingPair;
  migrateEarlyGroup(s, now);
  return true;
}
function recordTaskAction(s, type, args, now) {
  if (earlyStart(s) !== void 0) {
    if (earlyDone(s)) return;
    if (s.tasks.early?.startedAt === void 0) openEarlyGroup(s, now);
    recordEarlyAction(s, type, args);
    return;
  }
  if (s.onboarding) return;
  const progress = s.tasks.opening;
  if (type === "care.checkin") progress.checkin = true;
  if ((args.species ?? "rabbit") !== "rabbit") return;
  if (type === "care.buyPet") progress.buy = true;
  if (type !== "care.breed") return;
  progress.breed = true;
  if (s.tasks[rabbitPairTask]) return;
  const { job, lastLitter } = s.rooms.rabbit;
  if (lastLitter && isPurchasedRabbit(job?.mother) && isPurchasedRabbit(job?.father)) {
    s.tasks[rabbitPairTask] = { motherId: job.motherId, fatherId: job.fatherId, version: s.version + 1 };
  }
}
function recordTaskVisit(s, page, args, now) {
  if (earlyStart(s) !== void 0) return earlyDone(s) ? s : visitEarly(s, page, args, now);
  if (s.onboarding) return s;
  if (!["orders", "market"].includes(page) || s.tasks.opening[page]) return s;
  return { ...s, tasks: { ...s.tasks, opening: { ...s.tasks.opening, [page]: true } } };
}
var complete = (s) => !!s.tasks[rabbitPairTask] && Object.values(s.tasks.opening).every(Boolean);
function taskRows(s, access) {
  const task = s.tasks[rabbitPairTask], p = s.tasks.opening;
  const requirement = (key) => access[key].unlocked ? "" : " · " + access[key].requiredLevel + " 级开放";
  return [
    entry("开始兔子繁育", "确认一公一母的配对。", p.breed, "breed", { species: "rabbit" }),
    entry("购入一只种兔", "培育中心 · 种源" + requirement("lab"), p.buy, "lab", { fromTasks: true }),
    entry("签到领养幼兔", "领取今日的两只幼兔。", p.checkin, "profile"),
    entry("查看普通订单", "订单" + requirement("orders"), p.orders, "orders", { fromTasks: true }),
    entry("查看自由市场", "查看当前的动物报价。", p.market, "market"),
    entry("用购入的种兔继续繁育", "首窝出生后，用购入的一公一母开始配对。", !!task, "breed", { species: "rabbit" })
  ];
}
function taskShortcut(s, access) {
  if (earlyStart(s) !== void 0) {
    const { rows: rows2, claimed: claimed2 } = earlyTaskGroup(s);
    const next2 = rows2.find((row2) => !row2.done);
    return {
      completed: rows2.filter((row2) => row2.done).length,
      total: rows2.length,
      choice: next2 ? { ...next2.link, label: next2.title } : { page: "tasks", label: claimed2 ? "首轮经营任务已完成" : "领取任务奖励" }
    };
  }
  if (s.onboarding) return { completed: 4, total: 4, choice: { page: "tasks", label: "查看开店任务" } };
  const rows = taskRows(s, access), pending = rows.filter((r) => !r.done);
  const next = pending[0];
  const claimed = s.tasks[rabbitPairTask]?.claimedAt !== void 0;
  return {
    completed: rows.length - pending.length,
    total: rows.length,
    choice: next ? { ...next.link, label: next.title } : { page: "tasks", label: claimed ? "任务已全部完成" : "领取任务奖励" }
  };
}
function tasksPage(s, access) {
  if (earlyStart(s) !== void 0) {
    const { group, rows: rows2, claimed: claimed2 } = earlyTaskGroup(s);
    return {
      title: "任务",
      subtitle: group.title + " · " + rows2.filter((r) => r.done).length + " / " + rows2.length + " 已完成",
      rows: rows2,
      visual: { rewards: groupRewards(group) },
      actions: [{ label: claimed2 ? "已领取" : "领取", type: "task.claim", args: { id: group.id }, disabled: claimed2 || rows2.some((row2) => !row2.done) }]
    };
  }
  const rows = taskRows(s, access);
  const claimed = s.tasks[rabbitPairTask]?.claimedAt !== void 0;
  return {
    title: "任务",
    subtitle: rows.filter((r) => r.done).length + " / " + rows.length + " 已完成",
    rows,
    visual: { rewards: openingReward },
    actions: [{ label: claimed ? "已领取" : "领取", type: "task.claim", args: { id: rabbitPairTask }, disabled: claimed || !complete(s) }]
  };
}
function taskAction(s, type, args, now) {
  if (type !== "task.claim") return void 0;
  if (earlyStart(s) !== void 0) {
    const early = s.tasks.early;
    if (args.id === rabbitPairTask && s.tasks[rabbitPairTask]?.claimedAt !== void 0) throw new Error("这项任务的奖励已领取。");
    if (early?.claimed?.[args.id] !== void 0) throw new Error("这组任务的奖励已领取。");
    const { group, rows } = earlyTaskGroup(s);
    if (args.id !== group.id) throw new Error("请先完成当前一组任务。");
    if (rows.some((row2) => !row2.done)) throw new Error("请先完成这组里的全部任务。");
    const earlyState = s.tasks.early ??= {};
    (earlyState.claimed ??= {})[group.id] = now;
    const reward2 = grantGroupRewards(s, group);
    openEarlyGroup(s, now);
    const next = currentEarlyGroup(s);
    return "已领取「" + group.title + "」奖励 " + reward2 + "。" + (next ? "已开启「" + next.title + "」。" : "首轮经营任务已完成。");
  }
  if (args.id !== rabbitPairTask) throw new Error("没有这项任务。");
  const task = s.tasks[rabbitPairTask];
  if (task?.claimedAt !== void 0) throw new Error("这项任务的奖励已领取。");
  if (!complete(s)) throw new Error("请先完成全部任务。");
  const message = grantOpeningReward(s);
  task.claimedAt = now;
  return message;
}
function grantOpeningReward(s) {
  const room = s.rooms.rabbit;
  const stock = nutritionStock(room, reward.tier) + reward.quantity;
  if (!Number.isSafeInteger(stock)) throw new Error("兔房对应营养餐库存已满。");
  s.coins += reward.coins;
  room.nutritionStock ??= {};
  room.nutritionStock[reward.tier] = stock;
  return "已领取 " + reward.coins + " 金币和 " + reward.quantity + " 份臻选兔兔营养餐。";
}

// output/aliyun/source-market-breed-20261121/PetShop/server/onboarding.mjs
var rabbit2 = { species: "rabbit" };
var seedPrice = 200;
var firstLitterWait = 5e3;
var mealTier = "premium";
var mealName = "臻选兔兔营养餐";
var firstLitterSexes = ["母", "公", "母", "公"];
var parentSexes = ["母", "公"];
var recoverySource = "引导续接";
var adultOffer = (offer, now) => ({ ...offer, bornAt: now - (lifeDates(offer).adultAt - offer.bornAt) });
var pair = (s, breed, now, source) => {
  const names = occupiedPetNames(s);
  return parentSexes.map((sex) => makePet(names, "rabbit", breed, sex, now, source));
};
var idsOf = (animals2) => animals2.map((p) => p.id);
var findPet = (s, id) => s.pets.find((p) => p.id === id);
var choice = (label, page, args = {}) => ({ label, page, args });
var action = (label, type, args = {}, go4, goArgs) => ({ label, type, args, go: go4, goArgs });
function expect(condition, message) {
  if (!condition) throw Object.assign(new Error(message), { status: 409 });
}
var saleFor = (s, channel, id) => id && s.sales.findLast((record) => record.channel === channel && record.lines.some((line) => line.id === id));
var saleForOrder = (s, id) => id && s.sales.findLast((record) => record.channel === "order" && record.targetId === id);
var firstOrder = (id) => ({ id, species: "rabbit", breed: "domestic", diff: 0, rate: 135 });
var guidePrice = (s) => Math.max(0, Math.min(seedPrice, s.coins));
function initOnboarding(s) {
  const first = s.orders[0].order;
  s.onboarding = { booklet: true, orderId: first.id };
  Object.assign(first, firstOrder(first.id));
}
var rabbitWaitingForOpening = (s) => !!s.onboarding && !s.onboarding.starters && !s.onboarding.finishedAt;
var openingPair = (s, args) => !!s.onboarding?.starters && !s.onboarding.firstLitterAt && (args.species ?? "rabbit") === "rabbit" && args.mother === s.onboarding.starters[0] && args.father === s.onboarding.starters[1];
var guideAccess = (s, key) => {
  const g = s.onboarding;
  return key === "lab" && !!g?.remainingId || key === "orders" && g?.step >= 16;
};
function settleOnboarding(s, now) {
  const g = s.onboarding;
  if (!g) return;
  const room = s.rooms.rabbit, litter2 = room.lastLitter;
  if (!g.booklet) {
    if (!g.finishedAt) {
      if (g.step === 5 && !room.job && litter2?.bornAt !== g.firstLitterAt) g.step = 4;
      repairGuideTargets(s, g, now);
      if (g.step >= 15) g.legacyRewardReady = true;
      if (g.claimedAt !== void 0) g.finishedAt = g.claimedAt;
      if (!g.finishedAt) s.visitBook.opening = true;
    }
    g.booklet = true;
  }
  if (litter2 && litter2.bornAt === g.firstLitterAt) {
    g.litterIds ??= [...litter2.ids];
    g.firstLitter ??= structuredClone(litter2);
  }
  if (g.starters && !g.teachingMealGranted) grantTeachingMeal(room, g);
  protectOpeningAnimals(s, g.finishedAt ? void 0 : g, now);
}
function grantTeachingMeal(room, g) {
  if (g.teachingMealGranted) return;
  (room.nutritionStock ??= {})[mealTier] = nutritionStock(room, mealTier) + 1;
  g.teachingMealGranted = true;
}
var teachingPair = (s, now) => {
  const g = s.onboarding;
  if (!g?.starters || g.teachingMealUsed || g.firstLitterAt || !nutritionStock(s.rooms.rabbit, mealTier)) return;
  const pets = g.starters.map((id) => findPet(s, id));
  if (pets.every((p) => p && stageOf(p, now) !== "已故") && pets.some((p) => lifeDates(p).adultAt > now)) return pets;
};
function recoveredRabbit(s, g, now, role, missingId, { sex = "母", breed = "domestic", bornAt = now, ...data } = {}) {
  const pet = makePet(occupiedPetNames(s), "rabbit", breed, sex, bornAt, recoverySource, data);
  s.pets.push(pet);
  (g.recoveredTargets ??= []).push({ step: g.step, at: now, role, missingId: missingId ?? null, id: pet.id });
  return pet;
}
function repairGuideTargets(s, g, now) {
  if ([8, 9].includes(g.step)) {
    const sold = g.starters?.find((id) => saleFor(s, "market", id));
    if (sold) {
      g.remainingId = g.starters.find((id) => id !== sold);
      g.step = 10;
    }
  }
  if ([3, 4, 8, 9].includes(g.step)) {
    const previous = g.starters ?? [], bred = g.step >= 8;
    g.starters = parentSexes.map((sex, index) => {
      const id = previous[index], pet = findPet(s, id);
      if (pet && pet.sex === sex && pet.species === "rabbit" && pet.breedKey === "domestic" && pet.bred === bred && pet.tutorialDeathAt === void 0 && (g.step < 8 || !pet.retained) && !isBusy(s, pet)) return id;
      const substitute = recoveredRabbit(s, g, now, "starter", id, { sex, bred });
      if (g.step !== 3) substitute.maturation = { growthAt: now, adultAt: now };
      return substitute.id;
    });
  }
  if (g.step >= 10 && g.step <= 12) {
    const soldId = g.starters?.find((id) => saleFor(s, "market", id));
    if (soldId) g.remainingId ??= g.starters.find((id) => id !== soldId);
    if (saleFor(s, "recycle", g.remainingId)) {
      openGuideOffers(s, g, now);
    } else {
      const remaining = findPet(s, g.remainingId);
      if (!remaining?.bred || remaining.retained || remaining.species !== "rabbit" || isBusy(s, remaining)) {
        const index = g.starters?.indexOf(g.remainingId);
        const deathAt = saleFor(s, "market", soldId)?.at ?? now;
        const bornAt = deathAt - (SPECIES.rabbit.young + SPECIES.rabbit.growth) * 6e4;
        g.remainingId = recoveredRabbit(
          s,
          g,
          now,
          "recycle",
          g.remainingId,
          { sex: parentSexes[index] ?? "母", bornAt, bred: true, tutorialDeathAt: deathAt }
        ).id;
      } else settleUnsoldParent(s, g, now);
    }
  }
  if (g.step === 13 || g.step === 14) repairPurchasedSeeds(s, g, now);
  if (g.step === 16 && saleForOrder(s, g.orderId)) {
    g.step = 17;
    return;
  }
  if ([6, 7, 16].includes(g.step)) {
    const litter2 = s.rooms.rabbit.lastLitter;
    if (!g.litterIds?.length && litter2 && litter2.bornAt === g.firstLitterAt) g.litterIds = [...litter2.ids];
    if (!guideLitterPet(s, g)) {
      const pet = recoveredRabbit(s, g, now, "litter", g.litterIds?.[0]);
      (g.litterIds ??= []).push(pet.id);
    }
  }
  if (g.step === 16 && (!g.orderId || s.orders[0].order?.id !== g.orderId)) {
    g.orderId ??= randomUUID2();
    const index = s.orders.findIndex((slot) => slot.order?.id === g.orderId);
    if (index > 0) [s.orders[0], s.orders[index]] = [s.orders[index], s.orders[0]];
    else s.orders[0] = { order: firstOrder(g.orderId), readyAt: null };
  }
}
function openGuideOffers(s, g, now) {
  g.offers = pair(s, "lop", now, "开店种源");
  g.offerIds = idsOf(g.offers);
  g.purchased = [];
}
function repairPurchasedSeeds(s, g, now) {
  for (const [index, offer] of g.offers.entries()) {
    const id = offer.id;
    if (!g.purchased.includes(id)) continue;
    const pet = findPet(s, id);
    if (pet?.species === "rabbit" && pet.sex === offer.sex && pet.breedKey === "lop" && !pet.bred && pet.tutorialDeathAt === void 0 && !isBusy(s, pet)) continue;
    const restored = recoveredRabbit(s, g, now, "seed", id, {
      sex: offer.sex,
      breed: "lop",
      bornAt: adultOffer(offer, now).bornAt,
      traits: offer.traits,
      tagRulesVersion: offer.tagRulesVersion,
      tagCount: offer.tagCount
    });
    g.offers[index] = { ...offer, id: restored.id, name: restored.name };
    g.offerIds[index] = restored.id;
    g.purchased[g.purchased.indexOf(id)] = restored.id;
  }
}
function settleUnsoldParent(s, g, now) {
  const remaining = findPet(s, g.remainingId);
  if (!remaining?.bred || remaining.tutorialDeathAt !== void 0) return;
  const soldId = g.starters?.find((id) => id !== remaining.id && saleFor(s, "market", id));
  const deathAt = saleFor(s, "market", soldId)?.at ?? now;
  if (stageOf(remaining, deathAt) !== "已故") {
    remaining.tutorialDeathAt = deathAt;
    delete remaining.tutorialLifeGuard;
  }
}
function guideLitterPet(s, g) {
  for (const id of g.litterIds ?? []) {
    const pet = findPet(s, id);
    if (pet?.species === "rabbit" && pet.breedKey === "domestic" && !pet.mixed && !pet.retained && pet.tutorialDeathAt === void 0 && !isBusy(s, pet)) return pet;
  }
}
function protectOpeningAnimals(s, g, now) {
  const needed = new Set(g?.purchased ?? []);
  if (g && !g.remainingId) for (const id of g.starters ?? []) needed.add(id);
  if (g) {
    const delivery = guideLitterPet(s, g);
    if (delivery) needed.add(delivery.id);
  }
  for (const pet of s.pets) {
    if (needed.has(pet.id)) {
      pet.tutorialLifeGuard = true;
    } else if (pet.tutorialLifeGuard) {
      delete pet.tutorialLifeGuard;
      if (lifeDates(pet).deathAt < now) pet.tutorialDeathAt = now;
    }
  }
}
var openingSale = (s, g) => s.sales.find((sale) => sale.channel !== "recycle" && sale.lines.some((line) => g.litterIds?.includes(line.id)));
function openingRewardReady(s, g, now) {
  if (g.planAt || g.legacyRewardReady) return true;
  if (!g.litterIds?.length) return false;
  const children = g.litterIds.map((id) => findPet(s, id)).filter((p) => p && stageOf(p, now) !== "已故" && !p.bred);
  const retained = children.filter((p) => p.retained);
  if (parentSexes.every((sex) => retained.some((p) => p.sex === sex)) && (openingSale(s, g) || children.length === 2)) return true;
  return !parentSexes.every((sex) => children.some((p) => p.sex === sex));
}
function openingTaskPage(s, now) {
  const g = s.onboarding;
  if (!g || g.finishedAt) return;
  const born = !!g.litterIds?.length, done = openingRewardReady(s, g, now);
  const rows = [
    { title: "开放兔房", done: !!g.starters, link: choice(void 0, "rooms", rabbit2) },
    { title: "繁育第一窝", done: born, link: choice(void 0, "breed", rabbit2) },
    { title: "留种与出售", done, link: g.firstLitter ? choice(void 0, "litter", { ...rabbit2, bornAt: g.firstLitterAt }) : choice(void 0, "breed", rabbit2) }
  ];
  if (done) {
    const sale = g.planSaleTotal ?? openingSale(s, g)?.total;
    const seeds = s.pets.filter((p) => g.litterIds?.includes(p.id) && p.retained && !p.bred);
    const adultAt = Math.max(0, ...seeds.map((p) => lifeDates(p).adultAt));
    rows[2].text = [
      sale !== void 0 ? "出售所得 " + sale + " 金币" : "",
      seeds.length ? adultAt > now ? "种源成年还需约 " + Math.ceil((adultAt - now) / 6e4) + " 分钟" : "种源已成年" : ""
    ].filter(Boolean).join(" · ");
  }
  if (g.legacyRewardReady) rows.forEach((row2) => {
    row2.done = true;
  });
  return { title: "任务", subtitle: "领取开店奖励", rows, visual: { rewards: openingReward }, actions: [
    { ...action("领取", "onboarding.claim", {}, "tasks"), disabled: !done }
  ] };
}
function openingShortcut(s, now) {
  const page = openingTaskPage(s, now);
  if (!page) return;
  const completed = page.rows.filter((row2) => row2.done).length, next = page.rows.find((row2) => !row2.done);
  return {
    completed,
    total: page.rows.length,
    choice: next ? { ...next.link, label: next.title } : choice("领取开店奖励", "tasks")
  };
}
function openingPage(s, key, args, now) {
  if (key === "tasks") return openingTaskPage(s, now);
  if (key !== "offer") return;
  const g = s.onboarding, offer = g?.offers?.find((p) => p.id === args.id);
  if (!offer) return;
  const bought = g.purchased.includes(offer.id);
  const cash = guidePrice(s), aid = seedPrice - cash;
  const price = aid ? "开店补贴抵扣 " + aid + " 金币 · 实付 " + cash + " 金币" : "采购价格 " + seedPrice + " 金币";
  return {
    title: offer.name + " · " + offer.sex,
    art: petArt(offer),
    stage: "成年",
    subtitle: "垂耳兔 · 奶油 · 成年 · 未繁育",
    rows: [{ title: "成年种源", text: bought ? "已购入" : price }],
    actions: bought ? [choice("返回种源", "lab")] : [
      {
        ...action("核对购买", "onboarding.buy", { id: offer.id, price: seedPrice, cash }, "lab"),
        confirm: "购入 " + offer.name + "（" + offer.sex + "）？" + price + "。"
      }
    ]
  };
}
function decorateOpeningPage(s, key, args, view, now) {
  const g = s.onboarding;
  if (!g) return;
  if (key === "rooms" && g.teachingMealUsed && !g.firstLitterAt && (args.species ?? "rabbit") === "rabbit") {
    view.visual = { ...view.visual, grownIds: g.starters };
  }
  if (key === "roomNutrition" && (args.species ?? "rabbit") === "rabbit" && teachingPair(s, now)) {
    const feed = view.actions?.find((a) => a.type === "care.feed");
    if (feed?.args.tier === mealTier) view.visual = { ...view.visual, hint: "使用开店赠餐，两只小兔就会长大。" };
  }
  if (key === "breed" && view.presentation?.kind === "pairConfirm" && openingPair(s, args)) {
    view.presentation.waitText = "5 秒";
    view.rows[0].text = "开始后不能取消或更换亲本。5 秒后出生 4 只原色幼兔。";
  }
  if (key === "lab" && g.offers && !["nutrition", "services"].includes(args.tab)) {
    const offers = g.offers.filter((p) => !g.purchased.includes(p.id)).map((offer) => {
      const animal = specimen(s, adultOffer(offer, now), now, { inShop: false });
      return {
        title: animal.name,
        text: "开店种源 · " + seedPrice + " 金币",
        animal,
        art: animal.art,
        stage: "成年",
        link: choice(void 0, "offer", { ...rabbit2, id: offer.id }),
        visual: { price: seedPrice }
      };
    });
    view.rows = [...offers, ...view.rows];
  }
}
function openingAction(s, type, args, now) {
  const g = s.onboarding;
  if (!g) return;
  if (type === "onboarding.openRoom") {
    expect(rabbitWaitingForOpening(s), "兔房已开放。");
    const starters = pair(s, "domestic", now, "开店种源");
    s.rooms.rabbit.openedAt = now;
    s.rooms.rabbit.shelf = null;
    s.pets.push(...starters);
    g.starters = idsOf(starters);
    grantTeachingMeal(s.rooms.rabbit, g);
    protectOpeningAnimals(s, g, now);
    return "兔房已开放，两只原色幼兔已入住。获得 " + mealName + " ×1。";
  }
  if (type === "onboarding.feed" || type === "care.feed" && (args.species ?? "rabbit") === "rabbit" && args.tier === mealTier) {
    const starters = teachingPair(s, now);
    if (starters) {
      s.rooms.rabbit.nutritionStock[mealTier]--;
      for (const pet of starters) {
        const { growthAt, adultAt } = lifeDates(pet);
        if (now < adultAt) pet.maturation = { growthAt: Math.min(growthAt, now), adultAt: now };
      }
      g.teachingMealUsed = true;
      return "首对原色兔已成年。";
    }
    if (type === "onboarding.feed") expect(false, "请从兔房重新选择营养餐。");
  }
  if (type === "care.breed" && openingPair(s, args)) {
    const result = startLitter(s, args, now, { waitMs: firstLitterWait, plannedSexes: firstLitterSexes });
    g.firstLitterAt = s.rooms.rabbit.job.endsAt;
    return result;
  }
  if (type === "onboarding.buy") {
    const offer = g.offers?.find((p) => p.id === args.id);
    expect(offer && !g.purchased.includes(offer.id), "这个货位已购入或未开放。");
    const cash = guidePrice(s), aid = seedPrice - cash;
    expect(args.price === seedPrice && (args.cash === void 0 || args.cash === cash), "报价已变化，请重新核对购买。");
    const acquired = makePet(
      occupiedPetNames(s),
      "rabbit",
      "lop",
      offer.sex,
      now,
      "研究所采购",
      { ...adultOffer(offer, now), source: "研究所采购" }
    );
    s.coins -= cash;
    s.pets.push(acquired);
    if (aid) g.seedAid = (g.seedAid ?? 0) + aid;
    g.purchased.push(acquired.id);
    return acquired.name + "已入住兔房。" + (aid ? "开店补贴已抵扣 " + aid + " 金币。" : "");
  }
  if (type === "task.claim" && !g.finishedAt) expect(false, "请先领取开店奖励。");
  if (type === "onboarding.claim") {
    expect(!g.claimedAt && openingRewardReady(s, g, now), "开店奖励已领取，或留种与出售尚未完成。");
    const message = grantOpeningReward(s);
    g.claimedAt = g.finishedAt = now;
    protectOpeningAnimals(s, void 0, now);
    return message + " 已开启「安置兔房」。";
  }
}
function recordOpeningAction(s, type, args, now) {
  const g = s.onboarding;
  if (!g) return;
  if (type === "care.breed" && g.starters && !g.firstLitterAt && (args.species ?? "rabbit") === "rabbit") {
    g.firstLitterAt = s.rooms.rabbit.job.endsAt;
  }
  if (type !== "sale.commit") return;
  if (args.litterRetention?.opening) {
    g.planAt = now;
    g.planSaleTotal = s.sales.at(-1).total;
  }
  if (args.channel === "market" && g.firstLitterAt && !g.remainingId && g.starters?.some((id) => args.ids.includes(id))) {
    g.remainingId = g.starters.find((id) => findPet(s, id)?.bred);
    if (g.remainingId) settleUnsoldParent(s, g, now);
  }
  if (args.channel === "recycle" && g.remainingId && args.ids.includes(g.remainingId) && !g.offers) openGuideOffers(s, g, now);
}

// output/aliyun/source-market-breed-20261121/PetShop/server/care-pages.mjs
var go2 = (label, page, args = {}) => ({ label, page, args });
var link = (title, text, page, args = {}, extra = {}) => ({ title, text, link: { page, args }, ...extra });
var act = (label, type, args, confirm, page, goArgs = {}) => ({ label, type, args, confirm, go: page, goArgs });
var number = (p) => p.id.slice(0, 5).toUpperCase();
var options = (s, page, current2) => Object.entries(SPECIES).map(([species, c]) => ({
  ...go2(c.name + "房", page, { species }),
  active: species === current2,
  locked: !s.rooms[species] || species === "rabbit" && rabbitWaitingForOpening(s)
}));
var petRow = (s, p, now, page = "pet", args = { id: p.id }) => {
  const animal = specimen(s, p, now);
  return link(
    animal.name + " · " + animal.sex,
    [animal.breed, animal.coat, animal.stage, animal.status].join(" · "),
    page,
    args,
    { art: animal.art, stage: animal.stage, animal }
  );
};
var describeRemaining = (ms) => ms < 6e4 ? Math.max(1, Math.ceil(ms / 1e3)) + " 秒" : ms < 36e5 ? Math.ceil(ms / 6e4) + " 分钟" : ms < 864e5 ? Math.ceil(ms / 36e5) + " 小时" : Math.ceil(ms / 864e5) + " 天";
var empty = (title, text, page = "rooms") => ({ title, rows: [{ title: text }], actions: [go2("查看名册", page)] });
var speciesKey = (a) => a.species && Object.hasOwn(SPECIES, a.species) ? a.species : "rabbit";
function closedRoom(s, species, page, now) {
  if (species === "rabbit" && rabbitWaitingForOpening(s)) {
    return {
      title: "动物小屋",
      art: SPECIES.rabbit.art,
      visual: { openingRoom: true },
      presentation: { kind: "locked", species: "兔", breed: BREEDS.domestic.name, youngArt: "pets/domestic-coat01_female" },
      tabs: options(s, page, species),
      rows: [],
      actions: page === "rooms" ? [act("免费开放兔房", "onboarding.openRoom", {}, void 0, "rooms", { species })] : [go2("查看兔房", "rooms", { species })]
    };
  }
  const c = SPECIES[species], cost2 = purchasePrice(s, c.roomCost), firstBreed = BREEDS[c.breeds[0]];
  const { name: breed, maturityMinutes: maturity } = firstBreed;
  const estimate = beijingTime(now + maturity * 6e4).slice(0, 16);
  const balance = s.coins - cost2;
  return {
    title: c.name + "房 · 待开放",
    art: "rooms/unfinished-room",
    subtitle: "新房套餐",
    presentation: { kind: "locked", species: c.name, youngArt: "pets/" + c.breeds[0] + "-coat01_female", maturity, estimate, breed, price: cost2, coins: s.coins },
    rows: [
      { title: breed + "幼体一对", text: "公母各一只，六维 B，入住房间后开始成长。" },
      { title: "房间及两只种源", text: "基准 " + c.roomCost + " 金币 · 实付 " + cost2 + " 金币 · 余额 " + s.coins }
    ],
    tabs: options(s, page, species),
    actions: page === "rooms" ? [{ ...act("解锁" + c.name + "房", "care.unlock", { species, price: cost2 }, "支付 " + cost2 + " 金币开放" + c.name + "房，接收一公一母两只" + breed + "幼体？付款后余 " + Math.max(0, balance) + " 金币，若现在入住，预计北京时间 " + estimate + " 成年。", "roomReceipt", { species }), disabled: balance < 0 }] : [go2("查看" + c.name + "房", "rooms", { species })]
  };
}
function openingReceipt(s, species) {
  const receipt = s.rooms[species]?.openingReceipt;
  if (!receipt) return empty("新房入住记录", "这份经营档没有保存该次入住的明细。", "rooms");
  return {
    title: SPECIES[species].name + "房入住回执",
    subtitle: "新房已开放 · 北京时间",
    rows: [
      ...receipt.pair.map((p) => ({
        title: p.sex + " · " + p.name + " #" + number(p),
        text: BREEDS[p.breedKey].name + " · " + coatName(p) + " · 入住时为幼体"
      })),
      { title: "出生及入住", text: beijingTime(receipt.bornAt) },
      { title: "成年时刻", text: beijingTime(receipt.adultAt) },
      { title: "本次实付", text: receipt.paid + " 金币 · 成交后余额 " + receipt.balance + " 金币" }
    ],
    actions: [{ label: "查看本房名册", type: "ui.back" }]
  };
}
function roster(s, a, now) {
  const species = speciesKey(a), cfg = SPECIES[species], room = s.rooms[species];
  if (!room || species === "rabbit" && rabbitWaitingForOpening(s)) return closedRoom(s, species, "rooms", now);
  const all = s.pets.filter((p) => p.species === species);
  const breedKey = (p) => p.mixed ? "mixed" : p.breedKey;
  const breeds = new Map(all.map((p) => [breedKey(p), breedName(p)]));
  const breed = breeds.has(a.breed) ? a.breed : void 0;
  const stage = rosterStage(a.stage, a.filter);
  const shown = [];
  let nextStageAt = null;
  for (const p of all) {
    const end = stageEnd(p, now);
    if (end !== null && (nextStageAt === null || end < nextStageAt)) nextStageAt = end;
    if (breed && breedKey(p) !== breed || stage !== "全部" && stageOf(p, now) !== stage) continue;
    const row2 = petRow(s, p, now);
    row2.animal.stageEndsAt = end;
    shown.push(row2);
  }
  const residents = shown.slice(0, 10).map((row2) => row2.animal);
  const nutrition = activeNutrition(room, now);
  return {
    title: "动物小屋",
    art: cfg.art,
    animals: residents.map((p) => p.art),
    animalStages: residents.map((p) => p.stage),
    presentation: {
      kind: "rooms",
      species: cfg.name,
      count: all.length,
      matchedCount: shown.length,
      residents,
      nextStageAt,
      ...nutrition && { nutrition }
    },
    subtitle: "名册 " + shown.length + " 只 · " + (breeds.get(breed) ?? "全部") + " · " + stage,
    rows: [
      link(room.job ? "查看正在繁育的一窝" : "进入繁育台", room.job ? "预计 " + describeRemaining(room.job.endsAt - now) + " 后出生" : "挑选亲本，查看幼体的缺陷率和完美无缺率", "breed", { species }),
      ...room.lastLitter ? [link("最近出生的一窝", room.lastLitter.ids.length + " 只", "litter", { species })] : [],
      ...room.openingReceipt ? [link("查看入住回执", "购房时的两只幼体、成年时刻与余款", "roomReceipt", { species })] : [],
      ...shown,
      ...!shown.length ? [{ title: "当前筛选下没有动物。" }] : []
    ],
    tabs: options(s, "rooms", species),
    filters: [
      [["", "全部"], ...breeds].map(([key, label]) => ({
        ...go2(label, "rooms", { species, ...key && { breed: key }, stage }),
        active: key === (breed ?? "")
      })),
      ["全部", ...stageNames].map((v) => ({ ...go2(v, "rooms", { species, ...breed && { breed }, stage: v }), active: v === stage }))
    ]
  };
}
function checkin(s, now) {
  const signed = s.care.signedDay === dayAt(now);
  const breedKey = signed ? s.care.claimAnimals?.[0]?.breedKey ?? "domestic" : nextCheckinBreed(s);
  const { name: breed, coats, maturityMinutes: maturity } = BREEDS[breedKey];
  const rows = [{ title: "今日后备种源", text: breed + "幼体一公一母，" + coats[0] + "花色，六维均为 B。每天北京时间零点更新。" }];
  if (signed) rows.push(...s.pets.filter((p) => s.care.claimIds.includes(p.id)).map((p) => petRow(s, p, now)));
  return {
    title: "每日签到",
    art: "shop-modules/checkin",
    subtitle: signed ? "今日已领取" : "今日可领取",
    rows,
    presentation: { kind: "checkin", date: dayAt(now), signed, breed, youngArt: "pets/" + breedKey + "-coat01_female", maturity },
    actions: [...signed ? [] : [act("领养两只幼兔", "care.checkin", {}, void 0, "profile")], go2("查看兔房名册", "rooms", { species: "rabbit" })]
  };
}
function checkinReceipt(s) {
  const animals2 = s.care.claimAnimals ?? s.pets.filter((p) => s.care.claimIds?.includes(p.id));
  if (!animals2.length) return { title: "签到记录", rows: [{ title: "暂无可查看的领取记录。" }], actions: [{ label: "关闭", type: "ui.back" }] };
  return {
    title: "签到成功",
    subtitle: "获得 " + animals2.length + " 只幼兔",
    rows: animals2.map((p) => ({ title: p.name + " · " + p.sex, text: breedName(p) + " · " + coatName(p) + " · 幼年", art: petArt(p), stage: "幼年" })),
    actions: [{ label: "知道了", type: "ui.back" }]
  };
}
function ageDescription(ms) {
  const minutes2 = Math.max(0, Math.floor(ms / 6e4));
  if (!minutes2) return "不足 1 分钟";
  const days = Math.floor(minutes2 / 1440), hours = Math.floor(minutes2 / 60) % 24;
  return [days && days + " 天", hours && hours + " 小时", minutes2 % 60 && minutes2 % 60 + " 分钟"].filter(Boolean).join(" ");
}
function priceRows(s, p, now) {
  const dead = stageOf(p, now) === "已故";
  const total = salePrice(s, p, now, dead ? "recycle" : "market");
  return [{ title: dead ? "当前回收估值" : "当前市场估值", text: total + " 金币" + (p.retained ? " · 已留种保护" : isBusy(s, p) ? " · 繁育中" : "") }];
}
function detail(s, a, now) {
  const p = s.pets.find((p2) => p2.id === a.id);
  if (!p) return empty("动物档案", "这只动物已离店。");
  const stage = stageOf(p, now), until = stageEnd(p, now), dates = lifeDates(p);
  const history = p.reviewHistory ?? [], unrecorded = p.reviews - history.length;
  const room = s.rooms[p.species], doses = antiAgeUses(p), reshaped = reshapeUses(p);
  const hasAntiAge = room && serviceItemStock(room, "antiAge") > 0;
  const hasReshape = room && serviceItemStock(room, "reshape") > 0;
  return {
    title: "个体档案",
    art: petArt(p),
    stage,
    subtitle: breedName(p) + " · " + coatName(p) + " · " + p.sex,
    presentation: { kind: "pet", species: SPECIES[p.species].name, speciesKey: p.species, animal: specimen(s, p, now), traits: p.traits.slice(0, 5), nextStageAt: until },
    rows: [
      { title: "阶段", text: until ? stage + " · 距" + { 幼年: "成长", 成长: "成年", 成年: "老年", 老年: "寿终" }[stage] + " " + describeRemaining(until - now) : stage !== "已故" ? "仍在房内。" : p.retained ? "取消留种后可前往动物回收。" : "已故个体可在培育中心回收。" },
      { title: "来源", text: p.source + (p.motherId ? " · 母 " + p.motherName + " / 父 " + p.fatherName : "") + (p.mixed ? " · 外形 " + BREEDS[p.breedKey].name : "") },
      { title: "复评 " + p.reviews + " / 3 次", text: "已获最高荣誉系数 " + p.honor },
      { title: stage === "已故" ? "寿终时年龄" : "实际年龄", text: ageDescription(Math.min(now, dates.deathAt) - p.bornAt) },
      { title: "出生时刻", text: beijingTime(p.bornAt) + "（北京）" },
      { title: "成年时刻", text: beijingTime(dates.adultAt) + "（北京）" },
      ...doses ? [{ title: "抗衰老药剂", text: "已用 " + doses + " / " + antiAgeLimit + " 份 · 老年期增加 " + doses + " 天" }] : [],
      ...reshaped ? [{ title: "缺陷重塑剂", text: "已用 " + reshaped + " / " + reshapeLimit + " 份" }] : [],
      ...stage === "已故" ? [{ title: "自然寿终", text: beijingTime(dates.deathAt) + "（北京）" }] : [],
      ...priceRows(s, p, now),
      ...unrecorded > 0 ? [{ title: "早期复评", text: "此前 " + unrecorded + " 次复评仅留有次数。" }] : [],
      ...history.map((h) => ({ title: fields[h.field] + "复评", text: beijingTime(h.at) + "（北京） · " + h.before + "（" + h.beforeRarity + "） → " + h.after + "（" + h.afterRarity + "） · 评分 " + h.grade }))
    ],
    actions: [
      ...p.retained || !p.bred && stage !== "已故" ? [{ label: p.retained ? "取消留种" : "留种", type: "care.retain", args: { id: p.id, retained: !p.retained } }] : [],
      ...canBreed(s, p, now) ? [go2("去繁育台配对", "breed", { species: p.species, [p.sex === "公" ? "father" : "mother"]: p.id })] : [],
      ...!isBusy(s, p) && stage !== "已故" ? [{ ...go2(p.reviews >= 3 ? "复评次数已用完" : "特征复评", "review", { species: p.species, id: p.id }), disabled: p.reviews >= 3 }] : [],
      ...hasAntiAge && stage !== "已故" && doses < antiAgeLimit ? [act(
        "使用抗衰老药剂",
        "care.antiAge",
        { species: p.species, id: p.id },
        "用 1 份后，老年期会多 1 天。还可用 " + (antiAgeLimit - doses) + " 次。",
        "pet",
        { id: p.id }
      )] : [],
      ...hasReshape && ["幼年", "成长"].includes(stage) && reshaped < reshapeLimit ? [act(
        "使用缺陷重塑剂",
        "care.reshape",
        { species: p.species, id: p.id },
        "55% 减轻一档，45% 加重一档。若结果超过最高或最低档，会保留原档，仍消耗 1 份。还可用 " + (reshapeLimit - reshaped) + " 次。",
        "pet",
        { id: p.id }
      )] : [],
      ...!isBusy(s, p) && !p.retained ? [stage === "已故" ? go2("前往动物回收", "recycle", { species: p.species, preselectId: p.id }) : go2("前往自由市场", "market", { preselectId: p.id })] : []
    ]
  };
}
function pairPage(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room || species === "rabbit" && rabbitWaitingForOpening(s)) return closedRoom(s, species, "breed", now);
  if (room.job) return {
    title: "繁育台",
    art: cfg.art,
    subtitle: "繁育进行中",
    presentation: {
      kind: "breeding",
      species: cfg.name,
      endsAt: room.job.endsAt,
      remaining: room.job.endsAt - now,
      parents: [room.job.mother, room.job.father].map((p) => specimen(s, p, now))
    },
    rows: [{ title: room.job.mother.name + " × " + room.job.father.name, text: "预计 " + describeRemaining(room.job.endsAt - now) + " 后出生。离开店铺也会继续计时。" }],
    tabs: options(s, "breed", species),
    actions: [go2("前往动物房间", "rooms", { species })]
  };
  const choices = s.pets.filter((p) => p.species === species && canBreed(s, p, now)).sort((a2, b) => Number(b.retained === true) - Number(a2.retained === true));
  const mother = choices.find((p) => p.id === a.mother && p.sex === "母"), father = choices.find((p) => p.id === a.father && p.sex === "公");
  const args = { species, ...mother ? { mother: mother.id } : {}, ...father ? { father: father.id } : {} };
  const guide = mother && father && a.useGuide === true && room.items.guide > 0 && !a.picking ? guideField(s, mother, father) : -1;
  const selection = validSelection(room, a.selection) && !a.picking ? a.selection : null;
  const [rare = 0, mutation = 0] = s.research?.[species] ?? [];
  const preview = mother && father ? mutationPreview(mother, father, guide, mutation, !!room.mutationEnabled) : void 0;
  if (!mother || !father || a.picking) {
    const sex = !mother ? "母" : "公", pool = choices.filter((p) => p.sex === sex);
    return {
      title: "繁育台",
      art: "shop-modules/breeding-guide",
      subtitle: "挑选一公一母 · 目前可配 " + choices.length + " 只",
      presentation: {
        kind: "pair",
        species: cfg.name,
        wait: cfg.wait,
        parents: [mother, father].map((p) => p ? specimen(s, p, now) : null),
        mutationPreview: preview,
        candidates: choices.map((p) => specimen(s, p, now)),
        confirm: mother && father ? go2("核对亲本", "breed", args) : null
      },
      rows: [
        { title: mother ? "母本：" + mother.name : father ? "父本：" + father.name : "选择亲本", text: "点选一只可配的" + sex + "性作为" + (sex === "母" ? "母本" : "父本") + "。" },
        ...pool.map((p) => petRow(s, p, now, "breed", { ...args, [sex === "母" ? "mother" : "father"]: p.id })),
        ...!pool.length ? [{ title: "暂无合适的" + sex + "性亲本", text: "成年、老年且未繁育的空闲动物可参与配对。" }] : []
      ],
      tabs: options(s, "breed", species),
      actions: [...room.lastLitter && !room.lastLitter.viewed ? [go2(room.lastLitter.bornAt === s.onboarding?.firstLitterAt ? "查看首窝" : "查看最近一窝", "litter", { species })] : [], go2("查看房间", "rooms", { species })]
    };
  }
  const registration = mixedOffspring(mother, father) ? "杂交" : BREEDS[mother.breedKey].name;
  const summary = ["确认让 " + mother.name + " 和 " + father.name + " 使用一生唯一的繁育机会？", "后代品种 " + registration];
  const research = [];
  if (rare > 0) research.push("稀有率+" + rare * 5 + "%");
  if (room.mutationEnabled && mutation > 0) research.push("属性提升+" + mutation * 3 + "%");
  if (research.length) summary.push("研究加成 " + research.join("，"));
  if (guide >= 0) {
    const same = mother.traits[guide].grade === father.traits[guide].grade;
    summary.push("选育指导单抽中「" + fields[guide] + "」。" + (same ? "父母同档，照常遗传。" : "每只幼崽有 80% 的机会从较高档起算，之后自然升降。") + "整窝显示绿色「优选」。");
  }
  if (selection) summary.push(selectionItemNames[selection.item] + "：随机一只幼崽的" + selection.fields.map((i) => fields[i]).join("、") + "保留双亲较高等级，并显示蓝色「优选」。");
  const breedingArgs = { ...args, ...guide >= 0 && { useGuide: true }, ...selection && { selection } };
  if (mother.retained || father.retained) summary.push("幼体出生时，双亲自动取消留种。");
  return {
    title: "确认配对",
    subtitle: mother.name + " × " + father.name,
    art: cfg.art,
    animals: [petArt(mother), petArt(father)],
    animalStages: [stageOf(mother, now), stageOf(father, now)],
    presentation: {
      kind: "pairConfirm",
      species: cfg.name,
      wait: cfg.wait,
      parents: [mother, father].map((p) => specimen(s, p, now)),
      guide: { count: room.items.guide, index: guide },
      mutationPreview: preview,
      parentTraits: fields.map((name, i) => ({ name, ...Object.fromEntries([["mother", mother], ["father", father]].map(([side, pet]) => [side, { ...pet.traits[i], label: i === 5 ? defectDisplayLabel(pet.traits[i].grade) : pet.traits[i].label || "—" }])) }))
    },
    rows: [{ title: "一生仅一次繁育", text: "开始后不可取消或换亲本。等待 " + cfg.wait + " 分钟，预计 " + cfg.min + "–" + (cfg.min + cfg.litter.length - 1) + " 只。" }],
    actions: [
      act("开始繁育", "care.breed", breedingArgs, summary.join("\n"), "breed", { species }),
      go2("取消繁育", "breed", { ...args, picking: true }),
      act(room.mutationEnabled ? "关闭五维加成" : "启用五维加成", "care.toggle", { species, enabled: !room.mutationEnabled }, void 0, "breed", breedingArgs),
      go2(guide >= 0 || selection ? "已添加道具" : "添加道具", "breedItems", breedingArgs)
    ]
  };
}
function breedingItems(s, a, now) {
  const pairing = pairPage(s, { ...a, picking: false }, now);
  const title = "添加道具", back = { type: "ui.back", label: "取消" };
  const start = pairing.actions?.find((choice2) => choice2.type === "care.breed");
  if (!start) return { title, rows: [{ title: "亲本已变动，请返回重新选择。" }], actions: [back] };
  const species = start.args.species, room = s.rooms[species];
  const useGuide = start.args.useGuide === true;
  const item = a.selection?.item, count = selectionFieldCount(item);
  const picked = count > 0 && serviceItemStock(room, item) > 0;
  const chosen = picked && Array.isArray(a.selection.fields) ? [...new Set(a.selection.fields.filter((i) => Number.isInteger(i) && i >= 0 && i < 5))].slice(0, count) : [];
  const selection = picked ? { item, fields: chosen } : null;
  const initial = { species, mother: start.args.mother, father: start.args.father };
  const current2 = { ...initial, useGuide, selection };
  const guideTitle = (useGuide ? "✓ " : "") + "选育指导单 · 持有 " + room.items.guide + " 张";
  const rows = [{
    title: guideTitle,
    text: useGuide ? "系统抽中「" + fields[pairing.presentation.guide.index] + "」。整窝幼崽显示绿色「优选」。" : "系统随机选 1 项属性。父母等级不同时，80% 从较高档起算，后续照常升降。",
    ...room.items.guide > 0 && { link: go2("切换指导单", "breedItems", { ...current2, useGuide: !useGuide }) }
  }];
  for (const [key, label] of Object.entries(selectionItemNames)) {
    const stock = serviceItemStock(room, key);
    rows.push({
      title: (item === key ? "✓ " : "") + label + " · 持有 " + stock + " 张",
      text: "手动选择 " + selectionFieldCount(key) + " 项，随机一只幼崽保留较高等级。",
      ...stock > 0 && { link: go2(label, "breedItems", { ...current2, selection: item === key ? null : { item: key, fields: [] } }) }
    });
  }
  if (selection) {
    for (const [i, name] of fields.slice(0, 5).entries()) {
      const active = chosen.includes(i), next = active ? chosen.filter((index) => index !== i) : [...chosen, i];
      const row2 = { title: (active ? "✓ " : "") + name };
      if (next.length <= count) row2.link = go2(name, "breedItems", { ...current2, selection: { item, fields: next } });
      rows.push(row2);
    }
  }
  return { title, rows, actions: [{
    ...go2("完成", "breed", { ...initial, ...useGuide && { useGuide: true }, ...selection && { selection } }),
    disabled: !!selection && !validSelection(room, selection)
  }, back] };
}
function litter(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], first = species === "rabbit" && s.onboarding?.firstLitter;
  const l = first && a.bornAt === first.bornAt ? first : room?.lastLitter;
  if (!l) return empty("出生记录", "这间房还没有出生记录。");
  const residents = new Map(s.pets.map((p) => [p.id, p]));
  const birthRecords = new Map((l.children ?? []).map((p) => [p.id, p]));
  const missing = new Set(l.ids.filter((id) => !residents.has(id) && !birthRecords.has(id)));
  const historicalNames = /* @__PURE__ */ new Map();
  if (missing.size) {
    for (const { pet } of Object.values(s.show?.entries ?? {})) {
      if (!missing.has(pet?.id)) continue;
      if (pet.name) historicalNames.set(pet.id, pet.name);
      if (SPECIES[species].breeds.includes(pet.breedKey) && BREEDS[pet.breedKey].coats[pet.coatIndex - 1] && ["公", "母"].includes(pet.sex)) birthRecords.set(pet.id, pet);
    }
    for (const sale of s.sales ?? []) for (const line of sale.lines) if (missing.has(line.id) && line.name) historicalNames.set(line.id, line.name);
  }
  const children = l.ids.map((id) => {
    const current2 = residents.get(id);
    if (current2) return { ...petRow(s, current2, now), litterMember: true };
    const p = birthRecords.get(id), tag = "#" + number({ id });
    if (!p) return { litterMember: true, title: (historicalNames.get(id) || "同窝幼体") + " · " + tag, text: "已离店 · 早期记录未保存外观" };
    const animal = {
      id,
      number: number(p),
      name: p.name,
      sex: p.sex,
      breed: breedName(p),
      coat: coatName(p),
      stage: "幼年",
      status: "已离店",
      art: petArt(p),
      departed: true,
      ...Number.isFinite(p.score) && { score: p.score }
    };
    return { litterMember: true, title: p.name + " · " + p.sex, text: [animal.breed, animal.coat, tag, "已离店 · 出生时外观"].join(" · "), animal, art: animal.art, stage: animal.stage };
  });
  const portraits = children.filter((row2) => row2.art);
  return {
    title: "这一窝出生了",
    subtitle: "父本·" + l.father + "  母本·" + l.mother + " | 共" + l.ids.length + "只宝宝",
    presentation: { kind: "litter", species: SPECIES[species].name, speciesKey: species, count: l.ids.length, bornAt: l.bornAt },
    art: SPECIES[species].art,
    animals: portraits.map((row2) => row2.art),
    animalStages: portraits.map((row2) => row2.stage),
    rows: [{ title: "本窝出生", text: beijingTime(l.bornAt) + "（北京时间）" }, ...children],
    actions: [go2("挑选留种", "litterKeep", { species, bornAt: l.bornAt }), go2("前往动物房间", "rooms", { species })]
  };
}
function litterSelection(s, page, a, now) {
  const species = speciesKey(a), room = s.rooms[species], g = s.onboarding;
  const opening = species === "rabbit" && g?.firstLitter && a.bornAt === g.firstLitterAt && !g.planAt && !g.finishedAt;
  const latest = opening ? g.firstLitter : room?.lastLitter;
  if (!latest || latest.bornAt !== a.bornAt) {
    return { title: "出生记录已更新", rows: [{ title: "请重新打开这间房的出生记录。" }], actions: [go2("查看出生记录", "litter", { species })] };
  }
  const members = litterCandidates(s, latest, now), eligible2 = members.filter((p) => !p.retained);
  const identity = { species, bornAt: latest.bornAt };
  if (opening) {
    const back = go2("重新挑选", "litterKeep", identity);
    if (page === "litterKeep") {
      const canPlan = eligible2.length > 0 && members.some((p) => p.sex === "公") && members.some((p) => p.sex === "母") && members.length >= 3;
      return {
        title: "首窝留种与出售",
        subtitle: "已有种源会保留。选一公一母留种，再选一只出售。",
        selectionLabel: "留种",
        rows: members.map((p) => ({ ...petRow(s, p, now), ...!p.retained && { select: p.id } })),
        actions: canPlan ? [{ ...go2("挑选出售", "openingLitterSale", identity), useSelection: true, allowEmptySelection: true }] : [go2("查看兔房", "rooms", { species })]
      };
    }
    const keepIds = page === "openingLitterSale" ? a.ids : a.keepIds;
    const kept = eligible2.filter((p) => Array.isArray(keepIds) && keepIds.includes(p.id));
    const retained = [...members.filter((p) => p.retained), ...kept];
    if (!Array.isArray(keepIds) || new Set(keepIds).size !== kept.length || retained.length !== 2 || retained[0].sex === retained[1].sex) {
      return { title: "核对首窝留种", rows: [{ title: "请选择一公一母留种。" }], actions: [back] };
    }
    const saleable = eligible2.filter((p) => !keepIds.includes(p.id));
    if (page === "openingLitterSale") {
      return {
        title: "挑选出售",
        subtitle: "只出售一只，其余留在兔房。",
        selectionLabel: "出售",
        visual: { singleSelect: true },
        rows: saleable.map((p) => ({ ...petRow(s, p, now), link: void 0, select: p.id })),
        actions: [{ ...go2("核对售价", "openingLitterQuote", { ...identity, keepIds }), useSelection: true }, back]
      };
    }
    if (page !== "openingLitterQuote" || a.ids?.length !== 1 || !saleable.some((p) => p.id === a.ids[0])) {
      return { title: "核对出售", rows: [{ title: "请选择一只可出售的首窝兔子。" }], actions: [back] };
    }
    const quote = businessPage(s, "saleQuote", { channel: "market", ids: a.ids }, now);
    quote.subtitle = "留种 2 只 · " + quote.subtitle;
    quote.rows.unshift({
      title: "留种 " + retained.map((p) => p.name).join("、"),
      text: "其余 " + (members.length - 3) + " 只继续养在兔房。"
    });
    quote.actions = quote.actions.map((a2) => a2.type === "sale.commit" ? {
      ...a2,
      label: "确认选择",
      go: "tasks",
      args: { ...a2.args, litterRetention: { ...identity, keepIds, opening: true } }
    } : go2("修改出售", "openingLitterSale", { ...identity, ids: keepIds }));
    return quote;
  }
  if (page === "openingLitterSale" || page === "openingLitterQuote") {
    return { title: "出生记录已更新", rows: [{ title: "请重新查看出生记录。" }], actions: [go2("查看出生记录", "litter", { species })] };
  }
  return {
    title: "挑选留种",
    subtitle: "勾选要留作种源的动物。",
    selectionLabel: "留种",
    rows: members.map((p) => ({ ...petRow(s, p, now), ...!p.retained && { select: p.id } })),
    empty: "这一窝当前没有可挑选的未繁育动物。",
    actions: [{ ...act("留作种源", "care.keepLitter", identity, void 0, "litter", identity), useSelection: true, disabled: !eligible2.length }]
  };
}
function shelves(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room) return closedRoom(s, species, "shelf", now);
  return {
    title: cfg.name + "种源货架",
    art: "shop-modules/lab",
    subtitle: "本批剩余 " + describeRemaining(shelfBatchEndsAt(room) - now),
    rows: room.shelf.offers.map((p, i) => p ? shelfRow(s, p, species, now) : { title: (i === 0 ? "公" : "母") + "幼体 · 本批已售", text: "本批不再补货。下一批的品种和标签随机。" }),
    tabs: options(s, "shelf", species)
  };
}
function shelfRow(s, p, species, now) {
  const animal = specimen(s, { ...p, bornAt: now }, now, { inShop: false }), price = purchasePrice(s, youngPurchaseBase(p));
  return link(
    p.name + " · " + p.sex,
    animal.breed + " · " + animal.coat + " · " + price + " 金币",
    "offer",
    { species, id: p.id },
    { animal, art: animal.art, stage: animal.stage, visual: { price } }
  );
}
function labCatalog(s, args, now) {
  const species = Object.keys(SPECIES).filter((key) => s.rooms[key]);
  const page = { title: "培育中心", art: "shop-modules/lab" };
  if (args.tab === "nutrition") {
    const menus = species.map((key) => nutritionPage(s, "nutritionShop", key, void 0, now).rows);
    return { ...page, subtitle: "营养餐", rows: [0, 1, 2].flatMap((i) => menus.map((rows) => rows[i])) };
  }
  if (args.tab === "services") {
    const menus = species.map((key) => services(s, { species: key }, now));
    return { ...page, rows: Object.keys(itemName).flatMap((item, i) => menus.map((menu) => {
      const { label, type, args: args2, confirm } = menu.actions[i];
      return {
        ...menu.rows[i],
        title: SPECIES[args2.species].name + "用" + menu.rows[i].title,
        ...serviceItemUnit(item) === "张" && { art: "shop-modules/" + (item === "review" ? "research-review" : "breeding-guide") },
        action: { label, type, args: args2, confirm, disabled: s.coins < args2.price }
      };
    })) };
  }
  const stock = species.filter((key) => s.rooms[key].shelf && (key !== "rabbit" || !rabbitWaitingForOpening(s))).map((key) => ({ key, room: s.rooms[key] }));
  const nextBatchAt = stock.length ? Math.min(...stock.map(({ room }) => shelfBatchEndsAt(room))) : void 0;
  return {
    ...page,
    ...nextBatchAt !== void 0 && {
      subtitle: "下一批 " + Math.max(0, Math.ceil((nextBatchAt - now) / 6e4)) + " 分钟",
      visual: { nextBatchAt }
    },
    empty: "本批种源已售完，请等下一批上架。",
    rows: [0, 1].flatMap((i) => stock.flatMap(({ key, room }) => room.shelf.offers[i] ? [shelfRow(s, room.shelf.offers[i], key, now)] : [])),
    actions: species.some((key) => key !== "rabbit") ? [go2("定向种源预约", "seedReservation"), go2("品种培育课题", "breedingCourses")] : []
  };
}
function offerPage(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], p = room?.shelf.offers.find((x) => x?.id === a.id);
  if (!p) return { title: "种源货位", rows: [{ title: "该幼体已经售出或换批。" }], actions: [go2("查看本批种源", "lab")] };
  const base = youngPurchaseBase(p), price = purchasePrice(s, base);
  return {
    title: p.name + " · " + p.sex,
    subtitle: breedName(p) + " · " + coatName(p) + " · 幼年",
    art: petArt(p),
    stage: "幼年",
    rows: [
      { title: "采购报价", text: "基准 " + base + " · 实付 " + price + " 金币" },
      ...offerOrderRows(s, p, now),
      { title: "估价有效条件", text: "按当前店铺评分、订单和幼体状态估算。成长、获奖或订单变化后，交付时会重新核价。" },
      ...p.traits.map((t, i) => ({ title: t.type + " · " + t.grade, text: i === 5 ? defectDisplayLabel(t.grade) : t.label ? t.label + " · " + t.rarity : "无特征标签" }))
    ],
    actions: [act("购买幼体", "care.buyPet", { species, id: p.id, batch: room.shelf.number, price }, "支付 " + price + " 金币购买 " + p.name + "？", "shelf", { species })]
  };
}
var serviceEffects = {
  review: "随机改变 1 条标签的稀有度，可能降档。系统等概率选取已有标签，标签名字和属性等级不变。每只动物最多用 3 张。",
  guide: "随机挑 1 项属性。父母等级不同时，每只幼崽有 80% 的机会从较高档起算，之后仍可能升档或降档。整窝显示绿色「优选」。",
  single: "繁育前选 1 项属性，同窝随机一只保留双亲较高的等级，显示蓝色「优选」。",
  double: "繁育前选 2 项不同属性，同窝随机一只的两项都保留双亲较高的等级，显示蓝色「优选」。",
  reshape: "成年前才能用。55% 减轻一档，45% 加重一档，超过边界保留原档。每只最多用 3 份。",
  antiAge: "每份只将老年期延长 1 天。活体可用，每只最多用 3 份。"
};
function services(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species], cfg = SPECIES[species];
  if (!room) return closedRoom(s, species, "services", now);
  const list = Object.keys(itemName).map((item) => {
    const price = serviceItemPrice(s, species, item), unit = serviceItemUnit(item);
    const discounted = item === "review" && price !== cfg.review;
    const quote = item === "review" ? "购买一张" + cfg.name + "用" + itemName[item] + "？基准 " + cfg.review + " 金币，实付 " + price + " 金币。" : "支付 " + price + " 金币，购买 1 " + unit + cfg.name + "用" + itemName[item] + "？";
    return {
      row: {
        title: itemName[item] + " · 持有 " + serviceItemStock(room, item) + " " + unit,
        text: serviceEffects[item] + "\n每" + unit + " " + price + " 金币" + (discounted ? "（原价 " + cfg.review + " 金币）" : ""),
        visual: { unit }
      },
      action: act("购买" + itemName[item], "care.buyItem", { species, item, price }, quote, "services", { species })
    };
  });
  return {
    title: cfg.name + "用物品",
    art: "shop-modules/lab",
    rows: list.map((item) => item.row),
    tabs: options(s, "services", species),
    actions: [
      ...list.map((item) => item.action),
      go2("选择动物复评", "review", { species }),
      go2("前往繁育台", "breed", { species })
    ]
  };
}
function review(s, a, now) {
  const species = speciesKey(a), room = s.rooms[species];
  if (!room) return closedRoom(s, species, "review", now);
  const animals2 = s.pets.filter((p2) => p2.species === species && stageOf(p2, now) !== "已故" && !isBusy(s, p2) && p2.reviews < 3);
  const p = animals2.find((p2) => p2.id === a.id);
  if (!p) return {
    title: "选择复评动物",
    subtitle: SPECIES[species].name + "用复评单 " + room.items.review + " 张",
    rows: animals2.map((p2) => petRow(s, p2, now, "review", { species, id: p2.id })),
    empty: "没有符合条件的动物。",
    actions: [go2("购买物品", "lab", { tab: "services" })]
  };
  const tags = getPetTags(p);
  const warning = "随机改变 1 条标签的稀有度，可能降档。";
  return {
    title: "特征复评",
    art: petArt(p),
    stage: stageOf(p, now),
    subtitle: "剩余次数 " + (3 - p.reviews) + " · 持有 " + room.items.review + " 张",
    presentation: { kind: "review", animal: specimen(s, p, now), reviews: p.reviews, inventory: room.items.review },
    rows: [
      { title: "当前特征标签", text: "由系统等概率随机选取 1 条已有标签，标签名字和属性等级不变。" },
      { title: warning, text: "每次消耗 1 张特征复评单和 1 次额度，每只最多 3 次。" + (p.tagRulesVersion === 2 ? "" : "本只保留原有标签和已用次数，本次使用新复评规则。") }
    ],
    actions: [
      { ...act("使用 1 张复评单", "care.review", { species, id: p.id }, "为「" + p.name + "」使用 1 张复评单？" + warning + "标签名字和属性等级不变，消耗 1 次额度，无法选回。", "pet", { id: p.id }), disabled: !room.items.review || !tags.length },
      go2("购买物品", "lab", { tab: "services" }),
      go2("查看档案", "pet", { id: p.id })
    ]
  };
}
function carePage(s, page, args = {}, now) {
  switch (page) {
    case "lab":
      return labCatalog(s, args, now);
    case "roomReceipt":
      return openingReceipt(s, speciesKey(args));
    case "rooms":
    case "roomRoster":
      return roster(s, args, now);
    case "roomNutrition":
    case "nutritionDetail":
    case "nutritionShop":
      return nutritionPage(s, page, speciesKey(args), args.tier, now);
    case "profile":
      return checkin(s, now);
    case "checkinReceipt":
      return checkinReceipt(s);
    case "pet":
      return detail(s, args, now);
    case "breed":
      return pairPage(s, args, now);
    case "breedItems":
      return breedingItems(s, args, now);
    case "litter":
      return litter(s, args, now);
    case "litterKeep":
    case "litterSale":
    case "openingLitterSale":
    case "openingLitterQuote":
      return litterSelection(s, page, args, now);
    case "shelf":
      return shelves(s, args, now);
    case "offer":
      return offerPage(s, args, now);
    case "services":
      return services(s, args, now);
    case "review":
      return review(s, args, now);
    default:
      return null;
  }
}

// output/aliyun/source-market-breed-20261121/PetShop/server/care.mjs
var MINUTE = 6e4;
var DAY = 24 * 60 * MINUTE;
var BATCH = 30 * MINUTE;
var shelfBatchEndsAt = (room) => room.openedAt + (room.shelf.number + 1) * BATCH;
var SPECIES = {
  rabbit: { name: "兔", breeds: ["domestic", "lop", "angora", "lionhead"], young: 12, growth: 18, adult: 3, old: 1, wait: 2, min: 3, litter: [25, 50, 25], roomCost: 0, review: 40, guide: 250, art: "shop-modules/rabbit-room" },
  cat: { name: "猫", breeds: ["british", "american", "persian", "maine"], young: 30, growth: 60, adult: 4, old: 2, wait: 7, min: 2, litter: [20, 55, 25], roomCost: 6e3, review: 300, guide: 350, art: "rooms/cat-room" },
  dog: { name: "狗", breeds: ["shiba", "corgi", "poodle", "dachshund"], young: 40, growth: 80, adult: 5, old: 2, wait: 10, min: 2, litter: [15, 35, 35, 15], roomCost: 6e4, review: 330, guide: 400, art: "rooms/dog-room" }
};
var BREEDS = {};
var catalog = {
  domestic: ["原色兔", "栗野 灰野 黑白花斑 橘白花斑 纯黑 雪白"],
  lop: ["垂耳兔", "奶油 蓝灰 巧克力 纯白 黑白花斑 焦糖白花斑"],
  angora: ["安哥拉兔", "雪白 奶油 蓝灰 巧克力 橘黄 黑白花斑"],
  lionhead: ["狮子兔", "金黄 黑色 灰白 巧克力 奶油 黑白花斑"],
  british: ["英国短毛猫", "蓝灰 乳白 黑白双色 金渐层 银虎斑 巧克力"],
  american: ["美国短毛猫", "银虎斑 棕虎斑 橘虎斑 黑白双色 纯白 纯黑"],
  persian: ["波斯猫", "纯白 炭黑 奶油 蓝灰 橘虎斑 海豹重点"],
  maine: ["缅因猫", "棕虎斑 银虎斑 橘白 黑烟 纯白 蓝灰白"],
  shiba: ["柴犬", "赤色 黑褐 奶油白 赤胡麻 黑胡麻 白底赤斑"],
  corgi: ["柯基犬", "黄白 赤白 貂色 黑头三色 虎斑白 蓝陨石"],
  poodle: ["贵宾犬", "黑色 白色 杏色 巧克力 银灰 黑白花"],
  dachshund: ["腊肠犬", "赤棕 黑褐 巧克力褐 银灰陨石 虎斑 红白花"]
};
var breedMaturity = {
  domestic: 5,
  lop: 15,
  angora: 30,
  lionhead: 45,
  british: 90,
  american: 105,
  persian: 120,
  maine: 150,
  shiba: 240,
  corgi: 300,
  poodle: 360,
  dachshund: 480
};
for (const [species, config] of Object.entries(SPECIES)) {
  config.breeds.forEach((key, index) => {
    BREEDS[key] = {
      species,
      name: catalog[key][0],
      coats: catalog[key][1].split(" "),
      tier: index + 1,
      maturityMinutes: breedMaturity[key]
    };
  });
}
var TRAITS = [
  [["温顺", "好奇", "亲人"], ["沉稳", "大胆"], ["从容"]],
  [["圆眼", "清秀"], ["秀眉", "眼神明亮"], ["眼神灵动"]],
  [["柔软", "顺毛"], ["细密", "绒感"], ["丝光", "绒光"]],
  [["匀称", "舒展"], ["步态轻盈", "站姿端正"], ["仪态出众"]],
  [["紧凑", "修长"], ["骨架匀整", "轮廓流畅"], ["比例匀美"]]
];
var breedingFields = ["性格", "品相", "毛发", "体态", "体型"];
var fields = [...breedingFields, "缺陷"];
var rarities = ["普通", "少见", "稀有"];
var coatWeights = [25, 25, 18, 14, 10, 8];
var dayAt = (t) => new Date(t + 8 * 60 * MINUTE).toISOString().slice(0, 10);
var checkinBreeds = ["angora", "domestic", "lop", "lionhead"];
var checkinCount = (s) => s.care.checkinCount ?? Number(s.care.signedDay != null);
var nextCheckinBreed = (s) => checkinBreeds[checkinCount(s) % checkinBreeds.length];
var selectionItemNames = Object.freeze({ single: "单项选育单", double: "双项选育单" });
var itemName = { review: "特征复评单", guide: "选育指导单", ...selectionItemNames, reshape: "缺陷重塑剂", antiAge: "抗衰老药剂" };
var serviceItemUnit = (item) => item === "reshape" || item === "antiAge" ? "份" : "张";
var serviceItemStock = (room, item) => {
  const count = room.items[item];
  return Number.isSafeInteger(count) && count >= 0 ? count : 0;
};
var highValueItemPrices = Object.freeze({
  rabbit: Object.freeze({ guide: 1800, single: 3600, double: 8e3, reshape: 2700, antiAge: 1500 }),
  cat: Object.freeze({ guide: 6e3, single: 12e3, double: 27e3, reshape: 9e3, antiAge: 5e3 }),
  dog: Object.freeze({ guide: 27e3, single: 54e3, double: 12e4, reshape: 4e4, antiAge: 22e3 })
});
var serviceItemPrice = (s, species, item) => item === "review" ? purchasePrice(s, SPECIES[species].review) : highValueItemPrices[species][item];
var selectionFieldCount = (key) => key === "single" ? 1 : key === "double" ? 2 : 0;
var antiAgeLimit = 3;
var antiAgeUses = (p) => Number.isInteger(p.antiAgeUses) ? Math.max(0, Math.min(antiAgeLimit, p.antiAgeUses)) : 0;
var reshapeLimit = 3;
var reshapeUses = (p) => Number.isInteger(p.reshapeUses) ? Math.max(0, Math.min(reshapeLimit, p.reshapeUses)) : 0;
var sample = (list, rnd = Math.random) => list[Math.floor(rnd() * list.length)];
function weighted2(weights, rnd = Math.random) {
  let value = rnd() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < weights.length; i++) if ((value -= weights[i]) < 0) return i;
  return weights.length - 1;
}
function deterministic(key) {
  let sequence = 0;
  return () => createHash2("sha256").update(key + ":" + sequence++).digest().readUInt32LE() / 4294967296;
}
function requireValue2(test, message) {
  if (!test) throw new Error(message);
}
function speciesOf(value) {
  const key = value ?? "rabbit";
  requireValue2(Object.hasOwn(SPECIES, key), "没有这个物种的房间。");
  return key;
}
function roomOf(s, species) {
  const room = s.rooms[speciesOf(species)];
  requireValue2(room, "请先开放对应房间。");
  return room;
}
var stageNames = ["幼年", "成长", "成年", "老年", "已故"];
function lifeDates(p) {
  const cfg = SPECIES[p.species];
  const speciesMaturity = cfg.young + cfg.growth;
  const maturity = p.breedGrowth === true ? BREEDS[p.breedKey]?.maturityMinutes ?? speciesMaturity : speciesMaturity;
  const naturalGrowth = p.bornAt + Math.round(maturity * cfg.young / speciesMaturity) * MINUTE;
  const naturalAdult = p.bornAt + maturity * MINUTE;
  const oldAt = naturalAdult + cfg.adult * DAY;
  const baseDeathAt = p.tutorialDeathAt ?? (p.tutorialLifeGuard ? Infinity : oldAt + cfg.old * DAY);
  const deathAt = baseDeathAt + antiAgeUses(p) * DAY;
  return {
    growthAt: p.maturation?.growthAt ?? naturalGrowth,
    adultAt: p.maturation?.adultAt ?? naturalAdult,
    oldAt: Math.min(oldAt, baseDeathAt),
    deathAt
  };
}
function accelerateMaturation(p, effect, arrivedAt) {
  if (!effect) return;
  const start = Math.max(effect.startsAt, arrivedAt, p.bornAt);
  const duration = effect.endsAt - start;
  const { growthAt, adultAt } = lifeDates(p);
  if (duration <= 0 || adultAt <= start) return;
  const speed = Math.round(effect.rate * 10);
  const earlier = (deadline) => {
    if (deadline <= start) return deadline;
    const natural = deadline - start;
    return natural * 10 <= duration * speed ? start + Math.ceil(natural * 10 / speed) : deadline - Math.floor(duration * (speed - 10) / 10);
  };
  p.maturation = { growthAt: earlier(growthAt), adultAt: earlier(adultAt) };
}
var beijingTime = (ms) => new Date(ms + 8 * 60 * MINUTE).toISOString().slice(0, 19).replace("T", " ");
function ageBand(p, now) {
  const { growthAt, adultAt, oldAt, deathAt } = lifeDates(p);
  const ends = [growthAt, adultAt, oldAt, deathAt];
  const i = ends.findIndex((end) => now < end);
  return i < 0 ? ["已故", null] : [stageNames[i], Number.isFinite(ends[i]) ? ends[i] : null];
}
var stageOf = (p, now) => ageBand(p, now)[0];
var stageEnd = (p, now) => ageBand(p, now)[1];
function isBusy(s, p) {
  const job = s.rooms[p.species]?.job;
  return Boolean(job && (p.id === job.motherId || p.id === job.fatherId));
}
var breedName = (p) => p.mixed ? "杂交" : BREEDS[p.breedKey].name;
var mixedOffspring = (mother, father) => Boolean(mother.mixed || father.mixed || mother.breedKey !== father.breedKey);
var petArt = (p) => "pets/" + p.breedKey + "-coat" + String(p.coatIndex).padStart(2, "0") + "_" + (p.sex === "公" ? "male" : "female");
var coatName = (p) => BREEDS[p.breedKey].coats[p.coatIndex - 1];
var canBreed = (s, p, now) => !p.bred && !isBusy(s, p) && ["成年", "老年"].includes(stageOf(p, now));
var stockStatus = (s, p) => isBusy(s, p) ? "繁育中" : p.bred ? "已繁育" : "未繁育";
function specimen(s, p, now, { inShop = true } = {}) {
  const [stage, endsAt] = ageBand(p, now);
  return {
    id: p.id,
    number: p.id.slice(0, 5).toUpperCase(),
    name: p.name,
    sex: p.sex,
    breed: breedName(p),
    coat: coatName(p),
    stage,
    status: stage === "已故" ? p.retained ? "种源保护" : "待回收" : stockStatus(s, p),
    art: petArt(p),
    retained: p.retained === true,
    ...inShop && { stageEndsAt: endsAt },
    ...p.guided === true && { guided: true },
    ...p.selectedBreeding === true && { selectedBreeding: true },
    ...p.traits && {
      score: cardQualityScore(p.traits),
      traits: p.traits.slice(0, 5).map(({ type, grade }) => ({ type, grade })),
      tags: getPetTags(p),
      defect: { grade: p.traits[5].grade, label: defectDisplayLabel(p.traits[5].grade) }
    }
  };
}
var rosterFilters = {
  全部: () => true,
  种源: (_s, p) => p.retained === true,
  未繁育: (s, p, now) => stageOf(p, now) !== "已故" && stockStatus(s, p) === "未繁育"
};
var legacyFilters = { 在养: "全部", 后备种源: "种源", 可配对: "未繁育" };
function rosterFilter(value) {
  if (typeof value !== "string") return "全部";
  if (Object.hasOwn(legacyFilters, value)) return legacyFilters[value];
  return Object.hasOwn(rosterFilters, value) ? value : "全部";
}
function rosterStage(value, filter) {
  if (stageNames.includes(value)) return value;
  return filter === "已故" ? "已故" : "全部";
}
function fixedTraits(first = "温顺") {
  return [first, "清秀", "柔软", "匀称", "紧凑"].map((label, i) => ({ type: fields[i], label, rarity: "普通", grade: "B" })).concat(defectTrait("B"));
}
function makePet(usedNames, species, breedKey, sex, now, source, data = {}) {
  const name = takePetName(usedNames, Math.random(), data.name);
  const generated = data.traits ? { traits: structuredClone(data.traits) } : fixedTagSubset(fixedTraits());
  const pet = {
    id: randomUUID3(),
    species,
    breedKey,
    sex,
    bornAt: now,
    source,
    coatIndex: 1,
    mixed: false,
    breedGrowth: true,
    bred: false,
    honor: 0,
    reviews: 0,
    motherId: null,
    fatherId: null,
    ...data,
    ...generated,
    name
  };
  normalizeAnimalTags(pet);
  return pet;
}
function newRoom(now) {
  return { openedAt: now, job: null, lastLitter: null, shelf: null, items: Object.fromEntries(Object.keys(itemName).map((item) => [item, 0])), mutationEnabled: true };
}
function rolledTrait(i, rarity, grade, rnd) {
  return { type: fields[i], label: sample(TRAITS[i][rarity], rnd), rarity: rarities[rarity], grade };
}
function shelfBatch(s, species, number2, usedNames, reservation) {
  const seed = s.care.seed + ":stock-v1:" + species + ":" + number2;
  const breedKey = reservation?.breedKey ?? SPECIES[species].breeds[weighted2([40, 30, 20, 10], deterministic(seed + ":breed"))];
  const offers = (reservation ? [reservation.sex] : ["公", "母"]).map((sex, slot) => {
    const rnd = (field) => deterministic(seed + ":" + slot + ":" + field);
    const rare = rnd("rare")() < 0.1 ? Math.floor(rnd("rare-slot")() * 5) : -1;
    const gradedTraits = breedingFields.map((_, i) => {
      const grade = GRADES[weighted2([0, 10, 40, 42, 8, 0, 0], rnd("grade-" + i))];
      return rolledTrait(i, i === rare ? 2 : weighted2([80, 20], rnd("rarity-" + i)), grade, rnd("tag-" + i));
    }).concat(defectTrait("B"));
    const id = createHash2("sha256").update(seed + ":" + slot + ":id").digest("hex").slice(0, 32);
    const tags = fixedTagSubset(gradedTraits, rnd("tag-capacity-v2"));
    return { id, name: takePetName(usedNames, rnd("name")()), species, sex, breedKey, mixed: false, coatIndex: 1 + weighted2(coatWeights, rnd("coat")), ...tags };
  });
  return { number: number2, offers };
}
function makeReservationOffer(s, species, day3, breedKey, sex) {
  return shelfBatch(s, species, "reservation-" + day3, occupiedPetNames(s), { breedKey, sex }).offers[0];
}
function admitPurchasedPet(s, room, offer, now) {
  const pet = makePet(occupiedPetNames(s, [offer]), offer.species, offer.breedKey, offer.sex, now, "研究所采购", offer);
  accelerateMaturation(pet, activeNutrition(room, now), now);
  s.pets.push(pet);
  return pet;
}
function initCare(s, now, { onboarding = false } = {}) {
  if (s.care) return;
  s.care = { seed: randomBytes(16).toString("hex"), signedDay: null, claimIds: [], defectGradesUpdated: true };
  s.rooms = { rabbit: newRoom(now) };
  const usedNames = /* @__PURE__ */ new Set();
  s.pets = onboarding ? [] : [
    makePet(usedNames, "rabbit", "angora", "母", now - 30 * MINUTE, "开店种兔", { name: "小花" }),
    makePet(usedNames, "rabbit", "angora", "公", now - 30 * MINUTE, "开店种兔", { name: "小白", coatIndex: 2, ...fixedTagSubset(fixedTraits("好奇")) })
  ];
  tickCare(s, now);
}
function clearBredRetention(s) {
  let changed = false;
  for (const pet of s.pets) {
    if (pet.bred && pet.retained) {
      pet.retained = false;
      changed = true;
    }
  }
  return changed;
}
function birthIdentity({ id, name, sex, breedKey, coatIndex, mixed, traits }) {
  const score = cardQualityScore(traits);
  return { id, name, sex, breedKey, coatIndex, mixed: !!mixed, ...score !== void 0 && { score } };
}
function tickCare(s, now) {
  let changed = false;
  if (!s.care.defectGradesUpdated) {
    const updateLabel = (pet) => {
      if (pet) pet.traits[5] = defectTrait(pet.traits[5].grade);
    };
    s.pets.forEach(updateLabel);
    for (const room of Object.values(s.rooms)) {
      room.shelf?.offers.forEach(updateLabel);
      if (room.job) {
        updateLabel(room.job.mother);
        updateLabel(room.job.father);
        room.job.offspring.forEach(updateLabel);
      }
    }
    s.care.defectGradesUpdated = true;
    changed = true;
  }
  const refreshes = [];
  for (const [species, room] of Object.entries(s.rooms)) {
    if (room.reservedSeed && now >= room.reservedSeed.expiresAt) {
      delete room.reservedSeed;
      changed = true;
    }
    const number2 = Math.max(0, Math.floor((now - room.openedAt) / BATCH));
    if (!room.shelf || number2 > room.shelf.number) refreshes.push({ species, room, number: number2 });
    const job = room.job;
    if (job && now >= job.endsAt) {
      for (const p of s.pets) if (p.id === job.motherId || p.id === job.fatherId) {
        p.bred = true;
        p.retained = false;
      }
      const effect = nutritionWindow(room);
      for (const p of job.offspring) accelerateMaturation(p, effect, job.endsAt);
      s.pets.push(...job.offspring);
      room.lastLitter = {
        ids: job.offspring.map((p) => p.id),
        children: job.offspring.map(birthIdentity),
        bornAt: job.endsAt,
        mother: job.mother.name,
        father: job.father.name,
        parents: [job.mother, job.father].map(({ id, name, sex, bornAt, breedKey, breedGrowth, maturation }) => ({ id, name, sex, bornAt, species, breedKey, ...breedGrowth && { breedGrowth }, ...maturation && { maturation } }))
      };
      room.job = null;
      changed = true;
    } else if (room.lastLitter && !room.lastLitter.children) {
      const ids = new Set(room.lastLitter.ids);
      room.lastLitter.children = s.pets.filter((p) => ids.has(p.id)).map(birthIdentity);
      changed = true;
    }
  }
  if (refreshes.length) {
    const retiring = refreshes.flatMap(({ room }) => room.shelf?.offers ?? []);
    const usedNames = occupiedPetNames(s, retiring);
    for (const { species, room, number: number2 } of refreshes) room.shelf = shelfBatch(s, species, number2, usedNames);
    changed = true;
  }
  return changed;
}
function gradeBaseline(grades2, guided) {
  return guided && grades2[0] !== grades2[1] ? { first: grades2[0] > grades2[1] ? 0 : 1, chance: 0.8 } : { first: 0, chance: 0.5 };
}
function guideField(s, mother, father) {
  return weighted2([20, 20, 20, 20, 20], deterministic(s.care.seed + ":guide:" + mother.id + ":" + father.id));
}
function validSelection(room, selection) {
  if (!selection || typeof selection !== "object") return false;
  const { item, fields: chosen } = selection, count = selectionFieldCount(item);
  return count > 0 && serviceItemStock(room, item) > 0 && Array.isArray(chosen) && chosen.length === count && new Set(chosen).size === count && chosen.every((i) => Number.isInteger(i) && i >= 0 && i < breedingFields.length);
}
function mutationPreview(mother, father, guide, level, enabled) {
  const defect = defectProbabilities(mother.traits, father.traits);
  return { enabled, level, defect, fields: breedingFields.map((name, i) => {
    const m = mother.traits[i].grade, f = father.traits[i].grade;
    const grades2 = [GRADES.indexOf(m), GRADES.indexOf(f)];
    const { first, chance } = gradeBaseline(grades2, i === guide);
    const a = grades2[first], b = grades2[1 - first];
    const rise = (lv) => Number((100 * (chance * scoreRiseChance(a, b, lv) + (1 - chance) * scoreRiseChance(b, a, lv))).toFixed(3));
    return { name, mother: m, father: f, off: rise(0), on: rise(level) };
  }) };
}
function inherit(mother, father, options2, defect, guaranteed) {
  const traits = breedingFields.map((_, i) => {
    const parents = [mother.traits[i], father.traits[i]];
    const grades2 = parents.map((t) => GRADES.indexOf(t.grade));
    if (guaranteed?.includes(i)) return { type: fields[i], grade: GRADES[Math.max(...grades2)] };
    const { first, chance } = gradeBaseline(grades2, i === options2.guide);
    const j = Math.random() < chance ? first : 1 - first;
    const base = grades2[j], ref = grades2[1 - j];
    const up = scoreRiseChance(base, ref, options2.positive);
    const roll = Math.random(), next = base + (roll < up ? 1 : roll < up + 0.1 ? -1 : 0);
    const grade = GRADES[Math.max(0, Math.min(6, Math.max(...grades2) + 1, next))];
    return { type: fields[i], grade };
  });
  traits.push(defectTrait(GRADES[weighted2(defect.gradePercents)]));
  const rare = rareRedrawPercent(options2.rare);
  return taggedTraits(traits, (i) => inheritedTag(
    i,
    mother,
    father,
    (dimension) => rolledTrait(dimension, weighted2([80 - rare, 20, rare]), traits[dimension].grade, Math.random)
  ));
}
function startLitter(s, args, now, { waitMs, plannedSexes } = {}) {
  const species = speciesOf(args.species), room = roomOf(s, species), cfg = SPECIES[species];
  requireValue2(!room.job, "这间房已有一窝正在培育。");
  const mother = s.pets.find((p) => p.id === args.mother), father = s.pets.find((p) => p.id === args.father);
  requireValue2(mother?.species === species && father?.species === species && mother.sex === "母" && father.sex === "公" && canBreed(s, mother, now) && canBreed(s, father, now), "请选择仍在店、可繁育的一公一母成年或老年动物。");
  requireValue2(args.guide === void 0 || args.guide === -1, "指导单已改为系统抽取，请重新打开繁育台。");
  requireValue2(args.useGuide === void 0 || typeof args.useGuide === "boolean", "请选择是否添加选育指导单。");
  const useGuide = args.useGuide === true, selection = args.selection ?? null;
  requireValue2(!useGuide || room.items.guide > 0, "该物种的选育指导单不足。");
  requireValue2(!selection || validSelection(room, selection), "选育单不足或所选属性无效，请重新添加道具。");
  requireValue2(!plannedSexes || !useGuide && !selection, "教学繁育不使用选育道具。");
  const guide = useGuide ? guideField(s, mother, father) : -1;
  const [rare = 0, mutation = 0] = s.research?.[species] ?? [];
  const options2 = { rare, positive: room.mutationEnabled ? mutation : 0, guide };
  const endsAt = now + (waitMs ?? cfg.wait * MINUTE), n = plannedSexes?.length ?? cfg.min + weighted2(cfg.litter);
  const beneficiary = selection ? Math.floor(Math.random() * n) : -1;
  const mixed = mixedOffspring(mother, father);
  const defect = defectProbabilities(mother.traits, father.traits);
  const usedNames = occupiedPetNames(s);
  const lineage = { motherId: mother.id, fatherId: father.id, motherName: mother.name, fatherName: father.name, mixed };
  const offspring = Array.from({ length: n }, (_, i) => {
    if (plannedSexes) return makePet(usedNames, species, mother.breedKey, plannedSexes[i], endsAt, "本店繁育", lineage);
    const look = Math.random() < 0.5 ? mother : father;
    const guaranteed = i === beneficiary ? selection.fields : void 0;
    return makePet(usedNames, species, look.breedKey, Math.random() < 0.5 ? "公" : "母", endsAt, "本店繁育", {
      ...lineage,
      ...useGuide && { guided: true },
      ...guaranteed && { selectedBreeding: true },
      coatIndex: Math.random() < 0.85 ? look.coatIndex : weighted2(coatWeights) + 1,
      ...inherit(mother, father, options2, defect, guaranteed)
    });
  });
  if (guide >= 0) room.items.guide--;
  if (selection) room.items[selection.item]--;
  room.job = {
    motherId: mother.id,
    fatherId: father.id,
    mother: structuredClone(mother),
    father: structuredClone(father),
    options: { ...options2, ...selection && { selection, beneficiary: offspring[beneficiary].id } },
    endsAt,
    offspring
  };
  return waitMs ? "已开始首窝繁育，预计 " + waitMs / 1e3 + " 秒后出生。" : "已开始繁育，预计 " + cfg.wait + " 分钟后出生。";
}
function charge(s, expected, base) {
  chargeQuoted(s, expected, purchasePrice(s, base));
}
function chargeQuoted(s, expected, amount) {
  requireValue2(expected === amount, "报价有变化，请返回重新核对。");
  requireValue2(s.coins >= amount, "金币不足。需要 " + amount + " 金币。");
  s.coins -= amount;
}
function litterCandidates(s, litter2, now) {
  const ids = new Set(litter2.ids);
  return s.pets.filter((p) => ids.has(p.id) && !p.bred && !isBusy(s, p) && stageOf(p, now) !== "已故");
}
function retainedLitterPets(s, decision, soldIds, now) {
  const g = s.onboarding;
  requireValue2(decision.opening === true, "请从动物房间重新挑选留种。");
  requireValue2(decision.species === "rabbit" && g?.firstLitter && !g.planAt && !g.finishedAt, "首窝留种已处理。");
  const litter2 = g.firstLitter;
  requireValue2(litter2.bornAt === decision.bornAt, "出生记录已更新，请重新挑选。");
  const members = litterCandidates(s, litter2, now), eligible2 = members.filter((p) => !p.retained);
  requireValue2(Array.isArray(decision.keepIds) && Array.isArray(soldIds), "本窝选单无效。");
  const all = [...decision.keepIds, ...soldIds], chosen = new Set(all), keep = new Set(decision.keepIds);
  const retained = members.filter((p) => p.retained || keep.has(p.id));
  requireValue2(soldIds.length === 1 && chosen.size === all.length && all.every((id) => eligible2.some((p) => p.id === id)) && retained.length === 2 && retained[0].sex !== retained[1].sex, "请选择一公一母留种和一只出售。");
  return eligible2.filter((p) => keep.has(p.id));
}
function careAction(s, type, args, now) {
  if (!type.startsWith("care.")) return void 0;
  if (type === "care.retain") {
    const p = s.pets.find((p2) => p2.id === args.id);
    requireValue2(p, "这只动物已离店。");
    requireValue2(typeof args.retained === "boolean", "请选择留种或取消留种。");
    requireValue2(!args.retained || !p.bred, "已繁育动物无法留种。");
    requireValue2(!args.retained || stageOf(p, now) !== "已故", "已故动物无法新留种。");
    p.retained = args.retained;
    return p.name + (p.retained ? "已标记为种源。" : "已取消留种。");
  }
  if (type === "care.keepLitter") {
    const litter2 = s.rooms[args.species]?.lastLitter;
    requireValue2(litter2 && litter2.bornAt === args.bornAt, "出生记录已更新，请重新挑选。");
    const ids = args.ids ?? args.keepIds;
    requireValue2(Array.isArray(ids) && ids.length > 0 && new Set(ids).size === ids.length, "请勾选要留作种源的动物。");
    const kept = litterCandidates(s, litter2, now).filter((p) => !p.retained && ids.includes(p.id));
    requireValue2(kept.length === ids.length, "本窝名册已变化，请重新挑选。");
    for (const p of kept) p.retained = true;
    return "本窝 " + kept.length + " 只动物已标记为种源。";
  }
  if (type === "care.checkin") {
    const today = dayAt(now);
    requireValue2(s.care.signedDay !== today, "今天的两只幼兔已领取。");
    const usedNames = occupiedPetNames(s);
    const firstNames = s.care.signedDay == null ? ["谷穗", "小麦"] : [];
    const breedKey = nextCheckinBreed(s);
    const pair2 = ["母", "公"].map((sex, i) => makePet(usedNames, "rabbit", breedKey, sex, now, "每日签到", { name: firstNames[i] }));
    const effect = activeNutrition(s.rooms.rabbit, now);
    for (const p of pair2) accelerateMaturation(p, effect, now);
    s.pets.push(...pair2);
    s.care.checkinCount = checkinCount(s) + 1;
    s.care.signedDay = today;
    s.care.claimIds = pair2.map((p) => p.id);
    s.care.claimAnimals = pair2.map(birthIdentity);
    return "已领取两只" + BREEDS[breedKey].name + "幼体，一公一母。";
  }
  if (type === "care.breed") return startLitter(s, args, now);
  const species = speciesOf(args.species), cfg = SPECIES[species];
  if (type === "care.unlock") {
    requireValue2(!s.rooms[species] && cfg.roomCost > 0, "这间房已经开放。");
    charge(s, args.price, cfg.roomCost);
    const usedNames = occupiedPetNames(s);
    s.rooms[species] = newRoom(now);
    s.rooms[species].shelf = shelfBatch(s, species, 0, usedNames);
    const pair2 = ["公", "母"].map((sex) => makePet(usedNames, species, cfg.breeds[0], sex, now, "新房种源"));
    s.pets.push(...pair2);
    s.rooms[species].openingReceipt = {
      paid: args.price,
      balance: s.coins,
      bornAt: now,
      adultAt: lifeDates(pair2[0]).adultAt,
      pair: pair2.map(({ id, name, sex, breedKey, coatIndex }) => ({ id, name, sex, breedKey, coatIndex }))
    };
    return cfg.name + "房已开放，两只幼体已入住。";
  }
  const room = roomOf(s, species);
  if (type === "care.buyNutrition") {
    const meal = nutritionTier(args.tier);
    requireValue2(meal, "请选择有效的营养餐档次。");
    const count = nutritionStock(room, meal.key);
    requireValue2(count < Number.MAX_SAFE_INTEGER, "本房所选营养餐库存已满。");
    chargeQuoted(s, args.price, nutritionPrice(species, meal));
    room.nutritionStock ??= {};
    room.nutritionStock[meal.key] = count + 1;
    return "已购入 1 份" + meal.label + cfg.name.repeat(2) + "营养餐。";
  }
  if (type === "care.feed") {
    const meal = nutritionTier(args.tier);
    requireValue2(meal, "请选择有效的营养餐档次。");
    requireValue2(!activeNutrition(room, now), "本房的营养餐仍在生效，请等到期后再投喂。");
    requireValue2(nutritionStock(room, meal.key) > 0, "本房所选营养餐库存不足。");
    room.nutritionStock[meal.key]--;
    room.nutrition = { tier: meal.key, startsAt: now, endsAt: now + nutritionDuration };
    const effect = activeNutrition(room, now);
    for (const p of s.pets) if (p.species === species) accelerateMaturation(p, effect, now);
    return cfg.name + "房成长速度 ×" + meal.rate + "，营养餐已生效。";
  }
  if (type === "care.buyPet") {
    const index = room.shelf.offers.findIndex((p) => p?.id === args.id);
    requireValue2(index >= 0 && room.shelf.number === args.batch, "货位已售空或批次已更新。");
    const offer = room.shelf.offers[index];
    charge(s, args.price, youngPurchaseBase(offer));
    const pet = admitPurchasedPet(s, room, offer, now);
    room.shelf.offers[index] = null;
    if (pet.name !== offer.name) return "原货架名“" + offer.name + "”已被占用，已取名“" + pet.name + "”入住" + cfg.name + "房。";
    return pet.name + "已入住" + cfg.name + "房。";
  }
  if (type === "care.buyItem") {
    requireValue2(Object.hasOwn(itemName, args.item), "没有这种物品。");
    const count = serviceItemStock(room, args.item);
    requireValue2(count < Number.MAX_SAFE_INTEGER, "本房道具库存已满。");
    chargeQuoted(s, args.price, serviceItemPrice(s, species, args.item));
    room.items[args.item] = count + 1;
    return "已购入 1 " + serviceItemUnit(args.item) + cfg.name + "用" + itemName[args.item] + "。";
  }
  if (type === "care.antiAge") {
    const p = s.pets.find((p2) => p2.id === args.id);
    requireValue2(p?.species === species && stageOf(p, now) !== "已故", "请选择仍在店的活体动物。");
    const used = antiAgeUses(p);
    requireValue2(used < antiAgeLimit, "这只动物已用满 3 份抗衰老药剂。");
    requireValue2(serviceItemStock(room, "antiAge") > 0, "本房抗衰老药剂库存不足。");
    p.antiAgeUses = used + 1;
    room.items.antiAge--;
    return p.name + "的老年期增加 1 天，还可用 " + (antiAgeLimit - p.antiAgeUses) + " 次。";
  }
  if (type === "care.reshape") {
    const p = s.pets.find((p2) => p2.id === args.id);
    requireValue2(p?.species === species && ["幼年", "成长"].includes(stageOf(p, now)), "只能给尚未成年的在店动物使用。");
    const used = reshapeUses(p), grade = p.traits[5].grade, index = GRADES.indexOf(grade);
    requireValue2(used < reshapeLimit, "这只动物已用满 3 份缺陷重塑剂。");
    requireValue2(index >= 0, "当前缺陷档位无效，请重新打开动物档案。");
    requireValue2(serviceItemStock(room, "reshape") > 0, "本房缺陷重塑剂库存不足。");
    const step = Math.random() < 0.55 ? 1 : -1;
    const result = GRADES[index + step] ?? grade;
    p.traits[5] = defectTrait(result);
    p.reshapeUses = used + 1;
    room.items.reshape--;
    return "缺陷重塑：" + grade + " → " + result + (result === grade ? "（达到边界，保持原档）" : "") + "。已使用 1 份，还可用 " + (reshapeLimit - p.reshapeUses) + " 次。";
  }
  if (type === "care.toggle") {
    requireValue2(typeof args.enabled === "boolean", "请选择开启或关闭。");
    room.mutationEnabled = args.enabled;
    return "下次开始繁育时" + (args.enabled ? "采用" : "关闭") + "五维选育加成。";
  }
  if (type === "care.review") {
    const p = s.pets.find((p2) => p2.id === args.id);
    requireValue2(p?.species === species && stageOf(p, now) !== "已故" && !isBusy(s, p), "请选择在店空闲的活体。");
    requireValue2(args.field === void 0, "复评规则已更新，请重新打开复评页面。现在由系统随机选择已有标签。");
    requireValue2(p.reviews < 3 && room.items.review > 0, "复评次数或复评单不足。");
    const tags = getPetTags(p);
    requireValue2(tags.length > 0, "这只动物没有可复评的特征标签。");
    const tag = sample(tags), i = tag.dimension, old = p.traits[i];
    const rarity = reviewedRarity(old.rarity);
    p.traits[i] = { ...old, tagId: tag.tagId, rarity };
    (p.reviewHistory ??= []).push({
      at: now,
      field: i,
      before: old.label,
      after: p.traits[i].label,
      beforeRarity: old.rarity,
      afterRarity: p.traits[i].rarity,
      grade: old.grade,
      tagId: tag.tagId,
      ruleVersion: 2
    });
    p.reviews++;
    room.items.review--;
    return "标签「" + old.label + "」复评：" + old.rarity + " → " + rarity + "，标签名称和属性等级不变。";
  }
  return void 0;
}

// output/aliyun/source-market-breed-20261121/PetShop/server/show.mjs
import { createHash as createHash3, createHmac } from "node:crypto";
import { Buffer } from "node:buffer";

// output/aliyun/source-market-breed-20261121/PetShop/server/show-events.json
var show_events_default = [
  { id: "P01", name: "暖阳陪伴赛", targets: ["B", "B", "B", "B", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P02", name: "春日轻盈赛", targets: ["B", "B", "C", "A", "C", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P03", name: "绒毛小憩赛", targets: ["C", "B", "A", "B", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P04", name: "庭院漫步赛", targets: ["A", "C", "B", "A", "B", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P05", name: "小巧玲珑赛", targets: ["B", "A", "B", "C", "C", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P06", name: "清秀初见赛", targets: ["C", "A", "B", "B", "A", "B"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P07", name: "安静午后赛", targets: ["C", "C", "B", "C", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P08", name: "舒展时光赛", targets: ["B", "B", "C", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P09", name: "亲近晨光赛", targets: ["A", "B", "C", "B", "A", "C"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P10", name: "柔绒邀约赛", targets: ["B", "C", "A", "A", "B", "C"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P11", name: "匀美身姿赛", targets: ["C", "A", "C", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P12", name: "朴素风采赛", targets: ["C", "C", "C", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P13", name: "温雅仪态赛", targets: ["A", "A", "B", "S", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P14", name: "月下绒光赛", targets: ["B", "A", "S", "C", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P15", name: "明眸相逢赛", targets: ["A", "S", "C", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P16", name: "流畅轮廓赛", targets: ["C", "B", "A", "B", "S", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P17", name: "从容迎宾赛", targets: ["S", "B", "B", "A", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P18", name: "健朗日常赛", targets: ["B", "C", "A", "C", "B", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P19", name: "均衡新星赛", targets: ["A", "A", "A", "A", "A", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P20", name: "反差风采赛", targets: ["C", "S", "C", "S", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P21", name: "圆融雅集赛", targets: ["S", "C", "A", "B", "S", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P22", name: "绒感典藏赛", targets: ["A", "B", "S", "C", "S", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P23", name: "晨星仪态赛", targets: ["B", "S", "A", "S", "C", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P24", name: "端正风华赛", targets: ["S", "A", "C", "A", "S", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P25", name: "一眼惊鸿赛", targets: ["B", "S+", "A", "B", "C", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P26", name: "丝绒之冠赛", targets: ["C", "B", "S+", "A", "B", "A"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P27", name: "比例之美赛", targets: ["A", "C", "B", "A", "S+", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "P28", name: "从容压轴赛", targets: ["S+", "A", "C", "S", "B", "S"], weights: [1, 1, 1, 1, 1, 1] },
  { id: "O01", name: "四季相伴公开赛", targets: ["B", "A", "B", "A", "B", "A"], weights: [20, 20, 15, 15, 10, 20] },
  { id: "O02", name: "春风轻步公开赛", targets: ["C", "B", "A", "S", "C", "A"], weights: [10, 15, 15, 30, 15, 15] },
  { id: "O03", name: "晴窗明眸公开赛", targets: ["A", "S", "C", "B", "A", "B"], weights: [15, 30, 10, 15, 10, 20] },
  { id: "O04", name: "月色柔绒公开赛", targets: ["B", "A", "S", "C", "B", "S"], weights: [10, 15, 30, 10, 15, 20] },
  { id: "O05", name: "庭院轮廓公开赛", targets: ["C", "B", "A", "A", "S", "A"], weights: [10, 15, 15, 20, 25, 15] },
  { id: "O06", name: "从容相逢公开赛", targets: ["S", "C", "B", "A", "A", "S"], weights: [30, 10, 10, 15, 15, 20] },
  { id: "O07", name: "清简风采公开赛", targets: ["C", "C", "A", "B", "C", "A"], weights: [15, 20, 20, 15, 10, 20] },
  { id: "O08", name: "双星仪态公开赛", targets: ["B", "S", "C", "S", "A", "S"], weights: [10, 25, 10, 25, 10, 20] },
  { id: "O09", name: "绒光映月公开赛", targets: ["A", "B", "S+", "C", "S", "A"], weights: [15, 10, 30, 10, 20, 15] },
  { id: "O10", name: "均衡雅集公开赛", targets: ["A", "A", "A", "A", "A", "A"], weights: [20, 15, 20, 15, 10, 20] },
  { id: "O11", name: "风华典藏公开赛", targets: ["S", "C", "A", "S+", "B", "S"], weights: [20, 10, 15, 25, 10, 20] },
  { id: "O12", name: "星辉轮廓公开赛", targets: ["C", "S", "B", "A", "S+", "S"], weights: [10, 20, 10, 20, 25, 15] }
];

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-feature-levels.json
var shop_feature_levels_default = {
  featureLevels: {
    rooms: 1,
    login: 1,
    orders: 2,
    show: 4,
    lab: 2,
    market: 1,
    profile: 1,
    breed: 1,
    decor: 8,
    guest: 3,
    collection: 4
  },
  maxLevel: 60,
  levelUpCosts: [10, 10, 10, 30, 40, 50, 70],
  laterCostPerLevel: 10,
  raceOpensDay: { private: 2, public: 3 },
  saleXp: { base: 10, coinsPerBonus: 200, maxBonus: 20 }
};

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-features.mjs
var featureNames = {
  rooms: "动物小屋",
  login: "店主登记簿",
  orders: "普通订单",
  show: "赛事",
  lab: "培育中心",
  market: "自由市场",
  profile: "每日签到",
  breed: "繁育",
  decor: "店铺装饰",
  guest: "特殊来客",
  collection: "荣誉"
};
function featureAccess(rules, level) {
  return Object.fromEntries(Object.keys(featureNames).map((key) => {
    const requiredLevel = rules.featureLevels[key];
    return [key, { name: featureNames[key], requiredLevel, unlocked: level >= requiredLevel }];
  }));
}
var owner = /* @__PURE__ */ new Map();
var sections = {
  rooms: ["roomRoster", "roomReceipt", "roomNutrition", "nutritionDetail", "pet", "care.unlock", "care.retain", "care.feed", "care.antiAge", "care.reshape", "onboarding.openRoom", "onboarding.feed"],
  login: ["payment"],
  orders: ["orderDesk", "credits", "order.cancel", "order.buyCredit"],
  lab: [
    "shelf",
    "offer",
    "services",
    "review",
    "recycle",
    "research",
    "researchNode",
    "researchTable",
    "nutritionShop",
    "care.buyPet",
    "onboarding.buy",
    "care.buyItem",
    "care.buyNutrition",
    "care.review",
    "research.upgrade",
    "seedReservation",
    "breedingCourses",
    "seed.reserve",
    "seed.cancel",
    "seed.claim",
    "course.start",
    "course.cancel",
    "course.complete"
  ],
  profile: ["checkinReceipt", "care.checkin"],
  breed: ["litter", "litterKeep", "litterSale", "openingLitterSale", "openingLitterQuote", "breedItems", "care.breed", "care.toggle", "care.keepLitter"],
  decor: ["decor.buy", "decor.place"],
  guest: ["guest.dismiss"]
};
for (const [feature, keys] of Object.entries(sections)) {
  for (const key of keys) owner.set(key, feature);
}
var saleFeatures = /* @__PURE__ */ new Map([["market", "market"], ["order", "orders"], ["guest", "guest"], ["recycle", "lab"]]);
function operationFeature(key, args) {
  if (key === "sale" || key === "saleQuote" || key === "sale.commit") return saleFeatures.get(args.channel);
  if (Object.hasOwn(featureNames, key)) return key;
  if (key.startsWith("show.")) return "show";
  if (key.startsWith("collection.")) return "collection";
  return owner.get(key);
}

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-progression.mjs
function shopProgress(rules, totalXp) {
  let level = 1, intoLevel = totalXp;
  while (level < rules.maxLevel) {
    const cost2 = rules.levelUpCosts[level - 1] ?? rules.laterCostPerLevel * level;
    if (intoLevel < cost2) return { level, total: totalXp, intoLevel, toNext: cost2, maxLevel: rules.maxLevel };
    intoLevel -= cost2;
    level++;
  }
  return { level, total: totalXp, intoLevel, toNext: 0, maxLevel: rules.maxLevel };
}
function saleExperience(rules, channel, lines) {
  if (!["market", "order", "guest"].includes(channel)) return 0;
  const { base, coinsPerBonus, maxBonus } = rules.saleXp;
  return lines.reduce((sum, line) => sum + base + Math.min(maxBonus, Math.floor(line.amount / coinsPerBonus)), 0);
}
function shopRaceAccess(rules, createdAt, now) {
  const day3 = 864e5, beijingOffset = 8 * 36e5;
  const openingMidnight = Math.floor((createdAt + beijingOffset) / day3) * day3 - beijingOffset;
  const shopDay = Math.max(1, 1 + Math.floor((now - openingMidnight) / day3));
  const raceAccess = Object.fromEntries(Object.entries(rules.raceOpensDay).map(([mode, opensDay]) => {
    const opensAt = Math.max(createdAt, openingMidnight + (opensDay - 1) * day3);
    return [mode, { opensDay, opensAt, unlocked: now >= opensAt }];
  }));
  return { shopDay, raceAccess };
}

// output/aliyun/source-market-breed-20261121/PetShop/server/show.mjs
var GAME_EPOCH = Date.parse("2026-11-09T20:00:00+08:00");
var HOUR = 36e5;
var DAY2 = 24 * HOUR;
var WEEK = 7 * DAY2;
var grades = ["E", "D", "C", "B", "A", "S", "S+"];
var dimensions = ["性格", "品相", "毛发", "体态", "体型", "缺陷"];
var animals = { rabbit: "兔", cat: "猫", dog: "狗" };
var speciesPortrait = { rabbit: "pets/angora-coat01_female", cat: "pets/british-coat01_female", dog: "pets/shiba-coat01_male" };
var trophies = { bronze: "铜杯", silver: "银杯", gold: "金杯", memorial: "纪念杯", laurel: "桂冠杯" };
var tiers = { private: ["gold", "silver", "bronze"], public: ["laurel", "gold", "silver", "bronze", "memorial"] };
var points = { private: { bronze: 20, silver: 60, gold: 100 }, public: { memorial: 50, bronze: 100, silver: 200, gold: 400, laurel: 600 } };
var honors = { private: { bronze: 0, silver: 0.4, gold: 0.8 }, public: { memorial: 0, bronze: 0.2, silver: 0.4, gold: 0.6, laurel: 0.8 } };
var dateFormat = new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
var time = (value) => dateFormat.format(value);
var lookup = (records, key) => Object.hasOwn(records, key) ? records[key] : null;
var gradeList = (values) => values.map((g) => grades[g]).join(" / ");
var topicArt = "shop-modules/stage";
var PNAME = { private: "私人赛", public: "本地模拟公开赛" };
var themes = show_events_default.map(({ id, name, targets, weights }) => ({
  id,
  name,
  mode: id[0] === "P" ? "private" : "public",
  targets: targets.map((x) => grades.indexOf(x)),
  weights
}));
var groups = { private: themes.filter((t) => t.mode === "private"), public: themes.filter((t) => t.mode === "public") };
var byTheme = Object.fromEntries(themes.map((t) => [t.id, t]));
function initShow(s, now) {
  s.show ??= { epoch: s.gameEpoch ?? GAME_EPOCH, activePrivate: null, weeks: {}, entries: {}, cups: {} };
  ensureCalendar(s, now);
  s.ratingBps ??= 0;
}
function ensureCalendar(s, now) {
  if (s.show.calendar) return;
  const openedAt = Number.isFinite(s.createdAt) ? s.createdAt : null;
  let first = openedAt === null ? null : Math.max(0, Math.ceil((openedAt - s.show.epoch - 5 * DAY2) / WEEK));
  if (openedAt === null) for (const w of Object.values(s.show.weeks)) {
    if (Number.isSafeInteger(w.index) && w.index >= 0) first = first === null ? w.index : Math.min(first, w.index);
  }
  first ??= Math.max(0, Math.floor(((now ?? s.show.epoch) - s.show.epoch) / WEEK));
  s.show.calendar = { version: 1, firstWeek: first, themes: structuredClone(groups.public) };
}
function roundStart(s, mode, index) {
  return s.show.epoch + index * (mode === "public" ? WEEK : DAY2);
}
function period(s, mode, now) {
  const index = Math.floor((now - s.show.epoch) / (mode === "public" ? WEEK : DAY2));
  if (index < 0) return null;
  const start = roundStart(s, mode, index);
  return { id: mode + "-" + index, index, start, close: start + (mode === "public" ? 94 : 22) * HOUR, result: start + (mode === "public" ? 5 * DAY2 : DAY2), payout: mode === "public" ? start + 6 * DAY2 : null };
}
function digest(key, ...fields2) {
  return createHmac("sha256", key).update(JSON.stringify(fields2), "utf8").digest();
}
function offset(key, profile, event, species, bot, dim) {
  for (let counter = 0; ; counter++) {
    const value = digest(key, 1, "bot_score_v1", profile, event, species, bot, dim, counter).readUInt32BE();
    if (value >= 4294967200) continue;
    const n = value % 100;
    return n < 5 ? -3 : n < 15 ? -2 : n < 35 ? -1 : n < 65 ? 0 : n < 85 ? 1 : n < 95 ? 2 : 3;
  }
}
function publicTheme(s, index) {
  const cycle = s.show.calendar.themes;
  return cycle[index % cycle.length];
}
function makeWeek(s, round, kinds = Object.keys(animals)) {
  const theme = structuredClone(publicTheme(s, round.index)), key = Buffer.from(s.rootSeed, "hex");
  const bots = {};
  for (const kind of kinds) {
    bots[kind] = Array.from({ length: 99 }, (_, i) => theme.targets.map((target, dim) => Math.max(0, Math.min(6, target + offset(key, s.profileId, round.id, kind, i + 1, dim)))));
  }
  const seed = digest(key, 1, "tie_seed_v1", s.profileId, round.id, "", "", "", 0);
  return { ...round, theme, bots, version: 1, seed: seed.toString("hex"), commit: createHash3("sha256").update(seed).digest("hex") };
}
function syncRounds(s, now) {
  const daily2 = period(s, "private", now);
  if (daily2 && s.show.activePrivate?.id !== daily2.id) {
    const choices = [0, 9, 18].map((shift) => structuredClone(groups.private[(daily2.index + shift) % 28]));
    s.show.activePrivate = { ...daily2, choices };
  }
  const week = period(s, "public", now);
  if (week && !s.show.weeks[week.id]) s.show.weeks[week.id] = makeWeek(s, week);
}
function matchScores(scores, theme) {
  const dims = theme.targets.map((target, i) => [100, 70, 30, 0][Math.min(3, Math.abs(scores[i] - target))]);
  const total = theme.weights.reduce((n, w, i) => n + w * dims[i], 0);
  const divisor = theme.weights.reduce((sum, w) => sum + w, 0);
  const order = [0, 1, 2, 3, 4, 5].sort((a, b) => theme.weights[b] - theme.weights[a] || a - b);
  const key = [total, Math.min(...dims), dims.filter((x) => x === 100).length, ...order.map((i) => dims[i])];
  return { dims, total, divisor, key };
}
var displayScore = (m) => String(Number((m.total / m.divisor).toFixed(2)));
var qualifies = (m) => m.total >= 68 * m.divisor;
function compareKeys(a, b) {
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return b[i] - a[i];
  return 0;
}
function publicTier(position, count) {
  if (position < 1 || position > count) return null;
  const cutoff = [5, 20, 50, 80, 100].findIndex((p) => position <= Math.floor(p * count / 100));
  return tiers.public[cutoff];
}
function rankCash(position, tied, nq) {
  if (nq < 2) return 0;
  const top = Math.max(3, Math.ceil(nq / 10)), next = Math.max(10, Math.ceil(3 * nq / 10));
  let sum = 0;
  for (let p = position; p < position + tied; p++) sum += p === 1 ? 540 : p <= top ? 270 : p <= next ? 120 : 0;
  return Math.floor(sum * Math.min(9, nq - 1) / (9 * tied));
}
function privateTier(match) {
  const { total: n, divisor: d } = match;
  return n >= 95 * d ? "gold" : n >= 82 * d ? "silver" : n >= 68 * d ? "bronze" : null;
}
function drawToken(seed, input) {
  return createHmac("sha256", Buffer.from(seed, "hex")).update(input, "utf8").digest("hex");
}
function board(s, week, species) {
  const entries = week.bots[species].map((scores, i) => {
    const ordinal = String(i + 1).padStart(2, "0");
    return { accountId: "bot-" + species + "-" + ordinal, name: "模拟" + animals[species] + ordinal, scores };
  });
  const reg = s.show.entries[week.id];
  if (reg && !reg.voided && reg.pet.species === species) {
    entries.push({ accountId: s.profileId, name: reg.pet.name, scores: reg.pet.scores, player: true });
  }
  for (const e of entries) {
    e.match = matchScores(e.scores, week.theme);
    e.draw = drawToken(week.seed, week.id + "|" + e.accountId);
  }
  entries.sort((a, b) => {
    const sort = compareKeys(a.match.key, b.match.key);
    if (sort) return sort;
    if (a.draw !== b.draw) return a.draw < b.draw ? -1 : 1;
    return drawToken(week.seed, "tie-again|" + week.id + "|" + a.accountId).localeCompare(drawToken(week.seed, "tie-again|" + week.id + "|" + b.accountId));
  });
  const nq = entries.filter((e) => qualifies(e.match)).length;
  for (let i = 0; i < entries.length; ) {
    let end = i + 1;
    while (end < entries.length && compareKeys(entries[i].match.key, entries[end].match.key) === 0) end++;
    const qualified = qualifies(entries[i].match);
    const rankReward = qualified ? rankCash(i + 1, end - i, nq) : 0;
    for (let j = i; j < end; j++) Object.assign(entries[j], { position: j + 1, tieRank: i + 1, tieSize: end - i, tier: publicTier(j + 1, entries.length), guarantee: qualified ? 20 : 0, rankReward });
    i = end;
  }
  return { entries, nq };
}
function recordCup(s, entry2, outcome) {
  const tier = outcome.tier;
  if (!tier) return;
  const key = entry2.theme.id + "-" + tier;
  const cups = s.show.cups;
  const previous = Object.values(cups).filter((c) => c.themeId === entry2.theme.id).reduce((max, c) => Math.max(max, points[entry2.mode][c.tier]), 0);
  if (!cups[key]) cups[key] = { themeId: entry2.theme.id, tier, count: 0, first: entry2.id, firstAt: entry2.result, source: entry2.mode === "public" ? "local_sim" : "private" };
  cups[key].count++;
  s.ratingBps += Math.max(0, points[entry2.mode][tier] - previous);
  const pet = s.pets.find((p) => p.id === entry2.pet.id);
  if (pet) pet.honor = Math.max(pet.honor || 0, honors[entry2.mode][tier]);
}
function settle(s, e) {
  const match = matchScores(e.pet.scores, e.theme);
  if (e.mode === "private") e.outcome = { match, tier: privateTier(match), guarantee: 0, rankReward: 0 };
  else {
    const ranked = board(s, s.show.weeks[e.id], e.pet.species), own = ranked.entries.find((r) => r.player);
    e.outcome = { match, tier: own.tier, position: own.position, tieRank: own.tieRank, tieSize: own.tieSize, n: ranked.entries.length, nq: ranked.nq, guarantee: own.guarantee, rankReward: own.rankReward };
  }
  recordCup(s, e, e.outcome);
  s.coins += e.outcome.guarantee;
}
function tickShow(s, now) {
  ensureCalendar(s, now);
  syncRounds(s, now);
  const due = [];
  for (const e of Object.values(s.show.entries)) {
    if (e.voided) continue;
    if (!e.outcome && e.result <= now) due.push({ at: e.result, e, step: "result" });
    if (e.payout && !e.cashClosed && e.payout <= now) due.push({ at: e.payout, e, step: "cash" });
  }
  due.sort((a, b) => a.at - b.at || a.e.id.localeCompare(b.e.id));
  for (const { e, step } of due) {
    if (step === "result") settle(s, e);
    else {
      const { guarantee, rankReward } = e.outcome;
      e.cashPaid = Math.max(0, rankReward - guarantee);
      s.coins += e.cashPaid;
      e.cashClosed = true;
    }
  }
}
function current(s, mode, now) {
  const slot = period(s, mode, now);
  return slot && (mode === "private" ? s.show.activePrivate : s.show.weeks[slot.id]);
}
function eligible(s, p, now) {
  return p && Object.hasOwn(animals, p.species) && ["成年", "老年"].includes(stageOf(p, now)) && !isBusy(s, p);
}
function petSummary(p, now) {
  return {
    id: p.id,
    name: p.name,
    species: p.species,
    breed: breedName(p),
    breedKey: p.breedKey,
    mixed: Boolean(p.mixed),
    coatIndex: p.coatIndex,
    sex: p.sex,
    art: petArt(p),
    stage: stageOf(p, now),
    scores: p.traits.map((t) => grades.indexOf(t.grade)),
    traits: p.traits.map((t) => ({ type: t.type, label: t.label, rarity: t.rarity, grade: t.grade }))
  };
}
var privateFees = { rabbit: 20, cat: 100, dog: 120 };
function feeFor(s, mode, species) {
  return mode === "private" ? Math.ceil(privateFees[species] * (2e5 - s.ratingBps) / 2e6) * 10 : 0;
}
function nextRegistration(s, mode, access, now) {
  let opens = Math.max(now, s.show.epoch, access.opensAt);
  let slot = period(s, mode, opens);
  if (opens >= slot.close || s.show.entries[slot.id] || s.show.voids?.[slot.id]) {
    opens = roundStart(s, mode, slot.index + 1);
    slot = period(s, mode, opens);
  }
  return "下一次可报名 " + time(opens) + "，截止 " + time(slot.close) + "，公布结果 " + time(slot.result) + "（北京时间）。";
}
function registrationOpens(s, mode, access, now) {
  return (mode === "private" ? "私人赛" : "公开赛") + "需开店第 " + access.opensDay + " 天。" + nextRegistration(s, mode, access, now);
}
function review2(s, a, now, rules) {
  const mode = a.mode;
  if (!Object.hasOwn(PNAME, mode)) throw Error("请选择私人赛或本地模拟公开赛。");
  const access = shopRaceAccess(rules, s.createdAt, now).raceAccess[mode];
  if (!access.unlocked) throw Error(registrationOpens(s, mode, access, now));
  const round = current(s, mode, now);
  if (!round || round.id !== a.event || now >= round.close) throw Error("该轮报名已截止。" + nextRegistration(s, mode, access, now));
  if (s.show.voids?.[round.id]) throw Error("本期技术作废。" + nextRegistration(s, mode, access, now));
  if (s.show.entries[round.id]) throw Error("本轮已经提交过报名。" + nextRegistration(s, mode, access, now));
  const choices = mode === "private" ? round.choices : [round.theme], theme = choices.find((t) => t.id === a.theme);
  if (!theme) throw Error("本轮没有这场主题赛。");
  const pet = s.pets.find((p) => p.id === a.pet);
  if (!eligible(s, pet, now)) throw Error("请选店内成年或老年、空闲的动物。");
  const snapshot = petSummary(pet, now), fee = feeFor(s, mode, pet.species);
  const token = createHash3("sha256").update(JSON.stringify([round.id, theme, snapshot, fee])).digest("hex");
  return { round, theme, snapshot, fee, token, match: matchScores(snapshot.scores, theme) };
}
function showAction(s, type, args, now, rules = shop_feature_levels_default) {
  if (type !== "show.enter") return void 0;
  const { round, theme, snapshot, fee, token } = review2(s, args, now, rules);
  if (args.token !== token) throw Error("报名动物或报价已变化，请重新核对快照。");
  if (s.coins < fee) throw Error("金币不足，无法支付私人赛报名费。");
  s.coins -= fee;
  s.show.entries[round.id] = {
    id: round.id,
    mode: args.mode,
    theme: structuredClone(theme),
    submitted: now,
    fee,
    pet: snapshot,
    close: round.close,
    result: round.result,
    payout: round.payout,
    source: args.mode === "public" ? "local_sim" : "private"
  };
  return snapshot.name + "已报名「" + theme.name + "」，" + time(round.result) + "出结果。";
}
var link2 = (page, args = {}) => ({ page, args });
var action2 = (label, page, args = {}) => ({ label, page, args });
function themeLine(theme) {
  return "目标 " + gradeList(theme.targets);
}
function eventHome(s, now, rules) {
  const rows = [];
  const schedule = {};
  const day3 = shopRaceAccess(rules, s.createdAt, now);
  for (const mode of ["private", "public"]) {
    const round = current(s, mode, now);
    const access = day3.raceAccess[mode];
    if (!round) {
      rows.push({ title: PNAME[mode] + "尚未开赛", text: nextRegistration(s, mode, access, now), visual: { mode } });
      continue;
    }
    const start = rows.length;
    schedule[mode] = { close: time(round.close), result: time(round.result), payout: round.payout ? time(round.payout) : "", entered: !!s.show.entries[round.id] };
    const entry2 = s.show.entries[round.id];
    const status = now >= round.close ? "本轮已截止" : access.unlocked ? "报名至 " + time(round.close) : "开店第 " + access.opensDay + " 天开放报名";
    const cancelled = s.show.voids?.[round.id];
    if (cancelled) {
      rows.push({
        title: PNAME[mode] + " · 本期技术作废",
        text: cancelled.reason,
        ...entry2 ? { link: link2("show.result", { event: entry2.id }) } : {}
      });
    } else if (mode === "private") {
      if (entry2) rows.push({ title: "私人赛 · " + entry2.theme.name, text: "本轮已报名 " + entry2.pet.name, link: link2("show.result", { event: entry2.id }) });
      else for (const t of round.choices) rows.push({
        title: t.name,
        text: "私人三选一 · " + status,
        link: link2("show.round", { mode, event: round.id, theme: t.id })
      });
    } else {
      rows.push({
        title: round.theme.name,
        text: "本地模拟公开赛 · " + (entry2 ? "已报名 " + entry2.pet.name : status),
        link: link2(entry2 ? "show.result" : "show.round", { event: round.id, mode, theme: round.theme.id })
      });
      if (now >= round.result && round.index >= s.show.calendar.firstWeek) rows.push({ title: "本周公开赛榜单", text: "兔、猫、狗分榜 · 查看实际获档名单", link: link2("show.board", { event: round.id }) });
    }
    if (now >= round.close || !access.unlocked || entry2 || cancelled) {
      rows.push({ title: "后续参赛时间", text: nextRegistration(s, mode, access, now) });
    }
    for (const row2 of rows.slice(start)) row2.visual = { mode };
  }
  let model, bestScore = -1;
  for (const pet of s.pets) {
    if (stageOf(pet, now) === "已故") continue;
    const score = cardQualityScore(pet.traits);
    if (score !== void 0 && score > bestScore) {
      model = pet;
      bestScore = score;
    }
  }
  return {
    title: "比赛",
    art: topicArt,
    visual: { schedule, ...day3, pet: model ? petArt(model) : null, petStage: model ? stageOf(model, now) : null },
    subtitle: "北京时间 · 同一轮只可报名一只动物",
    rows,
    empty: "赛历 " + time(s.show.epoch) + " 开放",
    actions: [action2("奖杯收藏", "collection"), action2("参赛记录", "show.history"), action2("公开赛历届榜单", "show.archive")]
  };
}
function roundPage(s, a, now, rules) {
  const mode = a.mode, round = Object.hasOwn(PNAME, mode) ? current(s, mode, now) : null;
  if (!round || round.id !== a.event) return eventHome(s, now, rules);
  const theme = (mode === "private" ? round.choices : [round.theme]).find((t) => t.id === a.theme);
  if (!theme) return eventHome(s, now, rules);
  const day3 = shopRaceAccess(rules, s.createdAt, now), access = day3.raceAccess[mode];
  const rows = [
    { title: "六维目标", text: dimensions.map((d, i) => d + " " + grades[theme.targets[i]]).join(" · ") },
    { title: "匹配规则", text: "距目标0/1/2/更多档，依次得100/70/30/0分。高于和低于目标同样扣分。" },
    { title: "报名截止 " + time(round.close), text: "结果 " + time(round.result) + (round.payout ? " · 排名现金 " + time(round.payout) : "") }
  ];
  if (mode === "public") {
    const order = [0, 1, 2, 3, 4, 5].sort((x, y) => theme.weights[y] - theme.weights[x] || x - y);
    rows.push(
      { title: "六维权重", text: dimensions.map((d, i) => d + " " + theme.weights[i] + "%").join(" · ") },
      { title: "同分比较", text: "先比最低单维和命中数，再比 " + order.map((i) => dimensions[i]).join("、") + "。仍并列时抽签定杯，现金按并列平分。" },
      { title: "本地模拟抽签承诺 · SHA-256", text: round.commit }
    );
  } else rows.push({ title: "奖杯门槛", text: "68 分铜杯，82 分银杯，95 分金杯。" });
  const reg = s.show.entries[round.id];
  if (s.show.voids?.[round.id]) rows.push({ title: "本期技术作废", text: s.show.voids[round.id].reason + " · " + nextRegistration(s, mode, access, now) });
  else if (reg) rows.push({ title: "本轮已报名 · " + reg.pet.name, text: nextRegistration(s, mode, access, now), link: link2("show.result", { event: reg.id }) });
  else if (now < round.close && !access.unlocked) rows.push({ title: "报名尚未开放", text: registrationOpens(s, mode, access, now) });
  else if (now < round.close) {
    const pets = s.pets.filter((p) => eligible(s, p, now));
    if (!pets.length) rows.push({ title: "暂无可报名动物", text: "需店内成年或老年、未在繁育中的动物。" });
    for (const p of pets) rows.push({
      title: p.name,
      text: "报名 " + feeFor(s, mode, p.species) + " 金币",
      animal: specimen(s, p, now),
      art: petArt(p),
      stage: stageOf(p, now),
      link: link2("show.review", { mode, event: round.id, theme: theme.id, pet: p.id })
    });
  } else rows.push({ title: "本期报名已截止", text: nextRegistration(s, mode, access, now) });
  const actions = mode === "public" && !s.show.voids?.[round.id] && now >= round.result && round.index >= s.show.calendar.firstWeek ? [action2("查看物种榜", "show.board", { event: round.id })] : [];
  return { title: theme.name, subtitle: PNAME[mode], visual: day3, rows, actions };
}
function reviewPage(s, a, now, rules) {
  let v;
  try {
    v = review2(s, a, now, rules);
  } catch (error) {
    return { title: "报名核对", rows: [{ title: error.message }], actions: [action2("回到赛事台", "show")] };
  }
  const { snapshot: p, match, theme, fee, token } = v;
  return { title: "报名核对", subtitle: PNAME[a.mode] + " · " + theme.name, art: p.art, stage: p.stage, rows: [
    { title: p.name + " · " + p.breed, text: p.sex + " · " + p.stage + " · " + gradeList(p.scores) },
    { title: "六维匹配 " + displayScore(match) + " 分", text: themeLine(theme) + "\n逐维 " + match.dims.join(" / ") },
    { title: "本次实付 " + fee + " 金币", text: (a.mode === "private" ? "基准 " + privateFees[p.species] + " 金币。" : "公开赛免费。") + "提交后固定动物快照，占用本轮唯一机会。参赛后仍可出售或配对。" }
  ], actions: [
    {
      label: "提交报名",
      type: "show.enter",
      args: { mode: a.mode, event: a.event, theme: a.theme, pet: a.pet, token },
      confirm: "确定为「" + p.name + "」报名 " + theme.name + "？" + (a.mode === "private" ? "基准 " + privateFees[p.species] + " 金币，" : "") + "实付 " + fee + " 金币，提交后不能更换动物。",
      go: "show.result",
      goArgs: { event: a.event }
    },
    action2("重选参赛动物", "show.round", { mode: a.mode, event: a.event, theme: a.theme })
  ] };
}
function resultPage(s, id) {
  const e = lookup(s.show.entries, id);
  if (!e) return { title: "参赛记录", rows: [], empty: "还没有这场报名。" };
  const o = e.outcome, p = e.pet;
  const rows = [
    { title: e.theme.name, text: PNAME[e.mode] + " · 报名 " + time(e.submitted) + " · 实付 " + e.fee + " 金币" },
    { title: "报名快照 · " + p.name, text: p.breed + " · " + p.sex + " · 报名时" + p.stage + "\n" + gradeList(p.scores), art: p.art, stage: p.stage },
    { title: "比赛目标", text: themeLine(e.theme) + "\n权重 " + e.theme.weights.join(" / ") }
  ];
  if (e.voided) rows.push({ title: "本期技术作废", text: e.voided + " · 已退 " + e.fee + " 金币" });
  else if (!o) rows.push({ title: "已报名，等待结果", text: "公布 " + time(e.result) });
  else {
    rows.push({
      title: o.tier ? "获得" + trophies[o.tier] : "本场未获杯",
      art: o.tier ? "awards/" + o.tier : void 0,
      text: displayScore(o.match) + " 分 · " + time(e.result) + "\n逐维 " + o.match.dims.join(" / ")
    });
    if (e.mode === "public") rows.push(
      { title: "第 " + o.position + " / " + o.n + " 位 · 达标 " + o.nq + " 位", text: "真正并列 " + o.tieSize + " 人，起始名次 " + o.tieRank },
      { title: "达标现金 +" + o.guarantee, text: e.cashClosed ? "周日补差 +" + e.cashPaid + "，现金已结清。" : "排名补差 " + time(e.payout) + " 结算。" }
    );
    if (o.tier) rows.push({ title: "本档权益", text: "本档覆盖较低收益资格；收藏仅计本次实际获得的" + trophies[o.tier] + "。" });
  }
  const actions = [action2("奖杯收藏", "collection")];
  if (e.mode === "public" && o) actions.unshift(action2("五档名单", "show.board", { event: id, species: p.species }));
  return { title: "参赛记录", rows, actions };
}
function collectionPage(s, mode) {
  const selected = mode === "public" ? "public" : "private";
  const held = Object.values(s.show.cups).filter((c) => byTheme[c.themeId]?.mode === selected);
  return {
    title: "奖杯收藏",
    subtitle: PNAME[selected] + " · 已收集 " + held.length + " / " + groups[selected].length * tiers[selected].length,
    rows: groups[selected].map((t) => {
      const earned = held.filter((c) => c.themeId === t.id);
      return { title: t.name, text: earned.length ? earned.map((c) => trophies[c.tier] + " ×" + c.count).join(" · ") : "尚未获杯", link: link2("collection.theme", { theme: t.id }) };
    }),
    actions: [action2("私人杯册", "collection", { mode: "private" }), action2("模拟公开杯册", "collection", { mode: "public" })]
  };
}
function collectionTheme(s, id) {
  const t = lookup(byTheme, id);
  if (!t) return collectionPage(s, "private");
  return { title: t.name, subtitle: PNAME[t.mode], rows: tiers[t.mode].map((tier) => {
    const c = s.show.cups[t.id + "-" + tier];
    if (!c) return { title: trophies[tier] + " · 未收集", text: "需在该赛事实际获得此档。", art: "awards/" + tier, visual: { uncollected: true } };
    const first = s.show.entries[c.first];
    return {
      title: trophies[tier] + " ×" + c.count,
      art: "awards/" + tier,
      text: "首获 " + time(c.firstAt) + " · " + first.pet.name + " · " + displayScore(first.outcome.match) + " 分",
      link: link2("show.result", { event: first.id })
    };
  }), actions: [action2("选择其他主题", "collection", { mode: t.mode })] };
}
function lastPublished(s, now) {
  return Math.floor((now - s.show.epoch - 5 * DAY2) / WEEK);
}
function archivePage(s, now, cursor = 0) {
  const first = s.show.calendar.firstWeek, last = lastPublished(s, now), size = 8;
  const totalPages = Math.max(1, Math.ceil((last - first + 1) / size));
  const p = Number.isSafeInteger(cursor) ? Math.min(Math.max(0, cursor), totalPages - 1) : 0;
  const top = last - size * p, rows = [];
  for (let i = top; i >= Math.max(first, top - size + 1); i--) {
    const id = "public-" + i, saved = s.show.weeks[id];
    const theme = saved?.theme ?? publicTheme(s, i), at = saved?.result ?? roundStart(s, "public", i) + 5 * DAY2;
    const cancelled = s.show.voids?.[id];
    rows.push(cancelled ? { title: theme.name + " · 技术作废", text: cancelled.reason } : { title: theme.name, text: "公布 " + time(at), link: link2("show.board", { event: id }) });
  }
  const actions = [action2("当前赛事", "show", { mode: "public" })];
  if (p > 0) actions.push(action2("较近的赛期", "show.archive", { cursor: p - 1 }));
  if (p + 1 < totalPages) actions.push(action2("更早的赛期", "show.archive", { cursor: p + 1 }));
  return { title: "本地模拟公开赛", subtitle: "已公布的物种榜 · 第 " + (p + 1) + " / " + totalPages + " 页", rows, actions, empty: "首期结果将在周六20:00公布。" };
}
function publishedWeek(s, id, species, now) {
  if (typeof id !== "string" || !/^public-(0|[1-9]\d*)$/.test(id)) return null;
  if (s.show.voids?.[id]) return null;
  const index = Number(id.slice(7));
  if (!Number.isSafeInteger(index) || index < s.show.calendar.firstWeek || index > lastPublished(s, now)) return null;
  const saved = lookup(s.show.weeks, id);
  if (saved) return now >= saved.result ? saved : null;
  return makeWeek(s, period(s, "public", roundStart(s, "public", index)), [species]);
}
function boardPage(s, a, now, list) {
  const species = Object.hasOwn(animals, a.species) ? a.species : "rabbit";
  const w = publishedWeek(s, a.event, species, now);
  if (!w) return { title: "本地模拟公开赛", rows: [], empty: "本期暂无可查看的结果。" };
  const { entries, nq } = board(s, w, species);
  const actions = Object.keys(animals).map((id) => action2(animals[id] + "榜", "show.board", { event: w.id, species: id }));
  if (list) {
    const tier = tiers.public.includes(a.tier) ? a.tier : "laurel";
    const selected = entries.filter((e) => e.tier === tier);
    const snapshot = s.show.entries[w.id]?.pet;
    return {
      title: trophies[tier] + "名单",
      subtitle: "本地模拟公开赛 · " + animals[species] + "榜 · " + w.theme.name,
      visual: { tierOptions: tiers.public.map((t) => ({
        title: trophies[t],
        art: "awards/" + t,
        text: entries.filter((e) => e.tier === t).length + " 位",
        link: { ...link2("show.tier", { event: w.id, species, tier: t }), active: t === tier, replace: true }
      })) },
      rows: selected.map((e) => ({
        title: e.position + ". " + (e.player ? "本店 · " : "") + e.name,
        art: e.player && snapshot.art ? snapshot.art : speciesPortrait[species],
        ...e.player && snapshot.art ? { stage: snapshot.stage } : {},
        text: (e.player ? "本店参赛 · " + s.profileId.slice(-6) + (snapshot.art ? "" : " · 物种示意图") : "模拟选手 · " + e.accountId) + " · " + displayScore(e.match) + " 分\n逐维 " + e.match.dims.join(" / "),
        link: e.player ? link2("show.result", { event: w.id }) : link2("show.bot", { event: w.id, species, id: e.accountId })
      })),
      actions: Object.keys(animals).map((id) => action2(animals[id] + "榜", "show.tier", { event: w.id, species: id, tier })),
      empty: "本物种榜没有获得此档的动物。"
    };
  }
  const rows = tiers.public.map((tier) => ({
    title: trophies[tier],
    art: "awards/" + tier,
    text: entries.filter((e) => e.tier === tier).length + " 位",
    link: link2("show.tier", { event: w.id, species, tier })
  }));
  rows.push({ title: "模拟抽签校验", text: "种子 " + w.seed + "\nSHA-256 承诺 " + w.commit });
  return { title: "本地模拟公开赛", subtitle: w.theme.name + " · " + animals[species] + "榜 " + entries.length + " 位，现金达标 " + nq + " 位", rows, actions };
}
function botPage(s, a, now) {
  const species = a.species;
  if (!Object.hasOwn(animals, species)) return archivePage(s, now);
  const w = publishedWeek(s, a.event, species, now);
  if (!w) return archivePage(s, now);
  const e = board(s, w, species).entries.find((entry2) => !entry2.player && entry2.accountId === a.id);
  if (!e) return archivePage(s, now);
  return { title: e.name, subtitle: "本地模拟公开赛 · " + w.theme.name, rows: [
    { title: "模拟选手 " + e.accountId, art: speciesPortrait[species], text: "第 " + e.position + " 名 · " + trophies[e.tier] + " · " + displayScore(e.match) + " 分\n头像为" + animals[species] + "榜物种示意。" },
    { title: "六维快照", text: gradeList(e.scores) + "\n目标 " + gradeList(w.theme.targets) },
    { title: "抽签摘要", text: e.draw }
  ] };
}
function showPage(s, page, args = {}, now, rules = shop_feature_levels_default) {
  switch (page) {
    case "show":
      return eventHome(s, now, rules);
    case "show.round":
      return roundPage(s, args, now, rules);
    case "show.review":
      return reviewPage(s, args, now, rules);
    case "show.result":
      return resultPage(s, args.event);
    case "show.archive":
      return archivePage(s, now, args.cursor);
    case "show.board":
      return boardPage(s, args, now, false);
    case "show.tier":
      return boardPage(s, args, now, true);
    case "show.bot":
      return botPage(s, args, now);
    case "show.history":
      return { title: "参赛记录", rows: Object.values(s.show.entries).sort((a, b) => b.submitted - a.submitted).map((e) => ({
        title: e.theme.name,
        text: time(e.submitted) + " · " + PNAME[e.mode] + " · " + e.pet.name + " · " + (e.voided ? "已作废" : e.outcome ? "已公布" : "等待公布"),
        link: link2("show.result", { event: e.id })
      })), actions: [action2("当前赛事", "show")], empty: "尚无报名记录。" };
    case "collection":
      return collectionPage(s, args.mode);
    case "collection.theme":
      return collectionTheme(s, args.theme);
    default:
      return null;
  }
}

// output/aliyun/source-market-breed-20261121/PetShop/server/visit-book.mjs
import { randomUUID as randomUUID4 } from "node:crypto";
var cupNames = { bronze: "铜杯", silver: "银杯", gold: "金杯", memorial: "纪念杯", laurel: "桂冠杯" };
var sessionTimeout = 45e3;
var close = { label: "合上账簿", type: "ui.back" };
function initVisitBook(s, existing) {
  if (s.visitBook) return false;
  s.visitBook = { lastSeenAt: existing ? s.clock : null, opening: !existing, away: [], stories: [] };
  const firstSale = s.sales?.find((sale) => ["market", "guest", "order"].includes(sale.channel));
  const firstNote = s.journal.find((note) => note.key === "trade");
  if (existing && firstNote) {
    if (firstSale) firstNote.at = firstSale.at;
    else if (Array.isArray(s.sales)) s.journal = s.journal.filter((note) => note !== firstNote);
  }
  if (existing && finishStory(s, s.clock)) s.visitBook.stories.push({ id: randomUUID4(), text: ending });
  return true;
}
var ending = "开门、等候、挑选、记账。小店有了自己的日常，账簿仍会继续往后写。";
function finishStory(s, now) {
  if (s.journal.some((n) => n.key === "closing") || !["trade", "room", "guest"].every((key) => s.journal.some((n) => n.key === key))) return false;
  s.journal.push({ key: "closing", text: ending, at: now });
  return true;
}
function recordMilestone(s, type, args, now) {
  const lines = [];
  const add = (key, text) => {
    if (s.journal.some((n) => n.key === key)) return;
    s.journal.push({ key, text, at: now });
    lines.push(text);
  };
  if (type === "care.unlock") add("room", "研究所联络员送来" + SPECIES[args.species].name + "房资料：“这对幼崽有自己的成长周期，看看它们什么时候成年吧。”");
  if (type === "sale.commit" && ["market", "order", "guest"].includes(args.channel)) {
    add("trade", "第一笔生意完成了。你在账簿上记下收入，也重新看了看店里留下的动物。");
    if (args.channel === "guest") add("guest", "书店来客收下了心仪的动物。你之前选出的特征，正好合了这次委托。");
  }
  if (!lines.length) return;
  if (finishStory(s, now)) lines.push(ending);
  s.visitBook.stories.push({ id: randomUUID4(), text: lines.join("\n") });
}
function awayEvents(s, from, to) {
  const events = [];
  function add(at, title, text) {
    if (at > from && at <= to) events.push({ at, title, text });
  }
  for (const [key, room] of Object.entries(s.rooms)) {
    const litter2 = room.lastLitter;
    if (litter2) add(litter2.bornAt, SPECIES[key].name + "房出生 " + litter2.ids.length + " 只", litter2.mother + " × " + litter2.father);
  }
  for (const p of s.pets) {
    const { adultAt, deathAt } = lifeDates(p);
    add(adultAt, p.name + " 已成年", SPECIES[p.species].name + " · " + p.sex + " · #" + p.id.slice(0, 5).toUpperCase());
    add(deathAt, p.name + " 自然死亡", SPECIES[p.species].name + " · " + p.sex + " · #" + p.id.slice(0, 5).toUpperCase());
  }
  s.orders.forEach((slot, i) => {
    if (slot.order?.refilledAt) add(slot.order.refilledAt, "第 " + (i + 1) + " 槽普通订单已补单", "新委托已放入订单夹。");
  });
  for (const e of Object.values(s.show.entries)) {
    if (!e.outcome || e.voided) continue;
    const name = e.pet.name + " · " + e.theme.name;
    add(e.result, name, e.outcome.tier ? "获得" + cupNames[e.outcome.tier] + "。" : "本次未获杯。");
    if (e.cashClosed) add(e.payout, name + " · 排名结算", "追加到账 " + e.cashPaid + " 金币。");
  }
  return events.sort((a, b) => a.at - b.at);
}
function seedRecoveryRows(s, now, access) {
  const paired = Object.keys(s.rooms).some((species) => {
    if (s.rooms[species].job) return true;
    const candidates = s.pets.filter((p) => p.species === species && stageOf(p, now) !== "已故" && !p.bred && !isBusy(s, p));
    return candidates.some((p) => p.sex === "母") && candidates.some((p) => p.sex === "公");
  });
  if (paired) return [];
  const signed = s.care.signedDay === dayAt(now);
  const rows = [{
    title: "当前后备种源不足",
    text: signed ? "今天已签到，次日可再领一对基础幼兔。" : "今日签到可领一公一母两只基础幼兔。",
    link: { page: "profile" }
  }];
  if (!access.lab.unlocked) {
    rows.push({ title: "研究所尚未开放", text: "店铺 " + access.lab.requiredLevel + " 级开放种源货架。" });
    return rows;
  }
  for (const [species, room] of Object.entries(s.rooms)) {
    const stock = (room.shelf?.offers ?? []).filter(Boolean);
    rows.push({
      title: SPECIES[species].name + "房当前货架",
      text: stock.length ? stock.map((p) => p.name + "（" + p.sex + "）" + purchasePrice(s, youngPurchaseBase(p)) + " 金币").join("、") : "本批已售空。",
      link: { page: "lab" }
    });
  }
  return rows;
}
function summaryPage(s, events, now, access) {
  const rows = events.map((e) => ({ title: e.title, text: beijingTime(e.at) + "　" + e.text }));
  return { title: "离店期间", subtitle: "北京时间 · 以下事项均已结算", rows: [...rows, ...seedRecoveryRows(s, now, access)], actions: [close] };
}
var bookletCaptions = [
  "",
  "先去「动物小屋」，免费开放兔房。我留下的那对小兔，会直接住进去。",
  "进兔房点「投喂」，把这份营养餐喂给它们，两只小兔就会长大。",
  "点「开始繁育」，只要等 5 秒，再点「查看首窝」，看看新出生的小兔。之后兔房每窝要等 2 分钟。",
  "这一窝有四只，性别、特点和价钱各不相同。先想想，留哪两只继续繁育？",
  "留下一公一母作种源，卖掉一只换金币，剩下一只先养在兔房。确认无误再点「确认选择」。",
  "看看卖了多少钱，留种兔还要多久长大，然后领走我给你的开店奖励。",
  "领完开店奖励，「安置兔房」会自动开启，从这时开始记进度。回店里打开「任务」就能看到。",
  "做完这三件事就可以领奖。下一组会自动开启，从零开始。"
];
function openingBooklet() {
  return { title: "交接信", visual: { openingBooklet: bookletCaptions.map((caption, index) => ({
    art: "onboarding/letter-" + index,
    caption
  })) } };
}
function openingPage2(revisit) {
  return { title: "旧店交接", subtitle: "账簿的第一页", rows: [
    { title: "街角的小店", text: "柜台上压着钥匙和一本旧账簿。原店主写道：“先别急着把店做大，看看进门的人需要什么。”" },
    { title: "兔房里的一对种兔", text: "小花和小白在开店时已经成年。到繁育台选好亲本，核对后就能开始第一窝。" }
  ], actions: [{ label: "查看任务", page: "tasks" }, revisit ? close : { label: "进入店铺", type: "ui.back" }] };
}
function visitHistoryPage(s, key, now, access, args = {}) {
  if (key === "openingGuide" || key === "onboarding") {
    const page = s.onboarding ? openingBooklet() : openingPage2(true);
    return { ...page, readNoteIds: s.visitBook.opening ? ["opening"] : [] };
  }
  if (key === "lastVisit" && s.visitBook.lastReport) return summaryPage(s, s.visitBook.lastReport, now, access);
  return null;
}
function unreadLetter(s, now, access) {
  const book = s.visitBook;
  if (book.away.length) return { ids: book.away.map((b) => b.id), page: summaryPage(s, book.away.flatMap((b) => b.events), now, access) };
  if (book.opening) return { ids: ["opening"], page: s.onboarding ? openingBooklet() : openingPage2(false) };
  if (book.stories.length) return { ids: book.stories.map((n) => n.id), page: {
    title: "账簿新页",
    rows: book.stories.map((n) => ({ title: "经营手记", text: n.text })),
    actions: [close]
  } };
  return null;
}
function updateVisit(s, sessions, clientId, foreground, reader, now) {
  for (const [key, session] of sessions) if (now - session.at > sessionTimeout * 2) sessions.delete(key);
  if ((sessions.get(clientId)?.seq ?? -1) >= reader.seq) return;
  const active = Array.from(sessions.values()).some((session) => session.foreground && now - session.at <= sessionTimeout);
  const previous = sessions.get(clientId);
  const book = s.visitBook;
  if (foreground && !active && book.lastSeenAt !== null) {
    const events = awayEvents(s, book.lastSeenAt, now);
    if (events.length) book.away.push({ id: randomUUID4(), events });
  }
  if (foreground || previous?.foreground && now - previous.at <= sessionTimeout) book.lastSeenAt = now;
  sessions.set(clientId, { at: now, foreground, seq: reader.seq });
  const read = new Set(reader.read || []);
  if (read.has("opening")) book.opening = false;
  if (read.size) {
    const archived = book.away.filter((b) => read.has(b.id));
    if (archived.length) book.lastReport = archived.flatMap((b) => b.events);
    book.away = book.away.filter((b) => !read.has(b.id));
    book.stories = book.stories.filter((b) => !read.has(b.id));
  }
}

// output/aliyun/source-market-breed-20261121/PetShop/server/breeding-programs.mjs
var speciesOptions = ["cat", "dog"];
var reserveFees = { cat: 200, dog: 500 };
var courseFees = { cat: [3e3, 6e3, 12e3], dog: [8e3, 16e3, 32e3] };
var halfHour = 30 * 6e4;
var day2 = 48 * halfHour;
var courseTitles = ["初级", "进阶", "专精"];
var courseGoals = [
  "持有 1 只本店繁育的同品种纯种幼体或成体。",
  "持有 2 只本店繁育的同品种纯种成体，每只至少有一项五维达到 A 或以上。",
  "持有 3 只本店繁育的同品种纯种成体，每只至少有两项五维达到 A 或以上。"
];
var go3 = (label, page, args) => ({ label, page, args, replace: true });
var button = (label, type, args, confirm, disabled = false) => ({ label, type, args, confirm, disabled });
var row = (title, text, link3) => ({ title, text, ...link3 && { link: link3 } });
var time2 = (value) => beijingTime(value).slice(0, 16);
function requireRoom(s, species) {
  if (!speciesOptions.includes(species) || !s.rooms[species]) throw Error("请先开放对应的猫房或狗房。");
  return s.rooms[species];
}
function qualifyingPets(s, { breedKey, tier }, now) {
  return s.pets.filter((p) => p.breedKey === breedKey && !p.mixed && p.source === "本店繁育" && stageOf(p, now) !== "已故" && (tier === 0 || ["成年", "老年"].includes(stageOf(p, now)) && p.traits.slice(0, 5).filter((t) => ["A", "S", "S+"].includes(t.grade)).length >= tier));
}
function reservationPage(s, species, args, base, now) {
  const room = s.rooms[species], held = room.reservedSeed;
  const context = { species }, page = "seedReservation";
  if (held) {
    const { offer, readyAt, expiresAt, fee: fee2 } = held;
    const identity = { ...context, id: offer.id };
    const title = BREEDS[offer.breedKey].name + " · " + offer.sex;
    if (now < readyAt) return {
      ...base,
      subtitle: "预约已登记",
      rows: [row(title, time2(readyAt) + " 到货 · 北京时间")],
      actions: [button("取消预约", "seed.cancel", identity, "取消本次预约，退回 " + fee2 + " 金币？")]
    };
    const animal = specimen(s, { ...offer, bornAt: now }, now, { inShop: false }), price = purchasePrice(s, youngPurchaseBase(offer));
    return {
      ...base,
      subtitle: "预约已到货",
      rows: [{ ...row(animal.name + " · " + title, "购买 " + price + " 金币 · " + time2(expiresAt) + " 前领取"), art: animal.art, stage: animal.stage }],
      actions: [
        button("购买预约种源", "seed.claim", { ...identity, price }, "支付 " + price + " 金币，让这只幼体入住？", s.coins < price),
        button("放弃种源", "seed.cancel", identity, "放弃已到货种源？预约费已结算。")
      ]
    };
  }
  const fee = purchasePrice(s, reserveFees[species]);
  const details = row("定向预约", "选择品种和性别，下批到货后保留 24 小时。每房每天最多一次，购宠另行付款。");
  if (room.reservedOn === dayAt(now)) return { ...base, rows: [details, row("今日已预约", "北京时间次日零点后可以再次预约。")] };
  const breedKey = args.breedKey;
  if (!SPECIES[species].breeds.includes(breedKey)) return { ...base, rows: [details, ...SPECIES[species].breeds.map((key) => row(BREEDS[key].name, "预约费用 " + fee + " 金币", go3("选性别", page, { ...context, breedKey: key })))] };
  return { ...base, subtitle: BREEDS[breedKey].name, rows: [details], actions: ["母", "公"].map((sex) => button("预约" + sex + "性", "seed.reserve", { species, breedKey, sex, fee }, "支付 " + fee + " 金币预约" + BREEDS[breedKey].name + "（" + sex + "）？", s.coins < fee)) };
}
function coursesPage(s, species, args, base, now) {
  const state = s.rooms[species].breedingCourses, active = state?.active;
  if (active) {
    const { breedKey: breedKey2, tier } = active, name = BREEDS[breedKey2].name;
    const animals2 = qualifyingPets(s, active, now), count = tier + 1;
    return {
      ...base,
      subtitle: name + " · " + courseTitles[tier],
      rows: [row("当前课题", courseGoals[tier]), row("进度", animals2.length + " / " + count + " 只 · 完成后登记证书，动物继续留在店内。")],
      actions: [
        button("提交成果", "course.complete", { species, breedKey: breedKey2, tier }, void 0, animals2.length < count),
        button("撤回课题", "course.cancel", { species, breedKey: breedKey2, tier }, "撤回后可重新选择课题。已支付的报名费不退，确认撤回？")
      ]
    };
  }
  const breedKey = args.breedKey, list = SPECIES[species].breeds;
  if (!list.includes(breedKey)) return { ...base, rows: list.map((key) => row(
    BREEDS[key].name,
    "查看三档培育课题",
    go3("查看", "breedingCourses", { species, breedKey: key })
  )) };
  const recorded = state?.records ?? {};
  return { ...base, subtitle: BREEDS[breedKey].name, rows: courseTitles.map((label, tier) => {
    const fee = purchasePrice(s, courseFees[species][tier]), achieved = recorded[breedKey + "-" + tier];
    const locked = tier > 0 && !recorded[breedKey + "-" + (tier - 1)];
    const status = achieved ? "已登记证书" : locked ? "先完成上一档" : fee + " 金币报名";
    return { ...row(label + " · " + status, courseGoals[tier]), ...!achieved && !locked && { action: button(
      "报名",
      "course.start",
      { species, breedKey, tier, fee },
      "支付 " + fee + " 金币报名" + BREEDS[breedKey].name + " · " + label + "？课题没有期限，撤回不退费。",
      s.coins < fee
    ) } };
  }) };
}
function breedingProgramPage(s, page, args, now) {
  if (page !== "seedReservation" && page !== "breedingCourses") return void 0;
  const reservation = page === "seedReservation", title = reservation ? "定向种源预约" : "品种培育课题";
  const open = speciesOptions.filter((key) => s.rooms[key]);
  if (!open.length) return { title, rows: [row("开放后可用", "先开放猫房或狗房。")] };
  const species = open.includes(args.species) ? args.species : open[0];
  const base = { title, tabs: open.map((key) => ({ ...go3(SPECIES[key].name + "房", page, { species: key }), active: species === key })) };
  return reservation ? reservationPage(s, species, args, base, now) : coursesPage(s, species, args, base, now);
}
function breedingProgramAction(s, type, args, now) {
  if (!type.startsWith("seed.") && !type.startsWith("course.")) return void 0;
  const { species, breedKey, tier } = args, room = requireRoom(s, species);
  if (type === "seed.reserve") {
    const today = dayAt(now);
    if (room.reservedSeed || room.reservedOn === today) throw Error("该房今日已预约或仍有待领取的种源。");
    if (!SPECIES[species].breeds.includes(breedKey) || !["母", "公"].includes(args.sex)) throw Error("请选择该物种的品种和性别。");
    const fee = purchasePrice(s, reserveFees[species]);
    chargeQuoted(s, args.fee, fee);
    const readyAt = room.openedAt + (Math.floor((now - room.openedAt) / halfHour) + 1) * halfHour;
    room.reservedOn = today;
    room.reservedSeed = { offer: makeReservationOffer(s, species, today, breedKey, args.sex), fee, readyAt, expiresAt: readyAt + day2 };
    return "预约已登记，预计 " + time2(readyAt) + " 到货（北京时间）。";
  }
  if (type === "seed.cancel" || type === "seed.claim") {
    const held = room.reservedSeed;
    if (!held || held.offer.id !== args.id || now >= held.expiresAt) throw Error("预约不存在或已过期。");
    if (type === "seed.cancel") {
      const refund = now < held.readyAt ? held.fee : 0;
      s.coins += refund;
      delete room.reservedSeed;
      return refund ? "已取消预约并退回 " + refund + " 金币。" : "已放弃该种源。";
    }
    if (now < held.readyAt) throw Error("预约种源尚未到货。");
    chargeQuoted(s, args.price, purchasePrice(s, youngPurchaseBase(held.offer)));
    const pet = admitPurchasedPet(s, room, held.offer, now);
    delete room.reservedSeed;
    return pet.name + "已入住" + SPECIES[species].name + "房。";
  }
  if (!SPECIES[species].breeds.includes(breedKey) || !Number.isInteger(tier) || !courseTitles[tier]) throw Error("没有这项培育课题。");
  const state = room.breedingCourses ??= { records: {} };
  const key = breedKey + "-" + tier;
  if (type === "course.start") {
    if (state.active || state.records[key] || tier > 0 && !state.records[breedKey + "-" + (tier - 1)]) throw Error("请先处理当前课题或完成前一档。");
    chargeQuoted(s, args.fee, purchasePrice(s, courseFees[species][tier]));
    state.active = { breedKey, tier };
    return "已登记" + BREEDS[breedKey].name + " · " + courseTitles[tier] + "课题。";
  }
  if (state.active?.breedKey !== breedKey || state.active.tier !== tier) throw Error("这项课题当前未报名。");
  if (type === "course.cancel") {
    delete state.active;
    return "已撤回课题。";
  }
  if (type === "course.complete") {
    if (qualifyingPets(s, state.active, now).length < tier + 1) throw Error("店内动物还未满足课题条件。");
    state.records[key] = { breedKey, tier, completedAt: now };
    delete state.active;
    return "已将" + BREEDS[breedKey].name + " · " + courseTitles[tier] + "培育证书收入店主登记簿。";
  }
  return void 0;
}
function certificateRows(s) {
  return speciesOptions.flatMap((species) => Object.values(s.rooms[species]?.breedingCourses?.records ?? {}).map(({ breedKey, tier, completedAt }) => row(BREEDS[breedKey].name + " · " + courseTitles[tier] + "培育证书", time2(completedAt) + " 登记 · 北京时间")));
}

// output/aliyun/source-market-breed-20261121/PetShop/server/shop-engine.mjs
var legacyEntrances = Object.keys(featureNames).filter((key) => key !== "collection");
var pageHandlers = [carePage, businessPage, showPage, breedingProgramPage];
var actionHandlers = [careAction, businessAction, showAction, taskAction, breedingProgramAction];
var minute2 = 6e4;
var GameError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
  }
};
function newState(now, onboarding) {
  const id = randomUUID5();
  const state = {
    schema: 1,
    mode: "local_sim",
    profileId: id,
    profile_id: id,
    rootSeed: randomBytes2(32).toString("hex"),
    createdAt: now,
    clock: now,
    version: 1,
    coins: 680,
    shopXp: 0,
    receipts: {},
    journal: []
  };
  initCare(state, now, { onboarding });
  initShow(state, now);
  initBusiness(state, now);
  initVisitBook(state, false);
  if (onboarding) initOnboarding(state);
  return state;
}
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((k) => [k, canonical(value[k])]));
  return value;
}
function shopAccess(s, rules, level) {
  const access = featureAccess(rules, level);
  for (const key of ["lab", "orders"]) if (guideAccess(s, key)) access[key].unlocked = true;
  return access;
}
function publicShop(s, now, rules) {
  const { level, ...shopExperience } = shopProgress(rules, s.shopXp);
  const access = shopAccess(s, rules, level);
  const hints = [];
  const dayClaimed = s.care.signedDay === dayAt(now);
  const guest = access.guest.unlocked && s.visitors.active;
  for (const room of Object.values(s.rooms)) {
    const litter2 = room.lastLitter;
    if (access.breed.unlocked && litter2 && now - litter2.bornAt < 864e5) hints.push({ id: "litter-" + litter2.ids[0], text: "新的一窝出生了，去繁育台看看小家伙吧。" });
  }
  const order = access.orders.unlocked && readyOrderId(s, now);
  if (order) hints.push({ id: "order-" + order, text: "有只动物符合委托，订单夹里可以查看。" });
  return {
    protocol: 1,
    profileId: s.profileId,
    version: s.version,
    mode: s.mode,
    name: "宠物店",
    coins: s.coins,
    shopLevel: level,
    shopExperience,
    ...shopRaceAccess(rules, s.createdAt, now),
    featureAccess: access,
    entrances: legacyEntrances.filter((key) => access[key].unlocked),
    ...guest && { guest: { id: guest.id, endsAt: guest.endsAt } },
    now,
    hints,
    dayClaimed,
    taskShortcut: openingShortcut(s, now) ?? taskShortcut(s, access),
    decor: Object.keys(s.decor || {}).filter((k) => s.decor[k]?.placed),
    rooms: Object.keys(s.rooms || {}).filter((k) => s.rooms[k] && !(k === "rabbit" && rabbitWaitingForOpening(s))),
    notice: s.journal.at(-1) ?? null
  };
}
function accountPage(s, now, access) {
  return {
    title: "店主登记簿",
    subtitle: "本机经营档",
    art: "shop-modules/opening",
    readNoteIds: s.visitBook.stories.map((story) => story.id),
    rows: [
      { title: "店铺资产", text: s.coins + " 金币 · " + s.pets.length + " 只在册动物" },
      { title: "店主编号", text: s.profileId },
      { title: "交接信", text: "重读旧店主的来信和开店指引。", link: { page: "openingGuide" } },
      ...s.visitBook.lastReport ? [{ title: "上次回店摘要", text: "查看离开期间已结算的事项。", link: { page: "lastVisit" } }] : [],
      ...seedRecoveryRows(s, now, access),
      ...certificateRows(s),
      { title: "设备时间", text: "请保持设备时间准确。向前调时会立即推进成长和比赛，可能让动物自然寿终。调回时钟无法撤销已经结算的事件。" },
      ...s.clockEvent ? [{ title: "校时记录", text: s.clockEvent.text }] : [],
      ...s.recoveredFrom ? [{ title: "存档恢复", text: "最近一次从备份 " + s.recoveredFrom + " 恢复。" }] : [],
      ...s.journal.slice(-5).reverse().map((j) => ({ title: j.text, text: new Date(j.at).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" }) }))
    ],
    actions: [{ label: "奖杯收藏册", page: "collection" }, { label: "模拟支付演示", page: "payment" }]
  };
}
function validateState(s) {
  const obj = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
  if (!obj(s) || s.schema !== 1 || s.mode !== "local_sim" || !s.profileId || !Number.isFinite(s.clock) || typeof s.rootSeed !== "string" || !/^[0-9a-f]{64}$/i.test(s.rootSeed) || !Number.isSafeInteger(s.version) || !Array.isArray(s.pets) || !obj(s.receipts) || !obj(s.rooms?.rabbit) || !Array.isArray(s.journal) || !obj(s.care) || !obj(s.research) || !obj(s.decor) || !Array.isArray(s.orders) || s.orders.length !== 3 || !obj(s.businessDay) || !obj(s.visitors?.sessions) || !Array.isArray(s.visitors?.intervals) || !obj(s.show?.weeks) || !obj(s.show?.entries) || !obj(s.show?.cups) || s.pets.some((p) => !p?.id || !obj(s.rooms[p.species]) || !Array.isArray(p.traits) || p.traits.length !== 6) || !Number.isSafeInteger(s.coins) || s.shopXp !== void 0 && (!Number.isSafeInteger(s.shopXp) || s.shopXp < 0)) throw new GameError("经营存档结构不完整。", 503);
  return s;
}
var ShopEngine = class {
  constructor({ wall = Date.now, monotonic = () => performance.now(), rules = shop_feature_levels_default, onboarding = false } = {}) {
    this.wall = wall;
    this.monotonic = monotonic;
    this.rules = rules;
    this.onboarding = onboarding;
    this.readers = /* @__PURE__ */ new Map();
  }
  ensure() {
    if (!this.state) this.initialize(null);
  }
  initialize(restored, { fromBackup = false, resetConnections = false } = {}) {
    const s = restored ?? newState(this.wall(), this.onboarding);
    const retentionChanged = Boolean(restored) && clearBredRetention(s);
    const tagsChanged = Boolean(restored) && normalizeStoredTags(s);
    if (retentionChanged || tagsChanged) s.version++;
    const needsVisitBook = initVisitBook(s, !!restored);
    const needsTasks = initTasks(s, Math.max(s.clock, this.wall()));
    const needsOpening = !Number.isFinite(s.createdAt);
    if (needsOpening) s.createdAt = Number.isFinite(s.rooms.rabbit.openedAt) ? s.rooms.rabbit.openedAt : s.clock;
    const needsXp = s.shopXp === void 0;
    if (needsXp) s.shopXp = (s.sales ?? []).reduce((sum, sale) => sum + (sale.saleExperience ?? saleExperience(this.rules, sale.channel, sale.lines)), 0);
    if (restored && resetConnections && s.visitors) {
      s.visitors.sessions = {};
      s.visitors.intervals = [];
    }
    if (restored && this.wall() < s.clock) s.clockEvent = { at: s.clock, text: "检测到设备时钟回拨，经营时间从上次存档继续。" };
    this.anchor = Math.max(s.clock, this.wall());
    this.mark = this.monotonic();
    this.savedAt = s.clock;
    if (!restored || retentionChanged || tagsChanged || needsXp || needsOpening || needsVisitBook || needsTasks || fromBackup || s.clockEvent && s.clockEvent.at === s.clock) this.save(s);
    this.state = s;
  }
  now() {
    const mono = this.monotonic();
    const estimated = this.anchor + Math.max(0, mono - this.mark), wall = this.wall();
    if (wall - estimated > 2e3) this.clockChange = { at: wall, text: "设备时间向前调整，已按新的时刻结算经营事件。" };
    else if (wall < estimated - 2e3 && !this.lagging) this.clockChange = { at: Math.floor(estimated), text: "检测到设备时钟回拨，经营时间按原进度继续。" };
    this.lagging = wall < estimated - 2e3;
    this.anchor = Math.max(wall, estimated);
    this.mark = mono;
    return Math.floor(this.anchor);
  }
  save(s) {
    this.state = s;
    this.savedAt = s.clock;
  }
  advance(forceCheckpoint = false) {
    this.ensure();
    const now = this.now();
    const s = structuredClone(this.state);
    const world = ({ receipts, clock, ...fields2 }) => JSON.stringify(fields2);
    const before = world(s);
    tickCare(s, now);
    settleOnboarding(s, now);
    tickShow(s, now);
    tickBusiness(s, now);
    if (s.onboarding?.finishedAt && !this.state.onboarding?.finishedAt) recordTaskAction(s, "onboarding.claim", {}, now);
    if (this.clockChange) s.clockEvent = this.clockChange;
    const changed = before !== world(s);
    if (changed || now - this.savedAt >= minute2 || forceCheckpoint && now !== this.savedAt) {
      s.clock = now;
      if (changed) s.version++;
      this.save(s);
    }
    this.clockChange = null;
    return now;
  }
  shop() {
    const now = this.advance();
    return publicShop(this.state, now, this.rules);
  }
  requireFeature(level, key, s = this.state) {
    if (key && level < this.rules.featureLevels[key] && !guideAccess(s, key)) {
      throw new GameError(featureNames[key] + "需要店铺达到 " + this.rules.featureLevels[key] + " 级。", 403);
    }
  }
  page(page, args = {}) {
    const now = this.advance(), s = this.state;
    const level = shopProgress(this.rules, s.shopXp).level;
    const access = shopAccess(s, this.rules, level);
    if (args.fromTasks === true && ["lab", "orders"].includes(page) && !access[page].unlocked) {
      const { name, requiredLevel } = access[page];
      return { shop: publicShop(s, now, this.rules), page: {
        title: name,
        presentation: { kind: "featureLocked" },
        rows: [{ title: name + "尚未开放", text: "店铺达到 " + requiredLevel + " 级后开放。出售活体动物可以获得店铺经验。" }]
      } };
    }
    this.requireFeature(level, operationFeature(page, args));
    const data = structuredClone(s);
    let view = openingPage(data, page, args, now) ?? (page === "login" ? accountPage(data, now, access) : visitHistoryPage(data, page, now, access, args));
    if (page === "tasks" && !view) view = tasksPage(data, access);
    for (const get of pageHandlers) {
      if (view) break;
      view = get(data, page, args, now, this.rules);
    }
    if (!view) throw new GameError("这个页面暂不可用，请返回店铺。", 404);
    decorateOpeningPage(data, page, args, view, now);
    if (page === "orders" || page === "guest") {
      view.tabs = [
        { label: "普通订单", page: "orders", active: page === "orders" },
        {
          label: access.guest.unlocked ? "特殊来客" : `特殊来客 · ${access.guest.requiredLevel} 级`,
          page: "guest",
          active: page === "guest",
          disabled: !access.guest.unlocked
        }
      ];
    }
    const sale = view.actions?.find((a) => a.type === "sale.commit");
    if (sale) {
      this.requireFeature(level, operationFeature(sale.type, sale.args));
      const xp = saleExperience(this.rules, sale.args.channel, sale.args.amounts.map((amount) => ({ amount })));
      sale.args.saleExperience = xp;
      view.visual = { ...view.visual, saleExperience: xp };
      if (xp) view.subtitle += " · 店铺经验 +" + xp;
    }
    let viewed = recordTaskVisit(s, page, args, now);
    if (page === "litter" && view.presentation?.kind === "litter") {
      const { speciesKey: speciesKey2, bornAt } = view.presentation, room = viewed.rooms[speciesKey2], litter2 = room?.lastLitter;
      if (litter2?.bornAt === bornAt && !litter2.viewed) {
        viewed = { ...viewed, rooms: { ...viewed.rooms, [speciesKey2]: { ...room, lastLitter: { ...litter2, viewed: true } } } };
      }
    }
    if (viewed !== s) {
      viewed.clock = now;
      this.save(viewed);
    }
    return { shop: publicShop(viewed, now, this.rules), page: view };
  }
  receipt(id) {
    this.ensure();
    if (!Object.hasOwn(this.state.receipts, id)) throw new GameError("尚未找到该请求回执。", 404);
    return this.state.receipts[id].result;
  }
  act({ requestId, profileId, version, type, args }) {
    const now = this.advance(), current2 = this.state;
    if (typeof requestId !== "string" || !/^[\w-]{12,100}$/.test(requestId) || typeof type !== "string" || !args || Array.isArray(args) || typeof args !== "object") throw new GameError("请求格式不正确。", 400);
    if (profileId !== current2.profileId) throw new GameError("存档已切换，请重新打开店铺。");
    const key = JSON.stringify(canonical([type, args]));
    const old = Object.hasOwn(current2.receipts, requestId) && current2.receipts[requestId];
    if (old) {
      if (old.key !== key) throw new GameError("请求编号与原操作不符。");
      return old.result;
    }
    if (version !== current2.version) {
      if (type === "sale.commit") {
        try {
          validateSaleQuote(current2, args, now);
        } catch (error) {
          throw new GameError(error.message);
        }
      }
      throw new GameError("店内情况已变化，请查看最新资料后重新确认。");
    }
    const level = shopProgress(this.rules, current2.shopXp).level;
    this.requireFeature(level, operationFeature(type, args));
    if (type === "sale.commit" && args.litterRetention) this.requireFeature(level, "breed");
    const s = structuredClone(current2);
    let message = openingAction(s, type, args, now);
    if (message === void 0) for (const run of actionHandlers) {
      message = run(s, type, args, now, this.rules);
      if (message !== void 0) break;
    }
    if (message === void 0) throw new GameError("未识别的经营操作。", 400);
    if (typeof message !== "string" || !Number.isSafeInteger(s.coins) || s.coins < 0) throw Error("经营数据校验失败。");
    let awarded, levelUp;
    if (type === "sale.commit") {
      const sale = s.sales.at(-1);
      awarded = saleExperience(this.rules, sale.channel, sale.lines);
      if (args.saleExperience !== void 0 && args.saleExperience !== awarded) throw new GameError("店铺经验报价已变化，请重新核价。");
      sale.saleExperience = awarded;
      s.shopXp += awarded;
      if (!Number.isSafeInteger(s.shopXp)) throw Error("店铺经验超出可保存范围。");
      if (awarded) message = message.replace(/。$/, "") + "，店铺经验 +" + awarded + "。";
      const next = shopProgress(this.rules, s.shopXp).level;
      if (next > level) {
        const unlocked = Object.keys(featureNames).filter((key2) => this.rules.featureLevels[key2] > level && this.rules.featureLevels[key2] <= next);
        levelUp = { from: level, to: next, unlocked };
        message += "店铺升至 " + next + " 级" + (unlocked.length ? "，解锁" + unlocked.map((key2) => featureNames[key2]).join("、") : "") + "。";
      }
    }
    recordMilestone(s, type, args, now);
    if (s.onboarding) recordOpeningAction(s, type, args, now);
    recordTaskAction(s, type, args, now);
    s.clock = now;
    s.version++;
    const result = { requestId, message, version: s.version, ...awarded !== void 0 && { saleExperience: awarded }, ...levelUp && { levelUp } };
    s.receipts[requestId] = { key, result };
    this.save(s);
    return result;
  }
  heartbeat(clientId, foreground, reader) {
    if (typeof clientId !== "string" || !/^[\w-]{8,100}$/.test(clientId) || typeof foreground !== "boolean") throw new GameError("心跳格式无效。", 400);
    const now = this.advance(), s = structuredClone(this.state);
    if (reader && (reader.profileId !== s.profileId || !Number.isSafeInteger(reader.seq) || reader.seq < 0 || reader.read !== void 0 && (!Array.isArray(reader.read) || reader.read.some((id) => typeof id !== "string")))) {
      throw new GameError("店铺已切换或账簿参数无效，请重新打开店铺。", 409);
    }
    const readers = new Map(this.readers);
    if (reader && reader.seq <= (readers.get(clientId)?.seq ?? -1)) return publicShop(s, now, this.rules);
    if (reader) updateVisit(s, readers, clientId, foreground, reader, now);
    const guestUnlocked = shopProgress(this.rules, s.shopXp).level >= this.rules.featureLevels.guest;
    if (!guestUnlocked && !reader) return publicShop(s, now, this.rules);
    const guest = s.visitors?.active?.id;
    if (guestUnlocked) businessHeartbeat(s, { clientId, foreground }, now);
    if (guest !== s.visitors?.active?.id) s.version++;
    s.clock = now;
    this.save(s);
    this.readers = readers;
    const shop = publicShop(s, now, this.rules);
    if (reader && foreground) shop.letter = unreadLetter(s, now, shop.featureAccess);
    return shop;
  }
  checkpoint(force = false) {
    if (this.state) this.advance(force);
  }
};

// output/aliyun/source-market-breed-20261121/PetShop/server/request-store.mjs
var RequestGameStore = class extends ShopEngine {
  constructor(snapshot = null, options2 = {}) {
    super(options2);
    this.dirty = false;
    if (snapshot === null) {
      this.initialize(null);
      return;
    }
    const readers = snapshot?.readers;
    if (!Array.isArray(readers)) throw new GameError("经营档的会话记录无法读取。", 503);
    for (const pair2 of readers) {
      if (!Array.isArray(pair2) || pair2.length !== 2) throw new GameError("经营档的会话记录无法读取。", 503);
      const [id, entry2] = pair2;
      if (typeof id !== "string" || !/^[-\w]{8,100}$/.test(id) || this.readers.has(id) || !Number.isFinite(entry2?.at) || typeof entry2.foreground !== "boolean" || !Number.isSafeInteger(entry2.seq) || entry2.seq < 0)
        throw new GameError("经营档的会话记录无法读取。", 503);
      this.readers.set(id, { at: entry2.at, foreground: entry2.foreground, seq: entry2.seq });
    }
    this.initialize(structuredClone(validateState(snapshot.state)));
  }
  save(s) {
    super.save(s);
    this.dirty = true;
  }
  snapshot() {
    return structuredClone({ state: this.state, readers: [...this.readers] });
  }
};

// output/aliyun/source-market-breed-20261121/PetShop/server/account-name.mjs
function accountName(input) {
  const name = typeof input === "string" ? input.trim().normalize("NFKC") : "";
  if (!/^[\p{L}\p{M}\p{N}._@-]{1,32}$/u.test(name)) {
    throw new GameError("账号名限 1 至 32 个字，可用中文、字母、数字及 ._@-。", 400);
  }
  return { name, key: name.toLowerCase() };
}

// output/aliyun/source-market-breed-20261121/外网试玩/accounts/passwords.mjs
import { randomBytes as randomBytes3, scryptSync, timingSafeEqual } from "node:crypto";
import { Buffer as Buffer2 } from "node:buffer";
var format = "scrypt-32768-8-3";
var cost = { N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 };
var dummySalt = "00000000000000000000000000000000";
function validPassword(password) {
  if (typeof password !== "string" || password.length > 256) return false;
  const length = Array.from(password).length;
  return length >= 8 && length <= 128;
}
function passwordRecord(password) {
  const salt = randomBytes3(16).toString("hex");
  return [format, salt, scryptSync(password, Buffer2.from(salt, "hex"), 32, cost).toString("hex")].join("$");
}
function matchesPassword(password, record) {
  const [type, salt, digest2] = (record || "").split("$");
  const usable = type === format && /^[a-f0-9]{32}$/.test(salt) && /^[a-f0-9]{64}$/.test(digest2);
  const derived = scryptSync(password, Buffer2.from(usable ? salt : dummySalt, "hex"), 32, cost);
  return usable && timingSafeEqual(derived, Buffer2.from(digest2, "hex"));
}

// output/aliyun/source-market-breed-20261121/外网试玩/accounts/worker.mjs
var prefix = "/petshop-api/v1/";
var sites = /* @__PURE__ */ new Set(["https://play.zhu-li-4212.xyz", "https://petshop-trial.pages.dev", "https://petshop.zhu-li-4212.xyz"]);
var sessionLifetime = 30 * 864e5;
var hash = (value) => createHash4("sha256").update(value).digest("hex");
var json = (value, status = 200) => new Response(JSON.stringify(value), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
async function body(request, limit) {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") {
    throw new GameError("请求需要 JSON。", 415);
  }
  const stream = request.body?.getReader();
  if (!stream) throw new GameError("请求内容为空。", 400);
  let length = 0, content = "";
  const decoder = new TextDecoder();
  while (true) {
    const chunk = await stream.read();
    if (chunk.done) break;
    length += chunk.value.byteLength;
    if (length > limit) {
      await stream.cancel();
      throw new GameError("请求数据太大。", 413);
    }
    content += decoder.decode(chunk.value, { stream: true });
  }
  try {
    const parsed = JSON.parse(content + decoder.decode());
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
  } catch {
  }
  throw new GameError("请求内容无效。", 400);
}
async function limitAuth(db, key, maximum) {
  const now = Date.now(), windowMs = 6e5;
  const bucket = hash(key);
  const updated = await db.prepare(`INSERT INTO trial_auth_limits VALUES (?,1,?)
    ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN expires_at<=? THEN 1 ELSE attempts+1 END,
    expires_at=CASE WHEN expires_at<=? THEN excluded.expires_at ELSE expires_at END
    WHERE expires_at<=? OR attempts<? RETURNING attempts`).bind(bucket, now + windowMs, now, now, now, maximum).first();
  if (!updated) throw new GameError("操作过于频繁，请稍后再试。", 429);
  if (updated.attempts === 1) await db.prepare("DELETE FROM trial_auth_limits WHERE expires_at<=?").bind(now).run();
}
async function setLegacyPassword(db, input, key) {
  const now = Date.now();
  const proof = input.legacyProof;
  const code = typeof input.code === "string" ? input.code.trim().toLowerCase() : "";
  let condition, values;
  if (/^[0-9a-f]{16}$/.test(code)) {
    condition = "EXISTS (SELECT 1 FROM trial_sessions s WHERE s.account_id=trial_accounts.id AND s.setup_digest=? AND s.setup_expires_at>? AND s.expires_at>?)";
    values = [hash(code), now, now];
  } else if (typeof proof?.profileId === "string" && proof.profileId.length <= 128 && typeof proof.rootSeed === "string" && /^[0-9a-f]{64}$/.test(proof.rootSeed)) {
    condition = "json_extract(snapshot,'$.state.profileId')=? AND json_extract(snapshot,'$.state.rootSeed')=?";
    values = [proof.profileId, proof.rootSeed];
  } else {
    throw new GameError("请输入有效的一次性验证码，或使用原浏览器的旧店凭据。", 403);
  }
  const eligible2 = "name_key=? AND password_hash IS NULL AND " + condition;
  const unavailable = () => new GameError("旧店凭据无效、已过期，或此账号已设密码。", 403);
  const account = await db.prepare("SELECT id,username FROM trial_accounts WHERE " + eligible2).bind(key, ...values).first();
  if (!account) throw unavailable();
  const record = passwordRecord(input.password);
  const token = randomBytes4(32).toString("base64url");
  const batch = await db.batch([
    db.prepare("UPDATE trial_accounts SET password_hash=? WHERE " + eligible2).bind(record, key, ...values),
    db.prepare("DELETE FROM trial_sessions WHERE account_id=? AND EXISTS(SELECT 1 FROM trial_accounts WHERE id=? AND password_hash=?)").bind(account.id, account.id, record),
    db.prepare("INSERT INTO trial_sessions(digest,account_id,expires_at) SELECT ?,id,? FROM trial_accounts WHERE id=? AND password_hash=?").bind(hash(token), now + sessionLifetime, account.id, record)
  ]);
  if (!batch[0].meta.changes) throw unavailable();
  return json({ username: account.username, token, accountId: account.id });
}
async function legacySetupCode(db, token, digest2) {
  const now = Date.now(), expires = now + 9e5;
  const codeAt = (expiry) => createHmac2("sha256", token).update("trial-password-setup:" + expiry).digest("hex").slice(0, 16);
  const session = await db.prepare(`UPDATE trial_sessions SET
    setup_digest=CASE WHEN setup_expires_at>? THEN setup_digest ELSE ? END,
    setup_expires_at=CASE WHEN setup_expires_at>? THEN setup_expires_at ELSE ? END
    WHERE digest=? AND expires_at>? RETURNING setup_expires_at`).bind(now, hash(codeAt(expires)), now, expires, digest2, now).first();
  if (!session) throw new GameError("请重新登录试玩账号。", 401);
  return codeAt(session.setup_expires_at);
}
function newTrialSnapshot(legacy = null) {
  const snapshot = new RequestGameStore(legacy, { onboarding: true }).snapshot();
  snapshot.readers = [];
  snapshot.state.visitors.sessions = {};
  snapshot.state.visitors.intervals = [];
  return snapshot;
}
async function authenticate(db, request, route) {
  const peer = request.headers.get("cf-connecting-ip") || "local";
  await limitAuth(db, route + ":" + peer, route === "auth/register" ? 120 : 600);
  const registering = route === "auth/register";
  const input = await body(request, registering ? 18e5 : 4096);
  const { name, key } = accountName(input.username);
  if (!validPassword(input.password)) throw new GameError("请输入 8 至 128 个字符的密码。", 400);
  if (!registering) await limitAuth(db, route + ":account:" + key, 30);
  if (route === "auth/set-password") return setLegacyPassword(db, input, key);
  const token = randomBytes4(32).toString("base64url");
  const now = Date.now();
  const statements = [db.prepare("DELETE FROM trial_sessions WHERE expires_at<=?").bind(now)];
  let account;
  if (registering) {
    let snapshot;
    try {
      snapshot = newTrialSnapshot(input.legacySnapshot ?? null);
    } catch {
      throw new GameError("无法读取旧店存档。原存档仍保留在这个浏览器。", 422);
    }
    account = { id: randomUUID6(), username: name };
    statements.push(db.prepare("INSERT INTO trial_accounts(id,name_key,username,snapshot,password_hash) VALUES(?,?,?,?,?)").bind(account.id, key, name, JSON.stringify(snapshot), passwordRecord(input.password)));
  } else {
    account = await db.prepare("SELECT id,username,password_hash FROM trial_accounts WHERE name_key=?").bind(key).first();
    if (!matchesPassword(input.password, account?.password_hash)) throw new GameError("账号名或密码不正确。旧账号请先设置密码。", 401);
  }
  statements.push(db.prepare("INSERT INTO trial_sessions(digest,account_id,expires_at) VALUES(?,?,?)").bind(hash(token), account.id, now + sessionLifetime));
  try {
    await db.batch(statements);
  } catch (error) {
    if (registering && await db.prepare("SELECT id FROM trial_accounts WHERE name_key=?").bind(key).first()) {
      throw new GameError("这个账号名已注册。", 409);
    }
    throw error;
  }
  return json({ username: account.username, token, accountId: account.id });
}
function play(game, route, data, username) {
  if (route === "shop") return game.shop();
  if (route.startsWith("receipts/")) return game.receipt(route.slice(9));
  if (route === "heartbeat") return game.heartbeat(data.clientId, data.foreground, data.reader);
  if (route === "action") return game.act(data);
  if (typeof data.page !== "string" || data.args != null && (typeof data.args !== "object" || Array.isArray(data.args))) {
    throw new GameError("页面参数无效。", 400);
  }
  if (data.page === "multiplayerAccount") return { shop: game.shop(), page: { title: "切换账号", rows: [] } };
  const result = game.page(data.page, data.args || {});
  if (data.page === "login") {
    result.page.subtitle = "试玩账号 · " + username;
    result.page.actions.push({ label: "切换账号", page: "multiplayerAccount" });
    const clock = result.page.rows.find((row2) => row2.title === "设备时间");
    if (clock) {
      clock.title = "经营时间";
      clock.text = "换设备输入同一账号与密码，可继续经营这家店。";
    }
  }
  return result;
}
async function dispatch(request, db, route) {
  const get = request.method === "GET";
  if (get && route === "health") {
    await db.prepare("SELECT 1 FROM trial_accounts LIMIT 1").first();
    return json({ service: "petshop", storage: "trial-accounts", status: "ok", protocol: 1, gameplay: 1 });
  }
  if (request.method === "POST" && ["auth/register", "auth/login", "auth/set-password"].includes(route)) return authenticate(db, request, route);
  const read = route === "shop" || /^receipts\/[\w-]+$/.test(route);
  if (!read && !["auth/logout", "page", "heartbeat", "action"].includes(route)) throw new GameError("接口不存在。", 404);
  if (request.method !== (read ? "GET" : "POST")) throw new GameError("不支持此请求方法。", 405);
  const token = request.headers.get("authorization")?.match(/^Bearer ([\w-]{43})$/)?.[1];
  if (!token) throw new GameError("请先登录试玩账号。", 401);
  const digest2 = hash(token);
  if (route === "auth/logout") {
    await db.prepare("DELETE FROM trial_sessions WHERE digest=?").bind(digest2).run();
    return json({ ok: true });
  }
  const data = read ? null : await body(request, 512 * 1024);
  for (let attempt = 0; attempt < 8; attempt++) {
    const row2 = await db.prepare(`SELECT a.id,a.username,a.revision,a.snapshot,(a.password_hash IS NULL) AS legacy FROM trial_sessions s
      JOIN trial_accounts a ON a.id=s.account_id WHERE s.digest=? AND s.expires_at>?`).bind(digest2, Date.now()).first();
    if (!row2) throw new GameError("请重新登录试玩账号。", 401);
    const game = new RequestGameStore(JSON.parse(row2.snapshot));
    let result, rejected;
    try {
      result = play(game, route, data, row2.username);
    } catch (error) {
      if (!(error instanceof GameError) && error.constructor !== Error) throw error;
      rejected = error instanceof GameError ? error : new GameError(error.message);
    }
    if (game.dirty) {
      const written = await db.prepare("UPDATE trial_accounts SET snapshot=?,revision=revision+1 WHERE id=? AND revision=? AND EXISTS(SELECT 1 FROM trial_sessions WHERE digest=? AND expires_at>?)").bind(JSON.stringify(game.snapshot()), row2.id, row2.revision, digest2, Date.now()).run();
      if (!written.meta.changes) continue;
    }
    if (rejected) throw rejected;
    if (row2.legacy && route === "page" && data.page === "login") {
      const code = await legacySetupCode(db, token, digest2);
      result.page.rows.unshift({ title: "设置密码验证码", text: code + "（15 分钟有效）。在另一个标签页打开试玩，点「旧账号设置密码」，输入验证码并设置密码。" });
    }
    const response = json(result);
    if (route === "page" && data.page === "multiplayerAccount") response.headers.set("X-PetShop-Account", "switch");
    return response;
  }
  throw new GameError("另一台设备正在保存，请重试。", 409);
}
var worker_default = {
  async fetch(request, env) {
    const url = new URL(request.url), origin = request.headers.get("origin");
    if (!url.pathname.startsWith(prefix)) return env.ASSETS ? env.ASSETS.fetch(request) : json({ error: "接口不存在。" }, 404);
    const local = ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname);
    const localOrigin = local && origin && /^http:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(origin);
    if (origin && !sites.has(origin) && !localOrigin) return json({ error: "来源不受支持。" }, 403);
    let response;
    try {
      response = request.method === "OPTIONS" ? new Response(null, { status: 204 }) : await dispatch(request, env.DB.withSession?.("first-primary") ?? env.DB, url.pathname.slice(prefix.length));
    } catch (error) {
      if (!(error instanceof GameError)) console.error("Trial account request failed", error.name);
      response = error instanceof GameError ? json({ error: error.message }, error.status) : json({ error: "暂时无法读取或保存试玩店铺。" }, 503);
    }
    response.headers.set("Vary", "Origin");
    if (origin) {
      response.headers.set("Access-Control-Allow-Origin", origin);
      response.headers.set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
      response.headers.set("Access-Control-Allow-Headers", "Authorization,Content-Type");
      response.headers.set("Access-Control-Expose-Headers", "X-PetShop-Account");
    }
    return response;
  }
};
export {
  worker_default as default,
  newTrialSnapshot
};
