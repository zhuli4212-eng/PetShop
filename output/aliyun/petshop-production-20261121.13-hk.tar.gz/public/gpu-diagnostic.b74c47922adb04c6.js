const contextCounts = { attempts: 0, created: 0 };
const contexts = new WeakSet();
const originalGetContext = HTMLCanvasElement.prototype.getContext;

function getContext(type, ...args) {
  const context = originalGetContext.call(this, type, ...args);
  if (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
    contextCounts.attempts++;
    if (context && !contexts.has(context)) {
      contexts.add(context);
      contextCounts.created++;
    }
  }
  return context;
}

HTMLCanvasElement.prototype.getContext = getContext;

export function stopContextCount() {
  if (HTMLCanvasElement.prototype.getContext === getContext) HTMLCanvasElement.prototype.getContext = originalGetContext;
}

let installed = false;
const buildTag = 'sora-diag-20261121';

export async function install(apiBase, token) {
  const endpoint = apiBase + 'diagnostic';
  const authorization = 'Bearer ' + token;
  const options = { headers: { Authorization: authorization }, credentials: 'omit', cache: 'no-store', redirect: 'error' };
  if (installed) return;
  const gate = new AbortController();
  const gateTimeout = setTimeout(() => gate.abort(), 2500);
  try {
    if ((await fetch(endpoint, { ...options, signal: gate.signal })).status !== 204) {
      stopContextCount();
      return;
    }
  } finally { clearTimeout(gateTimeout); }
  if (installed) return;
  installed = true;
  const session = crypto.randomUUID().replaceAll('-', '');
  const start = performance.now();
  const elapsed = () => Math.round(performance.now() - start);
  let seq = 0, pending = [], timer, active = true, operation = 0, resourceCount = 0, current;
  const send = () => {
    clearTimeout(timer);
    timer = undefined;
    if (!active || !pending.length) return;
    const events = pending;
    pending = [];
    void fetch(endpoint, {
      ...options, method: 'POST', keepalive: true,
      headers: { ...options.headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ buildTag, session, events }),
    }).then(reply => { if (reply.status === 404) active = false; }).catch(() => {});
  };
  const mark = (phase, details = {}, immediate = false) => {
    if (!active) return;
    pending.push({ seq: ++seq, t: elapsed(), phase, page: current?.current?.key, ...details });
    if (immediate || pending.length >= 20) send();
    else timer ??= setTimeout(send, 350);
  };
  const state = shop => ({
    reading: shop.reading, online: shop.online, hasData: Boolean(shop.current?.data),
    rows: shop.current?.data?.rows?.length, version: shop.current?.version,
  });

  const measuredCanvas = document.getElementById('GameCanvas');
  let sampleNumber = 0;
  let lastSample = 0;
  let readDevice;
  let readPixelRatio;
  let firstAttributes;
  let lastDrawingBuffer;

  function sampleRender(reason, event, immediate = false) {
    if (!active || !measuredCanvas) return;
    const now = elapsed();
    if (reason === 2 && now - lastSample < 650) return;
    lastSample = now;
    try {
      const device = readDevice?.();
      const gl = device?.gl;
      const lost = reason === 5 || Boolean(gl?.isContextLost());
      if (gl && !lost) {
        firstAttributes ??= gl.getContextAttributes();
        lastDrawingBuffer = [gl.drawingBufferWidth, gl.drawingBufferHeight];
      }
      const memory = device?.memoryStatus;
      const detail = event?.statusMessage?.toLowerCase() ?? '';
      const status = /out of memory|memory pressure|allocation|\boom\b/.test(detail) ? 2
        : /reset|gpu process|crash/.test(detail) ? 3 : detail ? 1 : 0;
      const op = 1000000 + 4 * sampleNumber++;
      // The running account service already accepts these numeric diagnostic fields.
      // Reserve a separate ID range so the receiver can distinguish this group.
      mark('hooks', { operation: op, ms: measuredCanvas.width, status: measuredCanvas.height,
        rows: measuredCanvas.clientWidth, version: measuredCanvas.clientHeight, visible: !document.hidden });
      mark('hooks', { operation: op + 1, ms: memory?.bufferSize, status: memory?.textureSize,
        rows: Math.round(window.devicePixelRatio * 100), version: Math.round((readPixelRatio?.() ?? 0) * 100) });
      mark('hooks', { operation: op + 2, ms: contextCounts.attempts, status: contextCounts.created,
        rows: document.querySelectorAll('canvas').length, version: gl ? (typeof gl.texStorage2D === 'function' ? 2 : 1) : 0,
        ok: firstAttributes?.antialias });
      mark('hooks', { operation: op + 3, ms: lastDrawingBuffer?.[0], status: lastDrawingBuffer?.[1],
        rows: reason, version: status, ok: !lost }, immediate);
    } catch { /* A sampling error must not interfere with rendering. */ }
  }

  const renderTimer = setInterval(() => {
    if (!active) {
      clearInterval(renderTimer);
      stopContextCount();
      return;
    }
    if (!document.hidden) sampleRender(2);
  }, 1000);
  sampleRender(1, null, true);

  mark('start', { visible: !document.hidden, version: 202611218 }, true);
  let last = elapsed();
  const alive = setInterval(() => {
    if (!active) { clearInterval(alive); return; }
    const now = elapsed();
    mark('alive', { ms: now - last, visible: !document.hidden });
    last = now;
  }, 10000);
  document.addEventListener('visibilitychange', () => {
    sampleRender(7);
    mark('visibility', { visible: !document.hidden }, true);
  });
  window.addEventListener('pagehide', () => mark('pagehide', {}, true));
  window.addEventListener('error', () => mark('error', {}, true), true);
  window.addEventListener('unhandledrejection', () => mark('rejection', {}, true));
  const canvas = document.getElementById('GameCanvas');
  canvas?.addEventListener('pointerdown', () => mark('pointer', {}, true), { capture: true, passive: true });
  canvas?.addEventListener('webglcontextlost', event => {
    sampleRender(5, event);
    mark('contextlost', {}, true);
  });
  canvas?.addEventListener('webglcontextrestored', () => sampleRender(6, null, true));
  canvas?.addEventListener('webglcontextcreationerror', event => sampleRender(8, event, true));

  const open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, target, ...options) {
    const result = open.call(this, method, target, ...options);
    try {
      const url = new URL(target, document.baseURI);
      const match = /^\/(?:api|petshop-api\/v1)\/(shop|page|action|heartbeat|receipts)(?:\/|$)/.exec(url.pathname);
      if (!active || url.origin !== location.origin || !match) return result;
      const route = match[1];
      const id = ++operation;
      let started;
      const cleanup = () => {
        for (const [event, listener] of Object.entries(listeners)) this.removeEventListener(event, listener);
      };
      const listeners = { loadstart: () => {
        started = elapsed();
        mark('xhr.begin', { route, operation: id });
      } };
      for (const phase of ['load', 'error', 'timeout', 'abort']) listeners[phase] = () => {
        mark('xhr.' + phase, { route, operation: id, status: this.status, ms: elapsed() - started });
        cleanup();
      };
      for (const [event, listener] of Object.entries(listeners)) this.addEventListener(event, listener);
    } catch { /* Logging cannot interfere with the original request. */ }
    return result;
  };

  const engine = System.import('cc').then(({ director, resources, screen }) => {
    readDevice = () => director.root?.device;
    readPixelRatio = () => screen.devicePixelRatio;
    const load = resources.load;
    resources.load = function(asset, ...args) {
      const callback = args.at(-1);
      if (!active || resourceCount >= 180 || typeof asset !== 'string' || typeof callback !== 'function') {
        return load.call(this, asset, ...args);
      }
      resourceCount++;
      const resource = /^(shop-modules|onboarding|rooms)\//.exec(asset)?.[1] ?? (asset.startsWith('pet-') ? 'pet' : 'other');
      const id = ++operation;
      const started = elapsed();
      mark('resource.begin', { resource, operation: id });
      args[args.length - 1] = function(error, ...result) {
        mark(error ? 'resource.error' : 'resource.end', { resource, operation: id, ms: elapsed() - started });
        return callback.call(this, error, ...result);
      };
      return load.call(this, asset, ...args);
    };
  });

  const shop = System.import('chunks:///_virtual/ShopSession.ts').then(({ ShopSession }) => {
    for (const name of ['open', 'navigate', 'read', 'render']) {
      const fn = ShopSession.prototype[name];
      if (typeof fn !== 'function') throw Error('Missing diagnostic hook');
      ShopSession.prototype[name] = function(...args) {
        if (!active) return fn.apply(this, args);
        current = this;
        const id = ++operation;
        const started = elapsed();
        const page = ['open', 'navigate'].includes(name) ? args[0] : this.current?.key;
        const record = phase => mark(name + '.' + phase, {
          ...state(this), page, operation: id, ms: elapsed() - started,
        }, phase === 'throw' || (phase === 'begin' && name === 'read' && args[0] !== true));
        if (name === 'navigate') sampleRender(4);
        record('begin');
        try {
          const result = fn.apply(this, args);
          if (result instanceof Promise) void result.then(() => record('end'), () => record('throw')).catch(() => {});
          else {
            record('end');
            if (name === 'render') sampleRender(3);
          }
          return result;
        } catch (error) {
          record('throw');
          throw error;
        }
      };
    }
  });
  for (const hook of [engine, shop]) void hook.then(() => mark('hooks', { ok: true }), () => mark('hooks', { ok: false }, true));
}
